/* ClientDesk service worker: caches the app shell so it loads with no internet. Bump VERSION on release. */
const VERSION = 'clientdesk-v1.4.0';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'css/styles.css', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/favicon-64.png', 'icons/maskable-512.png', 'icons/apple-touch-icon.png',
  'js/util.js', 'js/db.js', 'js/logic.js', 'js/pdf.js', 'js/reports.js', 'js/ui.js', 'js/forms.js', 'js/views.js', 'js/analytics.js', 'js/bulk.js', 'js/native.js', 'js/legal.js', 'js/phone.js', 'js/smart.js', 'js/lock.js', 'js/app.js'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('message', (e) => { if (e.data === 'SKIP_WAITING') self.skipWaiting(); });

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith((async () => {
    const cache = await caches.open(VERSION);
    const hit = await cache.match(req, { ignoreSearch: true });
    // stale-while-revalidate: instant from cache, refresh in background when online
    const net = fetch(req).then((res) => { if (res && res.ok) cache.put(req, res.clone()); return res; }).catch(() => null);
    if (hit) { e.waitUntil(net); return hit; }
    const res = await net;
    if (res) return res;
    if (req.mode === 'navigate') return (await cache.match('index.html')) || Response.error();
    return Response.error();
  })());
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
    for (const c of list) { if ('focus' in c) { c.navigate && c.navigate('./#/reminders').catch(() => {}); return c.focus(); } }
    return self.clients.openWindow('./#/reminders');
  }));
});
