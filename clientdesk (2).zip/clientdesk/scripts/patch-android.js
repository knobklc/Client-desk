// Prepares the generated android/ project: permissions + the ClientDeskDevice plugin (contacts & call history). Safe to re-run.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const appId = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8')).appId; // com.clientdesk.app
const main = path.join(root, 'android', 'app', 'src', 'main');
const manifest = path.join(main, 'AndroidManifest.xml');
if (!fs.existsSync(manifest)) { console.log('No android/ project yet — run "npm run android:add" first.'); process.exit(0); }

// 1. permissions
let x = fs.readFileSync(manifest, 'utf8');
const perms = ['POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'RECEIVE_BOOT_COMPLETED', 'READ_CONTACTS', 'READ_CALL_LOG'].map((p) => 'android.permission.' + p);
const add = perms.filter((p) => !x.includes(p));
if (add.length) { x = x.replace('</manifest>', add.map((p) => `    <uses-permission android:name="${p}" />\n`).join('') + '</manifest>'); fs.writeFileSync(manifest, x); }
console.log(add.length ? 'Added permissions: ' + add.join(', ') : 'Permissions already present.');

// 2. plugin source + MainActivity registration
const pkgDir = path.join(main, 'java', ...appId.split('.'));
fs.mkdirSync(pkgDir, { recursive: true });
fs.copyFileSync(path.join(root, 'native', 'android', 'ClientDeskDevicePlugin.java'), path.join(pkgDir, 'ClientDeskDevicePlugin.java'));
fs.writeFileSync(path.join(pkgDir, 'MainActivity.java'), `package ${appId};

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ClientDeskDevicePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`);
console.log('Installed ClientDeskDevice plugin and registered it in MainActivity.');
