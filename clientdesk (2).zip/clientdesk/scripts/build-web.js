// Copies the web app into ./www (the folder Capacitor packs into the APK). The web app itself is unchanged.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true });
for (const item of ['index.html', 'manifest.webmanifest', 'sw.js', 'css', 'js', 'icons']) fs.cpSync(path.join(root, item), path.join(out, item), { recursive: true });
console.log('Web app copied to www/');
