# ClientDesk

Offline-first client call log, promise tracker, follow-up manager, analytics and PDF reports.
Runs as a **web app / PWA** and as an **Android app** (Capacitor) from the same code. No third-party libraries in the app itself.

## 1. Use it as a web app (PWA)
Service workers need HTTPS or localhost.

    npm start            # or: python3 -m http.server 8080   -> http://localhost:8080

Host the folder on any HTTPS static host (Netlify, GitHub Pages, cPanel), open once online, then "Install app". Works offline after that.

## 2. Build the Android APK

### Option A: no Android Studio, in the cloud (easiest)
1. Put this folder in a GitHub repository.
2. GitHub -> **Actions** -> **Build Android APK** -> **Run workflow**.
3. When it finishes, download the artifact **ClientDesk-debug-apk**, unzip, copy `app-debug.apk` to your phone and open it
   (allow "install unknown apps" for your file manager/browser when asked).

### Option B: on your computer
Needs Node 22+, JDK 21 and Android Studio (or just the Android SDK).

    npm install
    npm run build:web
    npm run android:add      # creates android/, makes icons from assets/, adds permissions (first time only)
    npm run android:apk      # -> android/app/build/outputs/apk/debug/app-debug.apk
    # or: npm run android:open  and press Run in Android Studio

After any change to the web code: `npm run android:sync` then rebuild.

A *debug* APK is fine to install and use. For the Play Store you need a signed release build (Android Studio: Build > Generate Signed Bundle/APK).

## What changes inside the Android app (js/native.js, only active in the APK)
- PDFs and backups open the Android share sheet (Save to Drive/Files, send on WhatsApp...) instead of a browser download.
- Reminders are scheduled as real Android notifications that fire even when the app is closed (allow notifications when asked).
- The Android Back button closes dialogs, then goes to the dashboard, then exits.
- No service worker is needed; the files live inside the APK. Data is stored in the app's own storage.

## Notes
- Data stays on the device. Clearing the app's storage or uninstalling deletes it: **export backups** (Settings).
- Optional, untested: receive WhatsApp "Share" directly in the APK by installing `@capgo/capacitor-share-target` and following its Android setup; `native.js` already listens for it. On the web/PWA, sharing works through the manifest `share_target`.
- Icons: `assets/` holds the sources for the Android launcher icons (adaptive icon foreground/background); `icons/` are the web icons.
- Release process: bump `VERSION` in `sw.js` and `CD.VERSION` in `js/views.js`.
- Tests: `NODE_PATH=<playwright> node tests/accept.test.js` (server on :8123).

## v1.3 additions (Android APK features)

- **Start calls from the app** – the Call button opens the phone dialer; when you return, ClientDesk offers to log the call with the time prefilled.
- **Import phone contacts** (Clients → Import numbers → Phone contacts) – APK only; web uses the Contact Picker where the browser supports it.
- **Import call log** (Calls → Import from phone) – APK only, needs READ_CALL_LOG; duplicates are skipped. Note: Google Play restricts this permission; sideloaded APKs are fine.
- **Privacy policy, terms and consent screen** – shown on first launch, with prominent disclosure before contacts/call-log access. The texts are templates: have a lawyer review them and set `CD.LEGAL.contact` in `js/legal.js`.
- Created by **KnobXeno**.

The Java plugin (`native/android/ClientDeskDevicePlugin.java`) and APK build were not compiled in the authoring environment; the first GitHub Actions build may need small fixes.

## v1.4 additions

- **Smart suggestions after a call** – if your call note mentions a payment ("has paid UGX 500,000") ClientDesk offers to mark the matching promise fulfilled (or record a part payment); if it mentions a future promise ("will pay 300k on Friday") it offers to record it and schedule the follow-up. You always confirm; negations such as "has not paid" are ignored. Turn off in Settings → Smart assistance. (`js/smart.js`)
- **Quick replies** – "Message" button on clients, calls and promises: pick a template, edit, send by WhatsApp or SMS. Templates are editable in Settings; placeholders `{name} {fullname} {me} {org} {description} {amount} {date} {company}`.
- **App lock** – PIN (4–6 digits, PBKDF2-hashed, back-off after 5 wrong tries), auto-lock when you leave the app, optional fingerprint/screen-lock via WebAuthn where the browser supports it (the APK WebView may not; PIN always works). The lock keeps people out of the app; it does not encrypt stored data. PINs are never included in backups. A forgotten PIN can only be reset by erasing the device data. (`js/lock.js`)
- **Weekly summary** – dashboard button + a once-a-week prompt (default Friday after 15:00): headline numbers, highlights, next actions, share as PDF or WhatsApp. (`js/smart.js`)
