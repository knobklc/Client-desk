package com.clientdesk.app;

import android.Manifest;
import android.database.Cursor;
import android.provider.CallLog;
import android.provider.ContactsContract;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Read-only access to the phone's contacts and call history, used only when the user taps the
 * import buttons (after an in-app disclosure). Nothing is uploaded; no audio is accessed.
 */
@CapacitorPlugin(
    name = "ClientDeskDevice",
    permissions = {
        @Permission(alias = "contacts", strings = { Manifest.permission.READ_CONTACTS }),
        @Permission(alias = "calllog", strings = { Manifest.permission.READ_CALL_LOG })
    }
)
public class ClientDeskDevicePlugin extends Plugin {

    /* ---------------- contacts ---------------- */
    @PluginMethod
    public void getContacts(PluginCall call) {
        if (getPermissionState("contacts") != PermissionState.GRANTED) {
            requestPermissionForAlias("contacts", call, "contactsPermsCallback");
            return;
        }
        loadContacts(call);
    }

    @PermissionCallback
    private void contactsPermsCallback(PluginCall call) {
        if (getPermissionState("contacts") == PermissionState.GRANTED) {
            loadContacts(call);
        } else {
            call.reject("Permission denied");
        }
    }

    private void loadContacts(PluginCall call) {
        Map<String, JSObject> byId = new LinkedHashMap<>();
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[] {
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                },
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
            );
            if (c != null) {
                while (c.moveToNext() && byId.size() < 5000) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    String number = c.getString(2);
                    if (number == null || number.trim().isEmpty()) continue;
                    JSObject o = byId.get(id);
                    if (o == null) {
                        o = new JSObject();
                        o.put("name", name == null ? "" : name);
                        o.put("numbers", new JSArray());
                        byId.put(id, o);
                    }
                    JSArray nums = (JSArray) o.opt("numbers");
                    nums.put(number.trim());
                }
            }
            JSArray contacts = new JSArray();
            for (JSObject o : byId.values()) contacts.put(o);
            JSObject result = new JSObject();
            result.put("contacts", contacts);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Could not read contacts: " + e.getMessage());
        } finally {
            if (c != null) c.close();
        }
    }

    /* ---------------- call history ---------------- */
    @PluginMethod
    public void getCalls(PluginCall call) {
        if (getPermissionState("calllog") != PermissionState.GRANTED) {
            requestPermissionForAlias("calllog", call, "callLogPermsCallback");
            return;
        }
        loadCalls(call);
    }

    @PermissionCallback
    private void callLogPermsCallback(PluginCall call) {
        if (getPermissionState("calllog") == PermissionState.GRANTED) {
            loadCalls(call);
        } else {
            call.reject("Permission denied");
        }
    }

    private void loadCalls(PluginCall call) {
        long since = call.getLong("since", 0L);
        int limit = call.getInt("limit", 500);
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                new String[] {
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DATE,
                    CallLog.Calls.DURATION
                },
                CallLog.Calls.DATE + " > ?",
                new String[] { String.valueOf(since) },
                CallLog.Calls.DATE + " DESC"
            );
            JSArray calls = new JSArray();
            if (c != null) {
                while (c.moveToNext() && calls.length() < limit) {
                    JSObject o = new JSObject();
                    String number = c.getString(0);
                    String name = c.getString(1);
                    o.put("number", number == null ? "" : number);
                    o.put("name", name == null ? "" : name);
                    o.put("type", c.getInt(2));
                    o.put("date", c.getLong(3));
                    o.put("duration", c.getLong(4));
                    calls.put(o);
                }
            }
            JSObject result = new JSObject();
            result.put("calls", calls);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Could not read call history: " + e.getMessage());
        } finally {
            if (c != null) c.close();
        }
    }
}
