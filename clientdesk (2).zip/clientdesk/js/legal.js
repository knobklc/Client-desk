/* ClientDesk — privacy policy, terms of use, consent screen and permission disclosures.
 * These are TEMPLATES written for this app's actual behaviour; have them reviewed by a qualified lawyer before public release. */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h, ui = CD.ui;
  const L = (CD.LEGAL = {
    version: '2026-11-20', creator: 'KnobXeno', year: 2026,
    contact: '' // <- put the support email / phone here, e.g. 'support@example.com'. Shown in the policy when set.
  });

  const contactLine = () => (L.contact ? `You can contact the developer, ${L.creator}, at ${L.contact}.` : `For questions about this policy, contact the developer, ${L.creator}, through the channel where you received the app.`);

  const POLICY = () => [
    { h: 'The short version', ul: [
      'ClientDesk is a notebook that lives on your device. The information you put in it is stored on your phone, tablet or computer — not on our servers.',
      `${L.creator} (the developer) does not receive, see or sell your data. The app has no accounts, no advertising and no analytics or tracking.`,
      'Contacts and call history are read only if you choose to import them, only after you allow the permission, and only the items you select are saved.',
      'ClientDesk never records phone calls or listens to audio, and never reads your messages.'] },
    { h: '1. Who we are', p: [`ClientDesk is created and published by ${L.creator}. This policy explains what the app does with information. ${contactLine()}`] },
    { h: '2. Information the app handles', ul: [
      'Information you type in: client names, phone numbers, emails, addresses, company names, notes, call notes, promises, amounts, follow-ups, reminders and report details.',
      'Contacts (only if you tap “Pick from phone contacts”): names and phone numbers shown in a list so you can choose which to add. Only the ones you select are saved in ClientDesk.',
      'Call history (only on Android, only if you tap “Import from phone”): for each call — the number, the name saved in your phone, date, time, duration and whether it was incoming, outgoing or missed. Only the calls you select are saved. No audio, no message content.',
      'Settings and your consent record (your name, organisation, preferences, the date you accepted this policy).',
      'Not collected: your location, microphone or camera data, call recordings, text or WhatsApp message content (except text you paste or share into the app yourself), advertising identifiers, or usage analytics.'] },
    { h: '3. Where information is stored', p: ['All records are stored locally in the app’s private storage on your device (the browser’s IndexedDB for the web version). Nothing is uploaded to a server by ClientDesk. Because data lives only on your device, clearing the app’s storage, uninstalling it, or losing the device can permanently delete it unless you have exported a backup.'] },
    { h: '4. Permissions the Android app may ask for', ul: [
      'Contacts: to let you choose phone contacts to import. Requested only when you tap the contacts button.',
      'Call log: to let you choose recent calls to add to your call records. Requested only when you tap the call-history button.',
      'Notifications and alarms: to show reminders for follow-ups and promises, even when the app is closed.',
      'Saving/sharing files: PDFs and backups are written to temporary app storage and handed to Android’s share sheet; you choose where they go.',
      'You can refuse or withdraw any permission in Android Settings → Apps → ClientDesk → Permissions. The rest of the app keeps working.'] },
    { h: '5. Sharing', p: ['ClientDesk shares information only when you tell it to — for example when you download a PDF, share a report, or open WhatsApp or your email app with a prepared message. Those apps and services have their own privacy policies. ClientDesk cannot see or control what happens after you share.'] },
    { h: '6. Your clients’ information — your responsibility', p: ['The people whose details you store are your clients or contacts. You decide what to record and why, so you are responsible for handling it lawfully — including any consent, notice, registration and security duties that apply to you or your organisation (in Uganda, the Data Protection and Privacy Act, 2019 and its regulations; elsewhere, the law that applies to you). Record only what you need, keep it accurate, and do not use it for unlawful purposes. ClientDesk does not record calls; if you record calls by other means you must follow the law on call recording and obtain any required consent.'] },
    { h: '7. Keeping information safe', ul: ['Lock your device with a PIN, pattern, fingerprint or face unlock.', 'Export backups regularly (Settings → Backup) and store them somewhere safe; a backup file contains all your client information, so protect it too.', 'Share reports only with people who are entitled to see them.'] },
    { h: '8. Retention and deletion', p: ['Information stays until you delete it. You can delete a client (with their history), remove demonstration data, or erase everything in Settings → Danger zone. Uninstalling the app also removes its stored data. Backup files and shared copies that you created are not deleted automatically.'] },
    { h: '9. Children', p: ['ClientDesk is a business tool and is not directed at children.'] },
    { h: '10. Changes to this policy', p: ['If this policy changes in a way that matters, the app will show it again and ask for your agreement. The current version is dated ' + L.version + '.'] },
    { h: '11. Contact', p: [contactLine()] }
  ];

  const TERMS = () => [
    { h: '1. Agreement', p: [`By using ClientDesk you agree to these Terms and to the Privacy Policy. ClientDesk is provided by ${L.creator}.`] },
    { h: '2. What you may do', p: ['You may use ClientDesk for your own lawful business or personal client follow-up, on your own devices. You may not copy, resell or redistribute the app, or remove its credits, without permission from the developer.'] },
    { h: '3. Acceptable use', ul: ['Use the app only for lawful purposes and in line with data-protection, privacy, telecommunications and consumer laws that apply to you.', 'Do not use it to harass or threaten anyone, to contact people who have asked not to be contacted, or to store information you have no right to hold.', 'Do not attempt to break, reverse-engineer or misuse the app.'] },
    { h: '4. Your data and backups', p: ['Your information belongs to you and is stored on your device. You are responsible for keeping backups. The developer cannot recover data that is lost, deleted or erased from your device.'] },
    { h: '5. No warranty', p: ['The app is provided “as is” and “as available”, without warranties of any kind. Reports, totals and reminders are calculated from what you enter; check them before relying on them. Notifications depend on your device and operating system and may not always fire.'] },
    { h: '6. Limitation of liability', p: ['To the fullest extent permitted by law, the developer is not liable for indirect or consequential loss, lost data, lost profits or lost business arising from use of, or inability to use, the app. Nothing in these Terms limits liability that cannot be limited by law.'] },
    { h: '7. Third-party services', p: ['Sharing to WhatsApp, email or other apps is handled by those services under their own terms.'] },
    { h: '8. Changes', p: ['These Terms may be updated. Continued use after an update shown in the app means you accept the new version; the app may ask you to agree again.'] },
    { h: '9. Governing law', p: ['These Terms are governed by the laws of the Republic of Uganda, unless mandatory local law says otherwise.'] },
    { h: '10. Credits', p: [`ClientDesk © ${L.year} ${L.creator}. All rights reserved.`] }
  ];

  const render = (secs) => h('div', { class: 'legal' }, ...secs.map((s) => h('section', {}, h('h3', {}, s.h), ...(s.p || []).map((t) => h('p', {}, t)), s.ul ? h('ul', { class: 'bullets' }, ...s.ul.map((t) => h('li', {}, t))) : null)));

  CD.showLegal = (kind) => {
    const m = CD.modal({ title: kind === 'terms' ? 'Terms of Use' : 'Privacy Policy', size: 'lg', body: h('div', {}, h('p', { class: 'muted small' }, `Version ${L.version} · ${L.creator}`), render(kind === 'terms' ? TERMS() : POLICY())), footer: [ui.btn('Close', { kind: 'primary', onclick: () => m.close() })] });
    return m;
  };

  CD.hasConsent = () => CD.settings.consentVersion === L.version;

  /** Blocking first-run / re-consent screen. Resolves when the user accepts. */
  CD.consentScreen = () => new Promise((resolve) => {
    const agree = h('input', { type: 'checkbox', id: 'agree' });
    const note = h('p', { class: 'txt-danger small', hidden: true }, 'ClientDesk cannot be used without agreeing to the Privacy Policy and Terms of Use.');
    const accept = ui.btn('Accept and continue', { kind: 'primary', icon: 'check', disabled: true, onclick: async () => { await CD.setSetting('consentVersion', L.version); await CD.setSetting('consentAt', new Date().toISOString()); m.close(); resolve(); } });
    agree.addEventListener('change', () => { accept.disabled = !agree.checked; note.hidden = true; });
    const m = CD.modal({ title: 'Before you start', size: 'md', locked: true, body: h('div', {},
      h('div', { class: 'consent-brand' }, CD.logo(44), h('div', {}, h('b', {}, 'ClientDesk'), h('div', { class: 'muted small' }, `by ${L.creator}`))),
      h('p', {}, 'Please read how ClientDesk treats your information:'),
      h('ul', { class: 'bullets' },
        h('li', {}, 'Your client information stays on this device. There are no accounts and nothing is sent to the developer.'),
        h('li', {}, 'Contacts and call history are read only if you choose to import them, after you allow the permission. Only items you select are saved.'),
        h('li', {}, 'The app never records calls or messages.'),
        h('li', {}, 'You are responsible for handling your clients’ information lawfully, and for keeping backups.')),
      h('p', { class: 'small' }, h('button', { class: 'link-btn', type: 'button', onclick: () => CD.showLegal('privacy') }, 'Read the Privacy Policy'), ' · ', h('button', { class: 'link-btn', type: 'button', onclick: () => CD.showLegal('terms') }, 'Read the Terms of Use')),
      h('label', { class: 'check consent-check', for: 'agree' }, agree, h('span', {}, 'I have read and agree to the Privacy Policy and the Terms of Use.')), note),
      footer: [ui.btn('Decline', { onclick: () => { note.hidden = false; const App = CD.native && CD.native.plugin('App'); if (App && App.exitApp && CD.native.isNative()) App.exitApp(); } }), accept] });
  });

  /** Prominent disclosure shown BEFORE Android's own permission dialog. Resolves true if the user continues. */
  const DISCLOSURE = {
    contacts: { title: 'Use your contacts?', text: ['ClientDesk will ask Android for permission to read your phone contacts.', 'It reads names and phone numbers only to show you a list to choose from. Nothing is uploaded, and only the contacts you tick are saved — on this device.'] },
    calllog: { title: 'Use your call history?', text: ['ClientDesk will ask Android for permission to read your call history.', 'It reads the number, the saved contact name, date, time, duration and whether the call was incoming, outgoing or missed — never audio or messages. You choose which calls to add; they are saved only on this device and are not sent anywhere.'] }
  };
  CD.disclose = (kind) => new Promise((resolve) => {
    const d = DISCLOSURE[kind]; let done = false; const fin = (v) => { if (done) return; done = true; resolve(v); m.close(); };
    const m = CD.modal({ title: d.title, size: 'sm', body: h('div', {}, ...d.text.map((t) => h('p', {}, t)), h('p', { class: 'small' }, h('button', { class: 'link-btn', type: 'button', onclick: () => CD.showLegal('privacy') }, 'Privacy Policy'))), footer: [ui.btn('Not now', { onclick: () => fin(false) }), ui.btn('Continue', { kind: 'primary', autofocus: true, onclick: () => fin(true) })], onClose: () => fin(false) });
  });
})();
