/* ClientDesk — forms and detail dialogs: clients, calls, promises, follow-ups, reminders */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h, ui = CD.ui;
  const S = () => CD.settings;
  const val = (el) => el.value.trim();
  const saveBtn = (label, onclick, icon = 'check') => ui.btn(label, { kind: 'primary', icon, onclick, type: 'button' });
  const cancelBtn = (m) => ui.btn('Cancel', { onclick: () => m.close() });
  const row = (...kids) => h('div', { class: 'row' }, ...kids);
  const withSubmit = (el, fn) => el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); fn(); } });
  const busy = async (btnEvt, fn) => { // prevent double submits
    const b = btnEvt && btnEvt.currentTarget; if (b) b.disabled = true;
    try { return await fn(); } catch (e) { console.error(e); CD.toast('Could not save: ' + (e.message || e), 'error'); } finally { if (b) b.disabled = false; }
  };
  const quickDates = (input) => h('div', { class: 'quick-dates' }, ...[['Tomorrow', 1], ['In 3 days', 3], ['Next week', 7], ['In 2 weeks', 14]].map(([l, n]) => h('button', { type: 'button', class: 'chip', onclick: () => { input.value = CD.addDays(CD.today(), n); input.dispatchEvent(new Event('input')); } }, l)));

  /* =============== CLIENT =============== */
  CD.openClientForm = (opts = {}) => {
    const ed = opts.client;
    const f = {
      name: h('input', { class: 'input', value: ed ? ed.name : '', maxlength: 120, autocomplete: 'off', autofocus: true }),
      phone: h('input', { class: 'input', type: 'tel', inputmode: 'tel', value: ed ? ed.phone : '', maxlength: 25, placeholder: 'e.g. 0772 000 000' }),
      altPhone: h('input', { class: 'input', type: 'tel', inputmode: 'tel', value: ed ? ed.altPhone : '', maxlength: 25 }),
      company: h('input', { class: 'input', value: ed ? ed.company : '', maxlength: 120 }),
      email: h('input', { class: 'input', type: 'email', value: ed ? ed.email : '', maxlength: 120 }),
      address: h('input', { class: 'input', value: ed ? ed.address : '', maxlength: 200 }),
      category: ui.select(ui.categoryOptions(S().categories, ed && ed.category), ed ? ed.category : ''),
      status: ui.select(CD.CLIENT_STATUSES, ed ? ed.status : 'Active'),
      registered: h('input', { class: 'input', type: 'date', value: ed ? ed.registered : CD.today() }),
      notes: h('textarea', { class: 'input', rows: 3, maxlength: 5000, placeholder: 'Anything worth remembering about this client…' }, ed ? ed.notes : '')
    };
    const body = h('form', { class: 'form', novalidate: true, onsubmit: (e) => { e.preventDefault(); submit(); } },
      row(ui.field('Full name', f.name, { required: true }), ui.field('Phone number', f.phone, { required: true })),
      h('details', { class: 'more', open: !!ed }, h('summary', {}, 'More details (optional)'),
        row(ui.field('Alternative phone', f.altPhone), ui.field('Company / business', f.company)),
        row(ui.field('Email address', f.email), ui.field('Physical address', f.address)),
        row(ui.field('Category', f.category), ui.field('Status', f.status)),
        row(ui.field('Date registered', f.registered)),
        ui.field('General notes', f.notes)),
      h('button', { type: 'submit', hidden: true }));
    let m;
    async function submit() {
      ui.clearErrs(body);
      const name = val(f.name), phone = val(f.phone), alt = val(f.altPhone), email = val(f.email);
      if (!name) return ui.fail(f.name, 'Enter the client’s name.');
      if (!CD.validPhone(phone)) return ui.fail(f.phone, 'Enter a valid phone number (digits, +, spaces).');
      if (alt && !CD.validPhone(alt)) return ui.fail(f.altPhone, 'Enter a valid alternative number or leave it empty.');
      if (email && !CD.validEmail(email)) return ui.fail(f.email, 'That email address does not look right.');
      if (!CD.isDate(f.registered.value)) return ui.fail(f.registered, 'Pick a valid date.');
      const dup = CD.findDuplicate(phone, alt, ed && ed.id);
      if (dup && !(await CD.confirm({ title: 'Possible duplicate', message: `${dup.name} already uses this phone number. Save this as a separate client anyway?`, confirmText: 'Save anyway' }))) return;
      const c = await CD.saveClient({ ...(ed || { demo: false }), name, phone, altPhone: alt, company: val(f.company), email, address: val(f.address), category: f.category.value, status: f.status.value, registered: f.registered.value, notes: val(f.notes) });
      CD.toast(ed ? 'Client updated.' : `${c.name} added.`);
      m.close(); if (opts.onSaved) opts.onSaved(c);
    }
    m = CD.modal({ title: ed ? 'Edit client' : 'Add new client', body, footer: [cancelBtn({ close: () => m.close() }), saveBtn(ed ? 'Save changes' : 'Save client', (e) => busy(e, submit))] });
    withSubmit(body, submit);
    return m;
  };

  CD.archiveClient = async (c) => {
    const to = c.status === 'Archived' ? 'Active' : 'Archived';
    if (to === 'Archived' && !(await CD.confirm({ title: 'Archive client?', message: `${c.name} will be hidden from your active lists, but all history is kept. You can restore them later.`, confirmText: 'Archive' }))) return false;
    await CD.saveClient({ ...c, status: to }); CD.toast(to === 'Archived' ? 'Client archived.' : 'Client restored.'); return true;
  };
  CD.deleteClient = async (c) => {
    const n = { calls: CD.clientCalls(c.id).length, promises: CD.clientPromises(c.id).length, fu: CD.clientFollowups(c.id).length };
    const ok = await CD.confirm({ title: 'Delete client permanently?', danger: true, confirmText: 'Delete permanently', message: `This permanently deletes ${c.name} together with ${CD.plural(n.calls, 'call')}, ${CD.plural(n.promises, 'promise')} and ${CD.plural(n.fu, 'follow-up')}. This cannot be undone. Consider archiving instead.` });
    if (!ok) return false;
    await CD.deleteClientCascade(c.id); CD.toast('Client deleted.'); return true;
  };

  /* =============== CALL =============== */
  CD.openCallForm = (opts = {}) => {
    const ed = opts.call;
    const picker = ui.clientPicker({ clientId: ed ? ed.clientId : opts.clientId || '' });
    const f = {
      date: h('input', { class: 'input', type: 'date', value: ed ? ed.date : opts.date || CD.today() }),
      time: h('input', { class: 'input', type: 'time', value: ed ? ed.time : opts.time || CD.nowTime() }),
      outcome: ui.select(CD.OUTCOMES, ed ? ed.outcome : 'Answered'),
      summary: h('textarea', { class: 'input', rows: 3, maxlength: 5000, placeholder: 'What did the client say?', autofocus: !!(ed || opts.clientId) }, ed ? ed.summary : ''),
      details: h('textarea', { class: 'input', rows: 2, maxlength: 5000 }, ed ? ed.details : ''),
      response: h('textarea', { class: 'input', rows: 2, maxlength: 5000, placeholder: 'e.g. Agreed to pay on Friday' }, ed ? ed.response : ''),
      action: h('textarea', { class: 'input', rows: 2, maxlength: 2000, placeholder: 'What do you need to do next?' }, ed ? ed.action : ''),
      next: h('input', { class: 'input', type: 'date', value: ed ? ed.nextFollowUp : '' }),
      nextTime: h('input', { class: 'input', type: 'time', value: '' }),
      notes: h('textarea', { class: 'input', rows: 2, maxlength: 5000 }, ed ? ed.notes : ''),
      pOn: h('input', { type: 'checkbox', id: 'pOn' }),
      pDesc: h('input', { class: 'input', maxlength: 300, placeholder: 'e.g. Will pay the balance on Friday' }),
      pDue: h('input', { class: 'input', type: 'date' }),
      pAmt: h('input', { class: 'input', type: 'number', min: 0, step: 'any', inputmode: 'decimal', placeholder: 'Optional' })
    };
    let direction = ed ? ed.direction : 'Outgoing';
    const dirEl = h('div', { class: 'seg', role: 'radiogroup', 'aria-label': 'Call direction' });
    const drawDir = () => CD.mount(dirEl, ...['Outgoing', 'Incoming'].map((d) => h('button', { type: 'button', role: 'radio', 'aria-checked': d === direction, class: 'seg-b' + (d === direction ? ' on' : ''), onclick: () => { direction = d; drawDir(); } }, d)));
    drawDir();
    const pBox = h('div', { class: 'subform', hidden: true }, row(ui.field('What was promised?', f.pDesc, { required: true }), ui.field('Expected by', f.pDue, { required: true })), row(ui.field(`Amount (${S().currency})`, f.pAmt)), quickDates(f.pDue));
    f.pOn.addEventListener('change', () => { pBox.hidden = !f.pOn.checked; if (f.pOn.checked) f.pDesc.focus(); });
    const body = h('form', { class: 'form', novalidate: true, onsubmit: (e) => { e.preventDefault(); submit(); } },
      picker.el,
      row(ui.field('Date', f.date, { required: true }), ui.field('Time', f.time), ui.field('Direction', dirEl)),
      ui.field('Call outcome', f.outcome),
      ui.field('Conversation summary', f.summary, { hint: 'What did the client say?' }),
      row(ui.field('Client’s response', f.response), ui.field('Action required', f.action)),
      ed ? null : h('div', { class: 'field' }, h('label', {}, 'Next follow-up date'), h('div', { class: 'row-tight' }, f.next, f.nextTime), quickDates(f.next), h('div', { class: 'err' })),
      h('details', { class: 'more', open: !!(ed && (ed.details || ed.notes)) }, h('summary', {}, 'More fields: important details, notes'), ui.field('Important details', f.details), ui.field('Additional notes', f.notes)),
      ed ? null : h('div', { class: 'promise-toggle' }, h('label', { class: 'check', for: 'pOn' }, f.pOn, h('span', {}, 'The client made a promise on this call')), pBox),
      h('button', { type: 'submit', hidden: true }));
    let m;
    async function submit() {
      ui.clearErrs(body);
      if (!CD.isDate(f.date.value)) return ui.fail(f.date, 'Pick the call date.');
      if (f.time.value && !CD.isTime(f.time.value)) return ui.fail(f.time, 'Invalid time.');
      if (!ed && f.next.value) {
        if (!CD.isDate(f.next.value)) return ui.fail(f.next, 'Invalid follow-up date.');
        if (f.next.value < f.date.value) return ui.fail(f.next, 'The follow-up cannot be before the call date.');
      }
      if (f.pOn.checked) {
        if (!val(f.pDesc)) return ui.fail(f.pDesc, 'Describe what was promised.');
        if (!CD.isDate(f.pDue.value)) return ui.fail(f.pDue, 'Pick the expected date.');
        if (f.pAmt.value !== '' && !(Number(f.pAmt.value) >= 0)) return ui.fail(f.pAmt, 'Enter a valid amount.');
      }
      let saved;
      await CD.batch(async () => {
        const client = await picker.resolve(); if (!client) return;
        saved = await CD.put('calls', { ...(ed || {}), clientId: client.id, date: f.date.value, time: f.time.value, direction, outcome: f.outcome.value, summary: val(f.summary), details: val(f.details), response: val(f.response), action: val(f.action), nextFollowUp: ed ? ed.nextFollowUp : f.next.value, notes: val(f.notes), demo: ed ? ed.demo : false });
        if (!ed && f.next.value) await CD.saveFollowup({ clientId: client.id, reason: val(f.action) || 'Follow up on call of ' + CD.fmtDate(f.date.value), date: f.next.value, time: f.nextTime.value, priority: 'Normal', status: 'Pending', relatedType: 'call', relatedId: saved.id, result: '', notes: '' });
        if (!ed && f.pOn.checked) await CD.recordPromise({ clientId: client.id, callId: saved.id, description: val(f.pDesc), dateMade: f.date.value, expectedDate: f.pDue.value, amount: f.pAmt.value === '' ? null : Number(f.pAmt.value), category: 'Payment', notes: '', status: 'Pending' });
      });
      if (!saved) return;
      CD.toast(ed ? 'Call updated.' : 'Call saved.' + (f.next.value ? ' Follow-up scheduled.' : '') + (f.pOn.checked ? ' Promise recorded.' : ''));
      m.close(); if (opts.onSaved) opts.onSaved(saved);
      if (!ed && CD.suggestAfterCall) setTimeout(() => CD.suggestAfterCall(saved, { promiseRecorded: f.pOn.checked }), 350);
    }
    m = CD.modal({ title: ed ? 'Edit call' : 'Log a call', size: 'lg', body, footer: [ui.btn('Cancel', { onclick: () => m.close() }), h('button', { type: 'button', class: 'btn btn-primary btn-lg', onclick: (e) => busy(e, submit) }, CD.icon('check', 16), h('span', {}, ed ? 'Save changes' : 'Save Call'))] });
    withSubmit(body, submit);
    return m;
  };

  CD.deleteCall = async (c) => {
    if (!(await CD.confirm({ title: 'Delete this call record?', danger: true, confirmText: 'Delete call', message: `The call with ${CD.clientName(c.clientId)} on ${CD.fmtDate(c.date)} will be permanently deleted.` }))) return false;
    await CD.del('calls', c.id); CD.toast('Call deleted.'); return true;
  };

  CD.openCallDetail = (id) => {
    const body = () => {
      const c = CD.byId('calls', id); if (!c) return h('p', {}, 'This call no longer exists.');
      const cl = CD.client(c.clientId);
      const kv = (k, v) => (v ? [h('dt', {}, k), h('dd', { class: 'pre' }, v)] : []);
      return h('div', {},
        h('div', { class: 'detail-head' }, h('div', {}, h('h3', {}, h('button', { class: 'link-btn', type: 'button', onclick: () => { m.close(); CD.openClientDetail(c.clientId); } }, CD.clientName(c.clientId)), ' ', ui.demoTag(c)), h('div', { class: 'muted' }, `${CD.fmtDT(c.date, c.time)} · ${c.direction}`)), ui.outcomeBadge(c.outcome)),
        h('dl', { class: 'kv' }, ...kv('Phone', cl && cl.phone), ...kv('Duration', c.durationSec ? Math.floor(c.durationSec / 60) + 'm ' + (c.durationSec % 60) + 's' : ''), ...kv('Source', c.source === 'phone' ? 'Imported from phone call log' : ''), ...kv('Conversation summary', c.summary), ...kv('Important details', c.details), ...kv('Client’s response', c.response), ...kv('Action required', c.action), ...kv('Next follow-up', c.nextFollowUp ? CD.fmtDate(c.nextFollowUp) : ''), ...kv('Additional notes', c.notes)),
        h('div', { class: 'btn-row' },
          ui.btn('Schedule follow-up', { icon: 'calendar', sm: true, onclick: () => CD.openFollowupForm({ clientId: c.clientId, relatedType: 'call', relatedId: c.id }) }),
          ui.btn('Record promise', { icon: 'handshake', sm: true, onclick: () => CD.openPromiseForm({ clientId: c.clientId, callId: c.id }) }), ui.btn('Message', { icon: 'msg', sm: true, onclick: () => CD.quickReply(c.clientId) })));
    };
    const m = CD.modal({ title: 'Call details', size: 'md', live: true, body,
      footer: () => { const c = CD.byId('calls', id); return c ? [ui.btn('Delete', { kind: 'danger-ghost', icon: 'trash', onclick: async () => { if (await CD.deleteCall(c)) m.close(); } }), ui.btn('Edit', { icon: 'edit', kind: 'primary', onclick: () => CD.openCallForm({ call: c }) })] : []; } });
    return m;
  };

  /* =============== PROMISE =============== */
  CD.openPromiseForm = (opts = {}) => {
    const ed = opts.promise;
    const picker = ui.clientPicker({ clientId: ed ? ed.clientId : opts.clientId || '' });
    const f = {
      desc: h('input', { class: 'input', maxlength: 300, value: ed ? ed.description : '', placeholder: 'e.g. Will pay the outstanding balance on Friday', autofocus: !!(ed || opts.clientId) }),
      made: h('input', { class: 'input', type: 'date', value: ed ? ed.dateMade : CD.today() }),
      due: h('input', { class: 'input', type: 'date', value: ed ? ed.expectedDate : '' }),
      amount: h('input', { class: 'input', type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: ed && ed.amount != null ? ed.amount : '', placeholder: 'Optional' }),
      cat: ui.select(ui.categoryOptions(S().promiseCategories, ed && ed.category), ed ? ed.category : S().promiseCategories[0] || ''),
      notes: h('textarea', { class: 'input', rows: 2, maxlength: 5000 }, ed ? ed.notes : ''),
      remind: h('input', { type: 'checkbox', checked: ed ? ed.remind !== false : true })
    };
    const body = h('form', { class: 'form', novalidate: true, onsubmit: (e) => { e.preventDefault(); submit(); } },
      picker.el,
      ui.field('Promise or commitment', f.desc, { required: true }),
      row(ui.field('Date promise was made', f.made, { required: true }), ui.field('Expected fulfilment date', f.due, { required: true })),
      ed ? null : quickDates(f.due),
      row(ui.field(`Amount involved (${S().currency})`, f.amount), ui.field('Category', f.cat)),
      ui.field('Additional notes', f.notes),
      h('label', { class: 'check' }, f.remind, h('span', {}, 'Remind me on the expected date')),
      h('button', { type: 'submit', hidden: true }));
    let m;
    async function submit() {
      ui.clearErrs(body);
      if (!val(f.desc)) return ui.fail(f.desc, 'Describe the promise.');
      if (!CD.isDate(f.made.value)) return ui.fail(f.made, 'Pick the date the promise was made.');
      if (!CD.isDate(f.due.value)) return ui.fail(f.due, 'Pick the expected fulfilment date.');
      if (f.due.value < f.made.value) return ui.fail(f.due, 'The expected date cannot be before the date it was made.');
      if (f.amount.value !== '' && !(Number(f.amount.value) >= 0)) return ui.fail(f.amount, 'Enter a valid amount.');
      let saved;
      await CD.batch(async () => {
        const client = await picker.resolve(); if (!client) return;
        const base = { clientId: client.id, description: val(f.desc), dateMade: f.made.value, amount: f.amount.value === '' ? null : Number(f.amount.value), category: f.cat.value, notes: val(f.notes), remind: f.remind.checked };
        if (ed) {
          const dateChanged = f.due.value !== ed.expectedDate;
          saved = await CD.put('promises', { ...ed, ...base });
          if (dateChanged) saved = await CD.updatePromise(saved, { expectedDate: f.due.value, note: 'Changed while editing' });
          else await CD.syncPromiseReminder(saved);
        } else saved = await CD.recordPromise({ ...base, callId: opts.callId || '', expectedDate: f.due.value, status: 'Pending' });
      });
      if (!saved) return;
      CD.toast(ed ? 'Promise updated.' : 'Promise recorded.'); m.close(); if (opts.onSaved) opts.onSaved(saved);
    }
    m = CD.modal({ title: ed ? 'Edit promise' : 'Record a promise', body, footer: [ui.btn('Cancel', { onclick: () => m.close() }), saveBtn(ed ? 'Save changes' : 'Save promise', (e) => busy(e, submit))] });
    withSubmit(body, submit);
    return m;
  };

  CD.openPromiseDetail = (id) => {
    let status = null, newDate = '', amountPaid = '', note = '';
    const body = (api) => {
      const p = CD.byId('promises', id); if (!p) return h('p', {}, 'This promise no longer exists.');
      if (status === null) { status = p.status; newDate = p.expectedDate; }
      const sSel = ui.select(CD.PROMISE_STATUSES, status, { onchange: (e) => { status = e.target.value; api.render(); } });
      const dIn = h('input', { class: 'input', type: 'date', value: newDate, oninput: (e) => { newDate = e.target.value; } });
      const aIn = h('input', { class: 'input', type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: amountPaid, placeholder: 'Amount received now', oninput: (e) => { amountPaid = e.target.value; } });
      const nIn = h('textarea', { class: 'input', rows: 2, maxlength: 2000, placeholder: 'Progress note (optional)', oninput: (e) => { note = e.target.value; } }, note);
      const events = CD.data.promiseEvents.filter((e) => e.promiseId === id).sort((a, b) => CD.cmp(b.at, a.at));
      const evText = (e) => ({ created: 'Promise recorded', status: `Status changed: ${e.fromStatus} → ${e.toStatus}`, date: `Expected date changed: ${CD.fmtDate(e.fromDate)} → ${CD.fmtDate(e.toDate)}`, payment: `Payment received: ${CD.money(e.amount)}`, note: 'Progress note' }[e.type] || e.type);
      const submitUpdate = async () => {
        ui.clearErrs(api.body);
        const amt = amountPaid === '' ? 0 : Number(amountPaid);
        if (!(amt >= 0)) return ui.fail(aIn, 'Enter a valid amount.');
        if (!CD.isDate(newDate)) return ui.fail(dIn, 'Pick a valid date.');
        if (status === p.status && newDate === p.expectedDate && !amt && !note.trim()) { CD.toast('Nothing to update — change the status, date, amount or add a note.', 'info'); return; }
        if (status === 'Rescheduled' && newDate === p.expectedDate && p.status !== 'Rescheduled') return ui.fail(dIn, 'Choose the new expected date when rescheduling.');
        await CD.updatePromise(p, { status, expectedDate: newDate, amountPaid: amt, note });
        status = null; amountPaid = ''; note = ''; CD.toast('Promise updated.'); api.render();
      };
      return h('div', {},
        h('div', { class: 'detail-head' }, h('div', {}, h('h3', {}, p.description, ' ', ui.demoTag(p)), h('div', { class: 'muted' }, h('button', { class: 'link-btn', type: 'button', onclick: () => { m.close(); CD.openClientDetail(p.clientId); } }, CD.clientName(p.clientId)), ` · made ${CD.fmtDate(p.dateMade)}`)), h('div', { class: 'badges' }, ...ui.promiseBadges(p))),
        h('dl', { class: 'kv' },
          h('dt', {}, 'Expected by'), h('dd', {}, CD.fmtDate(p.expectedDate), ' ', CD.promiseOverdue(p) ? h('span', { class: 'txt-danger' }, `(${CD.overdueText(p.expectedDate)})`) : h('span', { class: 'muted' }, CD.promiseOpen(p) ? `(${CD.relDay(p.expectedDate).toLowerCase()})` : '')),
          p.amount != null ? [h('dt', {}, 'Amount'), h('dd', {}, `${CD.money(p.amount)} · received ${CD.money(p.amountFulfilled || 0)} · balance ${CD.money(CD.promiseBalance(p))}`)] : null,
          p.category ? [h('dt', {}, 'Category'), h('dd', {}, p.category)] : null,
          p.notes ? [h('dt', {}, 'Notes'), h('dd', { class: 'pre' }, p.notes)] : null),
        h('div', { class: 'subform' },
          h('h4', {}, 'Update this promise'),
          h('p', { class: 'muted small' }, 'A promise stays open until you change its status — a passed deadline only marks it overdue.'),
          row(ui.field('Status', sSel), ui.field('Expected fulfilment date', dIn)),
          (status === 'Partially Fulfilled' || p.amount != null) ? ui.field(`Record payment (${S().currency})`, aIn) : null,
          ui.field('Progress note', nIn),
          h('div', { class: 'btn-row' }, ui.btn('Save update', { kind: 'primary', icon: 'check', onclick: (e) => busy(e, submitUpdate) }))),
        h('h4', { class: 'sec' }, 'History'),
        events.length ? h('ul', { class: 'timeline' }, ...events.map((e) => h('li', {}, h('span', { class: 'tl-dot' }), h('div', {}, h('b', {}, evText(e)), e.note && e.type !== 'created' ? h('div', { class: 'muted pre' }, e.note) : null, h('div', { class: 'muted small' }, CD.fmtStamp(e.at)))))) : h('p', { class: 'muted' }, 'No history yet.'));
    };
    const m = CD.modal({ title: 'Promise', size: 'md', body,
      footer: (api) => { const p = CD.byId('promises', id); return p ? [ui.btn('Delete', { kind: 'danger-ghost', icon: 'trash', onclick: async () => { if (await CD.confirm({ title: 'Delete this promise?', danger: true, confirmText: 'Delete', message: 'The promise and its history will be permanently deleted.' })) { await CD.batch(async () => { await CD.del('promiseEvents', CD.data.promiseEvents.filter((e) => e.promiseId === id).map((e) => e.id)); await CD.del('reminders', CD.data.reminders.filter((r) => r.promiseId === id).map((r) => r.id)); await CD.del('promises', id); }); CD.toast('Promise deleted.'); m.close(); } } }), ui.btn('Message', { icon: 'msg', onclick: () => CD.quickReply(p.clientId) }), ui.btn('Edit details', { icon: 'edit', onclick: () => CD.openPromiseForm({ promise: p, onSaved: () => api.render() }) })] : []; } });
    return m;
  };

  /* =============== FOLLOW-UP =============== */
  CD.openFollowupForm = (opts = {}) => {
    const ed = opts.followup;
    let related = ed && ed.relatedType ? `${ed.relatedType}:${ed.relatedId}` : opts.relatedType ? `${opts.relatedType}:${opts.relatedId}` : '';
    const relBox = h('div');
    const drawRel = (clientId) => {
      const opts2 = [{ value: '', label: 'None' }];
      if (clientId) {
        CD.clientCalls(clientId).sort((a, b) => CD.cmp(b.date + b.time, a.date + a.time)).slice(0, 10).forEach((c) => opts2.push({ value: 'call:' + c.id, label: `Call – ${CD.fmtDate(c.date)} (${c.outcome})` }));
        CD.clientPromises(clientId).filter((p) => CD.promiseOpen(p) || (ed && ed.relatedId === p.id)).forEach((p) => opts2.push({ value: 'promise:' + p.id, label: `Promise – ${CD.trunc(p.description, 40)}` }));
      }
      const sel = ui.select(opts2, related, { onchange: (e) => { related = e.target.value; } });
      if (!opts2.some((o) => o.value === related)) { related = ''; sel.value = ''; }
      CD.mount(relBox, ui.field('Related call or commitment', sel));
    };
    const picker = ui.clientPicker({ clientId: ed ? ed.clientId : opts.clientId || '' });
    picker.el.addEventListener('click', () => setTimeout(() => drawRel(picker.selectedId()), 0));
    const f = {
      reason: h('input', { class: 'input', maxlength: 300, value: ed ? ed.reason : opts.reason || '', placeholder: 'e.g. Confirm payment was made', autofocus: !!(ed || opts.clientId) }),
      date: h('input', { class: 'input', type: 'date', value: ed ? ed.date : opts.date || '' }),
      time: h('input', { class: 'input', type: 'time', value: ed ? ed.time : '' }),
      prio: ui.select(CD.PRIORITIES, ed ? ed.priority : 'Normal'),
      status: ui.select(CD.FU_STATUSES, ed ? ed.status : 'Pending'),
      notes: h('textarea', { class: 'input', rows: 2, maxlength: 3000 }, ed ? ed.notes : '')
    };
    drawRel(picker.selectedId());
    const body = h('form', { class: 'form', novalidate: true, onsubmit: (e) => { e.preventDefault(); submit(); } },
      picker.el,
      ui.field('Reason for follow-up', f.reason, { required: true }),
      h('div', { class: 'field' }, h('label', {}, 'Scheduled date & time', h('span', { class: 'req' }, ' *')), h('div', { class: 'row-tight' }, f.date, f.time), ed ? null : quickDates(f.date), h('div', { class: 'err' })),
      row(ui.field('Priority', f.prio), ed ? ui.field('Status', f.status) : null),
      relBox, ui.field('Notes', f.notes), h('button', { type: 'submit', hidden: true }));
    let m;
    async function submit() {
      ui.clearErrs(body);
      if (!val(f.reason)) return ui.fail(f.reason, 'Enter the reason for the follow-up.');
      if (!CD.isDate(f.date.value)) return ui.fail(f.date, 'Pick the scheduled date.');
      let saved;
      await CD.batch(async () => {
        const client = await picker.resolve(); if (!client) return;
        const [rt, rid] = related ? related.split(':') : ['', ''];
        const status = ed ? f.status.value : 'Pending';
        const dateChanged = ed && (ed.date !== f.date.value || ed.time !== f.time.value);
        saved = await CD.saveFollowup({ ...(ed || { result: '', demo: false }), clientId: client.id, reason: val(f.reason), date: f.date.value, time: f.time.value, priority: f.prio.value, status: status === 'Pending' && dateChanged && ed.status === 'Rescheduled' ? 'Rescheduled' : status, relatedType: rt, relatedId: rid, notes: val(f.notes), completedDate: status === 'Completed' ? (ed && ed.completedDate) || CD.today() : '', completedAt: status === 'Completed' ? (ed && ed.completedAt) || new Date().toISOString() : '' });
      });
      if (!saved) return;
      CD.toast(ed ? 'Follow-up updated.' : 'Follow-up scheduled.'); m.close(); if (opts.onSaved) opts.onSaved(saved);
    }
    m = CD.modal({ title: ed ? 'Edit follow-up' : 'Schedule follow-up', body, footer: [ui.btn('Cancel', { onclick: () => m.close() }), saveBtn(ed ? 'Save changes' : 'Schedule', (e) => busy(e, submit), 'calendar')] });
    withSubmit(body, submit);
    return m;
  };

  CD.completeFollowup = (fu) => {
    const result = h('textarea', { class: 'input', rows: 3, maxlength: 3000, placeholder: 'What happened? e.g. Client confirmed payment will arrive Monday.', autofocus: true });
    const next = h('input', { class: 'input', type: 'date' });
    const body = h('form', { class: 'form', onsubmit: (e) => e.preventDefault() },
      h('p', {}, h('b', {}, CD.clientName(fu.clientId)), ' – ', fu.reason),
      ui.field('Result of the follow-up', result), h('div', { class: 'field' }, h('label', {}, 'Schedule another follow-up (optional)'), next, quickDates(next)));
    const m = CD.modal({ title: 'Complete follow-up', body, footer: [ui.btn('Cancel', { onclick: () => m.close() }), saveBtn('Mark completed', (e) => busy(e, async () => {
      if (next.value && next.value < CD.today()) return ui.fail(next, 'Choose a date that is today or later.');
      await CD.batch(async () => {
        await CD.saveFollowup({ ...fu, status: 'Completed', result: val(result), completedDate: CD.today(), completedAt: new Date().toISOString() });
        if (next.value) await CD.saveFollowup({ clientId: fu.clientId, reason: 'Follow up again: ' + fu.reason, date: next.value, time: '', priority: fu.priority, status: 'Pending', relatedType: fu.relatedType, relatedId: fu.relatedId, result: '', notes: '', demo: fu.demo });
      });
      CD.toast('Follow-up completed.' + (next.value ? ' New follow-up scheduled.' : '')); m.close();
    }))] });
    return m;
  };
  CD.rescheduleFollowup = (fu) => {
    const date = h('input', { class: 'input', type: 'date', value: CD.addDays(CD.today(), 1), autofocus: true });
    const time = h('input', { class: 'input', type: 'time', value: fu.time || '' });
    const why = h('input', { class: 'input', maxlength: 300, placeholder: 'Why? (optional)' });
    const body = h('form', { class: 'form', onsubmit: (e) => e.preventDefault() }, h('p', {}, h('b', {}, CD.clientName(fu.clientId)), ' – ', fu.reason), h('p', { class: 'muted' }, `Currently ${CD.fmtDT(fu.date, fu.time)}`),
      h('div', { class: 'field' }, h('label', {}, 'New date & time'), h('div', { class: 'row-tight' }, date, time), quickDates(date)), ui.field('Reason', why));
    const m = CD.modal({ title: 'Reschedule follow-up', body, footer: [ui.btn('Cancel', { onclick: () => m.close() }), saveBtn('Reschedule', (e) => busy(e, async () => {
      if (!CD.isDate(date.value)) return ui.fail(date, 'Pick a date.');
      await CD.saveFollowup({ ...fu, date: date.value, time: time.value, status: 'Rescheduled', notes: [fu.notes, `Rescheduled from ${CD.fmtDT(fu.date, fu.time)}${val(why) ? ': ' + val(why) : ''}`].filter(Boolean).join('\n') });
      CD.toast('Follow-up rescheduled.'); m.close();
    }), 'calendar')] });
    return m;
  };
  CD.cancelFollowup = async (fu) => {
    if (!(await CD.confirm({ title: 'Cancel this follow-up?', message: 'It will be marked as cancelled and its reminder removed. You can still see it under All follow-ups.', confirmText: 'Cancel follow-up', cancelText: 'Keep it', danger: true }))) return;
    await CD.saveFollowup({ ...fu, status: 'Cancelled' }); CD.toast('Follow-up cancelled.');
  };
  CD.deleteFollowup = async (fu) => {
    if (!(await CD.confirm({ title: 'Delete follow-up?', message: 'This permanently removes the follow-up.', confirmText: 'Delete', danger: true }))) return false;
    await CD.batch(async () => { await CD.del('reminders', CD.data.reminders.filter((r) => r.followupId === fu.id).map((r) => r.id)); await CD.del('followups', fu.id); });
    CD.toast('Follow-up deleted.'); return true;
  };

  /* =============== MANUAL REMINDER =============== */
  CD.openReminderForm = (opts = {}) => {
    const ed = opts.reminder;
    const f = {
      title: h('input', { class: 'input', maxlength: 200, value: ed ? ed.title : '', autofocus: true, placeholder: 'e.g. Submit weekly report to supervisor' }),
      date: h('input', { class: 'input', type: 'date', value: ed ? ed.date : CD.today() }),
      time: h('input', { class: 'input', type: 'time', value: ed ? ed.time : '09:00' }),
      note: h('textarea', { class: 'input', rows: 2, maxlength: 2000 }, ed ? ed.note : '')
    };
    const body = h('form', { class: 'form', novalidate: true, onsubmit: (e) => e.preventDefault() }, ui.field('Reminder', f.title, { required: true }), h('div', { class: 'field' }, h('label', {}, 'Date & time', h('span', { class: 'req' }, ' *')), h('div', { class: 'row-tight' }, f.date, f.time), h('div', { class: 'err' })), ui.field('Note', f.note));
    const m = CD.modal({ title: ed ? 'Edit reminder' : 'Add reminder', body, footer: [ui.btn('Cancel', { onclick: () => m.close() }), saveBtn('Save reminder', (e) => busy(e, async () => {
      ui.clearErrs(body);
      if (!val(f.title)) return ui.fail(f.title, 'Enter what to be reminded about.');
      if (!CD.isDate(f.date.value)) return ui.fail(f.date, 'Pick a date.');
      if (f.time.value && !CD.isTime(f.time.value)) return ui.fail(f.time, 'Invalid time.');
      const changed = !ed || ed.date !== f.date.value || ed.time !== f.time.value;
      await CD.put('reminders', { ...(ed || { demo: false }), title: val(f.title), note: val(f.note), date: f.date.value, time: f.time.value || '09:00', done: false, snoozedUntil: changed ? '' : ed.snoozedUntil, notifiedAt: changed ? '' : ed.notifiedAt });
      CD.toast('Reminder saved.'); m.close();
    }))] });
    return m;
  };

  /* =============== CLIENT DETAIL (live) =============== */
  CD.openClientDetail = (id, startTab = 'timeline') => {
    let tab = startTab;
    const body = (api) => {
      const c = CD.client(id); if (!c) { setTimeout(() => api.close(), 0); return h('p', {}, 'This client no longer exists.'); }
      api.setTitle(c.name);
      const calls = CD.clientCalls(id).sort((a, b) => CD.cmp(b.date + (b.time || ''), a.date + (a.time || '')));
      const proms = CD.clientPromises(id).sort((a, b) => CD.cmp(b.dateMade, a.dateMade));
      const fus = CD.clientFollowups(id).sort((a, b) => (CD.fuOpen(a) === CD.fuOpen(b) ? CD.cmp(b.date, a.date) : CD.fuOpen(a) ? -1 : 1));
      const openP = proms.filter(CD.promiseOpen), overdueP = proms.filter(CD.promiseOverdue), openF = fus.filter(CD.fuOpen);
      const kv = (k, v, node) => (v || node ? [h('dt', {}, k), h('dd', { class: 'pre' }, node || v)] : []);

      const items = [];
      calls.forEach((x) => items.push({ k: `${x.date}T${x.time || '00:00'}`, icon: 'phone', title: `${x.direction} call – ${x.outcome}`, text: x.summary, sub: CD.fmtDT(x.date, x.time), fn: () => CD.openCallDetail(x.id) }));
      proms.forEach((p) => { items.push({ k: `${p.dateMade}T12:00`, icon: 'handshake', title: `Promise recorded: ${p.description}`, text: `Expected ${CD.fmtDate(p.expectedDate)}${p.amount != null ? ' · ' + CD.money(p.amount) : ''}`, sub: CD.fmtDate(p.dateMade), badges: ui.promiseBadges(p), fn: () => CD.openPromiseDetail(p.id) }); });
      CD.data.promiseEvents.filter((e) => e.type !== 'created' && proms.some((p) => p.id === e.promiseId)).forEach((e) => { const p = CD.byId('promises', e.promiseId); items.push({ k: CD.localISO(new Date(e.at)), icon: 'handshake', title: { status: `Promise → ${e.toStatus}`, date: `Promise rescheduled to ${CD.fmtDate(e.toDate)}`, payment: `Payment received ${CD.money(e.amount)}`, note: 'Promise note' }[e.type] || 'Promise update', text: [CD.trunc(p.description, 60), e.note].filter(Boolean).join(' – '), sub: CD.fmtStamp(e.at), fn: () => CD.openPromiseDetail(p.id) }); });
      fus.forEach((f) => { items.push({ k: CD.localISO(new Date(f.created_at)), icon: 'calendar', title: `Follow-up scheduled for ${CD.fmtDT(f.date, f.time)}`, text: f.reason, sub: CD.fmtStamp(f.created_at), badges: ui.fuBadges(f), fn: () => CD.openFollowupForm({ followup: f }) }); if (f.status === 'Completed') items.push({ k: CD.localISO(new Date(f.completedAt || f.updated_at)), icon: 'check', title: 'Follow-up completed', text: [f.reason, f.result].filter(Boolean).join(' – '), sub: CD.fmtStamp(f.completedAt || f.updated_at) }); });
      items.sort((a, b) => CD.cmp(b.k, a.k));
      const tl = (list, empty) => (list.length ? h('ul', { class: 'timeline' }, ...list.map((it) => h('li', {}, h('span', { class: 'tl-ic' }, CD.icon(it.icon, 13)), h('div', { class: 'tl-body' }, h('div', { class: 'tl-title' }, it.fn ? h('button', { class: 'link-btn', type: 'button', onclick: it.fn }, it.title) : h('b', {}, it.title), ...(it.badges || [])), it.text ? h('div', { class: 'tl-text' }, CD.trunc(it.text, 240)) : null, h('div', { class: 'muted small' }, it.sub))))) : h('p', { class: 'muted pad' }, empty));
      let content;
      if (tab === 'timeline') content = tl(items, 'No activity yet. Log a call or record a promise to start the history.');
      else if (tab === 'calls') content = tl(items.filter((i) => i.icon === 'phone'), 'No calls logged for this client yet.');
      else if (tab === 'promises') content = proms.length ? h('div', { class: 'list' }, ...proms.map((p) => h('button', { type: 'button', class: 'list-row', onclick: () => CD.openPromiseDetail(p.id) }, h('div', {}, h('b', {}, p.description), h('div', { class: 'muted small' }, `Due ${CD.fmtDate(p.expectedDate)}${p.amount != null ? ' · ' + CD.money(p.amount) : ''}`)), h('div', { class: 'badges' }, ...ui.promiseBadges(p))))) : h('p', { class: 'muted pad' }, 'No promises recorded for this client.');
      else content = fus.length ? h('div', { class: 'list' }, ...fus.map((f) => h('div', { class: 'list-row' }, h('div', {}, h('b', {}, f.reason), h('div', { class: 'muted small' }, CD.fmtDT(f.date, f.time) + (f.result ? ' · ' + CD.trunc(f.result, 60) : ''))), h('div', { class: 'badges' }, ui.prioBadge(f.priority), ...ui.fuBadges(f), CD.fuOpen(f) ? ui.btn('Complete', { sm: true, onclick: () => CD.completeFollowup(f) }) : null)))) : h('p', { class: 'muted pad' }, 'No follow-ups scheduled for this client.');

      return h('div', {},
        h('div', { class: 'detail-head' }, h('div', { class: 'cl-id' }, h('span', { class: 'avatar lg' }, CD.initials(c.name)), h('div', {}, h('div', { class: 'badges' }, ui.clientStatusBadge(c.status), c.category ? ui.badge(c.category, 'neutral') : null, ui.demoTag(c)), c.company ? h('div', { class: 'muted' }, c.company) : null)),
          h('div', { class: 'btn-row' }, ui.btn('Call', { sm: true, icon: 'phone', kind: 'primary', onclick: () => CD.startCall(c.id) }), ui.btn('Message', { sm: true, icon: 'msg', onclick: () => CD.quickReply(c.id) }))),
        h('div', { class: 'btn-row wrap' },
          ui.btn('Log call', { sm: true, icon: 'edit', onclick: () => CD.openCallForm({ clientId: id }) }),
          ui.btn('Promise', { sm: true, icon: 'handshake', onclick: () => CD.openPromiseForm({ clientId: id }) }),
          ui.btn('Follow-up', { sm: true, icon: 'calendar', onclick: () => CD.openFollowupForm({ clientId: id }) }),
          ui.btn('Edit', { sm: true, icon: 'edit', onclick: () => CD.openClientForm({ client: c }) }),
          ui.btn('History PDF', { sm: true, icon: 'download', onclick: () => CD.downloadClientHistory(c) }),
          ui.btn(c.status === 'Archived' ? 'Restore' : 'Archive', { sm: true, icon: 'archive', onclick: async () => { await CD.archiveClient(c); } }),
          ui.btn('Delete', { sm: true, icon: 'trash', kind: 'danger-ghost', onclick: async () => { if (await CD.deleteClient(c)) m.close(); } })),
        h('dl', { class: 'kv kv-grid' }, ...kv('Phone', null, ui.phone(c.phone, c.id)), ...kv('Alternative phone', null, c.altPhone ? ui.phone(c.altPhone, c.id) : ''), ...kv('Email', c.email), ...kv('Address', c.address), ...kv('Registered', CD.fmtDate(c.registered)), ...kv('Notes', c.notes)),
        h('div', { class: 'mini-stats' }, ...[['Calls', calls.length], ['Open promises', openP.length], ['Overdue promises', overdueP.length, overdueP.length > 0], ['Open follow-ups', openF.length]].map(([l, v, w]) => h('div', { class: w ? 'warn' : '' }, h('b', {}, v), h('small', {}, l)))),
        ui.tabs([{ id: 'timeline', label: 'Timeline' }, { id: 'calls', label: 'Calls', count: calls.length }, { id: 'promises', label: 'Promises', count: proms.length }, { id: 'followups', label: 'Follow-ups', count: fus.length }], tab, (t) => { tab = t; m.render(); }),
        content);
    };
    const m = CD.modal({ title: 'Client', size: 'lg', live: true, body });
    return m;
  };

  CD.downloadClientHistory = (c) => {
    try {
      const rep = CD.buildReport({ type: 'client', clientId: c.id, from: '', to: '', includeDemo: true, include: {} });
      CD.downloadBlob(CD.reportToPDF(rep).toBlob(), CD.reportFileName(rep, 'pdf').replace(/^/, CD.slug(c.name) + '_'));
      CD.toast('Client history PDF downloaded.');
    } catch (e) { console.error(e); CD.toast('Could not create the PDF: ' + e.message, 'error'); }
  };
})();
