/* ClientDesk — business rules, derived values, reminders sync, demo data */
(function () {
  'use strict';
  const CD = window.CD;

  CD.OUTCOMES = ['Answered', 'No answer', 'Busy', 'Switched off', 'Call back requested', 'Other'];
  CD.UNANSWERED = ['No answer', 'Busy', 'Switched off'];
  CD.PROMISE_STATUSES = ['Pending', 'Fulfilled', 'Partially Fulfilled', 'Broken', 'Rescheduled'];
  CD.FU_STATUSES = ['Pending', 'Completed', 'Rescheduled', 'Cancelled'];
  CD.PRIORITIES = ['Low', 'Normal', 'High', 'Urgent'];
  CD.CLIENT_STATUSES = ['Active', 'Inactive', 'Archived'];

  /* ---------- Follow-ups ---------- */
  CD.fuOpen = (f) => f.status === 'Pending' || f.status === 'Rescheduled';
  CD.fuOverdue = (f) => {
    if (!CD.fuOpen(f) || !f.date) return false;
    const today = CD.today();
    if (f.date < today) return true;
    if (f.date === today && f.time) return f.time < CD.nowTime();
    return false;
  };
  CD.fuSort = (a, b) => CD.cmp(a.date + (a.time || '99:99'), b.date + (b.time || '99:99'));

  /* ---------- Promises (status is NEVER changed automatically; "overdue" is computed) ---------- */
  CD.promiseOpen = (p) => p.status === 'Pending' || p.status === 'Partially Fulfilled' || p.status === 'Rescheduled';
  CD.promiseOverdue = (p) => CD.promiseOpen(p) && !!p.expectedDate && p.expectedDate < CD.today();
  CD.promiseBalance = (p) => (p.amount != null ? Math.max(0, p.amount - (p.amountFulfilled || 0)) : null);

  /* ---------- Dashboard / summary stats (all calculated live from stored records) ---------- */
  CD.stats = () => {
    const d = CD.data, today = CD.today();
    const ws = CD.weekStart(today), we = CD.weekEnd(today);
    const open = d.followups.filter(CD.fuOpen);
    const overdue = open.filter(CD.fuOverdue);
    return {
      totalClients: d.clients.length,
      activeClients: d.clients.filter((c) => c.status === 'Active').length,
      callsToday: d.calls.filter((c) => c.date === today).length,
      callsWeek: d.calls.filter((c) => c.date >= ws && c.date <= we).length,
      fuPending: open.length - overdue.length,
      fuOverdue: overdue.length,
      promOutstanding: d.promises.filter(CD.promiseOpen).length,
      promOverdue: d.promises.filter(CD.promiseOverdue).length,
      promFulfilled: d.promises.filter((p) => p.status === 'Fulfilled').length
    };
  };

  CD.clientLastCall = (id) => {
    let best = null;
    for (const c of CD.data.calls) if (c.clientId === id && (!best || (c.date + c.time) > (best.date + best.time))) best = c;
    return best;
  };

  /* ---------- Client save with duplicate-phone detection ---------- */
  CD.findDuplicate = (phone, alt, ignoreId) => {
    const nums = [CD.normPhone(phone), CD.normPhone(alt)].filter(Boolean);
    if (!nums.length) return null;
    return CD.data.clients.find((c) => c.id !== ignoreId && nums.some((n) => n === c.phoneNorm || n === c.altNorm)) || null;
  };
  CD.saveClient = (c) => CD.put('clients', { ...c, phoneNorm: CD.normPhone(c.phone), altNorm: CD.normPhone(c.altPhone || '') });

  /* ---------- Promise updates with audit trail ---------- */
  CD.recordPromise = async (p) => {
    let rec;
    await CD.batch(async () => {
      rec = await CD.put('promises', { amountFulfilled: 0, remind: true, status: 'Pending', ...p });
      await CD.put('promiseEvents', { promiseId: rec.id, at: new Date().toISOString(), type: 'created', toStatus: rec.status, toDate: rec.expectedDate, note: 'Promise recorded' });
      await CD.syncPromiseReminder(rec);
    });
    return rec;
  };

  /** patch: {status, expectedDate, amountPaid, note}. Creates one history event per kind of change. */
  CD.updatePromise = async (p, patch) => {
    let next = { ...p };
    await CD.batch(async () => {
      const at = new Date().toISOString();
      const events = [];
      const note = (patch.note || '').trim();
      if (patch.expectedDate && patch.expectedDate !== p.expectedDate) {
        events.push({ type: 'date', fromDate: p.expectedDate, toDate: patch.expectedDate, note });
        next.expectedDate = patch.expectedDate;
      }
      if (patch.amountPaid && patch.amountPaid > 0) {
        next.amountFulfilled = (p.amountFulfilled || 0) + patch.amountPaid;
        events.push({ type: 'payment', amount: patch.amountPaid, note });
      }
      if (patch.status && patch.status !== p.status) {
        events.push({ type: 'status', fromStatus: p.status, toStatus: patch.status, note });
        next.status = patch.status;
        next.fulfilledAt = patch.status === 'Fulfilled' ? CD.today() : '';
        if (patch.status === 'Fulfilled' && p.amount != null && (next.amountFulfilled || 0) < p.amount) next.amountFulfilled = p.amount;
      }
      if (!events.length && note) events.push({ type: 'note', note });
      else if (events.length > 1 && note) { /* note already attached to each; keep only on first */ events.slice(1).forEach((e) => { e.note = ''; }); }
      if (patch.noteOnly) { /* nothing extra */ }
      next = await CD.put('promises', next);
      for (const e of events) await CD.put('promiseEvents', { promiseId: p.id, at, ...e });
      await CD.syncPromiseReminder(next);
    });
    return next;
  };

  /* ---------- Reminders: follow-ups & promises each own a linked reminder ---------- */
  CD.syncFollowupReminder = async (fu) => {
    const ex = CD.data.reminders.find((r) => r.followupId === fu.id);
    if (CD.fuOpen(fu)) {
      const time = fu.time || '09:00';
      const changed = !ex || ex.date !== fu.date || ex.time !== time;
      await CD.put('reminders', {
        ...(ex || {}), title: `Follow up: ${CD.clientName(fu.clientId)}`, note: fu.reason || '', date: fu.date, time,
        clientId: fu.clientId, followupId: fu.id, done: false, doneAt: '',
        snoozedUntil: changed ? '' : (ex.snoozedUntil || ''), notifiedAt: changed ? '' : (ex.notifiedAt || ''), demo: fu.demo
      });
    } else if (ex && !ex.done) {
      await CD.put('reminders', { ...ex, done: true, doneAt: new Date().toISOString() });
    }
  };
  CD.syncPromiseReminder = async (p) => {
    const ex = CD.data.reminders.find((r) => r.promiseId === p.id);
    if (CD.promiseOpen(p) && p.expectedDate && p.remind !== false) {
      const changed = !ex || ex.date !== p.expectedDate;
      await CD.put('reminders', {
        ...(ex || {}), title: `Promise due: ${CD.clientName(p.clientId)}`, note: p.description, date: p.expectedDate, time: '09:00',
        clientId: p.clientId, promiseId: p.id, done: false, doneAt: '',
        snoozedUntil: changed ? '' : (ex.snoozedUntil || ''), notifiedAt: changed ? '' : (ex.notifiedAt || ''), demo: p.demo
      });
    } else if (ex && !ex.done) {
      await CD.put('reminders', { ...ex, done: true, doneAt: new Date().toISOString() });
    }
  };
  CD.saveFollowup = async (f) => {
    let rec;
    await CD.batch(async () => { rec = await CD.put('followups', f); await CD.syncFollowupReminder(rec); });
    return rec;
  };

  /* reminder timing */
  CD.remDue = (r) => CD.dateTime(r.date, r.time || '09:00');
  CD.remAlertAt = (r) => {
    if (r.snoozedUntil) return new Date(r.snoozedUntil);
    return new Date(CD.remDue(r).getTime() - (Number(CD.settings.leadMinutes) || 0) * 60000);
  };
  CD.remSnoozed = (r) => !r.done && r.snoozedUntil && new Date(r.snoozedUntil) > new Date();
  CD.remOverdue = (r) => !r.done && !CD.remSnoozed(r) && CD.remAlertAt(r) <= new Date() && CD.remDue(r) < new Date();
  CD.remTriggered = (r) => !r.done && !CD.remSnoozed(r) && CD.remAlertAt(r) <= new Date();

  CD.snoozeReminder = (r, mins) => {
    const until = mins === 'tomorrow' ? (() => { const d = CD.dateTime(CD.addDays(CD.today(), 1), '09:00'); return d; })() : new Date(Date.now() + mins * 60000);
    return CD.put('reminders', { ...r, snoozedUntil: until.toISOString(), notifiedAt: '' });
  };

  /* ---------- Demo data (clearly flagged with demo:true; fictional Ugandan names & numbers) ---------- */
  CD.hasDemo = () => CD.STORES.some((s) => CD.data[s].some((r) => r.demo));
  CD.loadDemoData = async () => {
    const T = CD.today(), d = (n) => CD.addDays(T, n);
    const cl = [
      ['Nakato Grace', '0772 000 101', '0701 000 111', 'Kampala Fresh Foods Ltd', 'Corporate', 'Nakasero Road, Kampala'],
      ['Okello David', '0752 000 202', '', 'Okello & Sons Hardware', 'Business', 'Gulu Main Street, Gulu'],
      ['Namukasa Sarah', '0782 000 303', '', '', 'Individual', 'Ntinda, Kampala'],
      ['Mugisha Patrick', '0703 000 404', '0772 000 414', 'Mugisha Transporters', 'Business', 'Mbarara Town'],
      ['Atim Juliet', '0758 000 505', '', 'Lira Women Savings Group', 'Government / NGO', 'Lira City'],
      ['Ssebunya Moses', '0773 000 606', '', 'Ssebunya Printing Works', 'Business', 'Masaka Road, Kampala'],
      ['Achieng Ruth', '0789 000 707', '', '', 'Individual', 'Jinja Road, Jinja'],
      ['Tumwebaze Alex', '0704 000 808', '', 'Tumwebaze Agro Supplies', 'Corporate', 'Fort Portal']
    ];
    const ids = [];
    await CD.batch(async () => {
      for (const [name, phone, altPhone, company, category, address] of cl) {
        const c = await CD.saveClient({ name, phone, altPhone, company, category, address, email: '', status: 'Active', registered: d(-60), notes: '', demo: true });
        ids.push(c.id);
      }
      const call = async (ci, off, time, dir, outcome, summary, extra = {}) => CD.put('calls', { clientId: ids[ci], date: d(off), time, direction: dir, outcome, summary, details: '', response: '', action: '', nextFollowUp: '', notes: '', demo: true, ...extra });
      const c1 = await call(0, -6, '10:15', 'Outgoing', 'Answered', 'Discussed the outstanding invoice for October deliveries. Client confirmed receipt and said the accounts office is processing it.', { response: 'Agreed to pay within the week.', action: 'Call back on Friday to confirm payment.' });
      await call(1, -5, '14:30', 'Outgoing', 'No answer', 'Rang twice, no answer.');
      const c3 = await call(1, -3, '09:40', 'Outgoing', 'Answered', 'Client apologised for missing the earlier call. Says stock delivery is delayed at the border.', { response: 'Will send delivery documents tomorrow.', action: 'Check that documents arrived.' });
      await call(2, -2, '16:05', 'Incoming', 'Answered', 'Client called asking for a statement of account.', { action: 'Email the statement.' });
      await call(3, -2, '11:20', 'Outgoing', 'Switched off', 'Phone switched off. Will try the alternative number.');
      const c6 = await call(3, -1, '08:55', 'Outgoing', 'Answered', 'Reached him on the alternative number. He is travelling and promised to send mobile money payment on arrival.', { response: 'Will pay tomorrow evening.' });
      await call(4, -1, '15:10', 'Outgoing', 'Call back requested', 'In a meeting; asked me to call back tomorrow morning.');
      await call(5, 0, '09:05', 'Outgoing', 'Busy', 'Line busy.');
      await call(5, 0, '09:50', 'Outgoing', 'Answered', 'Discussed the balance on the printing order. He says funds come in on Thursday.', { response: 'Will pay the remaining balance on Thursday.' });
      await call(6, -12, '13:00', 'Outgoing', 'Answered', 'Client confirmed she had paid the deposit by bank transfer.');
      await call(7, -9, '10:00', 'Outgoing', 'Answered', 'Reminded about the delivery schedule; client asked for a revised quotation.', { action: 'Send revised quotation.' });
      await call(0, 0, '08:30', 'Outgoing', 'Answered', 'Quick check on whether the payment was approved. Said it will be released this afternoon.', { response: 'Release this afternoon.' });

      const pr = async (ci, desc, made, due, amount, category, status, extra = {}) => CD.recordPromise({ clientId: ids[ci], description: desc, dateMade: d(made), expectedDate: d(due), amount, category, notes: '', status, demo: true, ...extra });
      const p1 = await pr(0, 'Pay outstanding October invoice', -6, -1, 4500000, 'Payment', 'Pending', { callId: c1.id });
      await pr(1, 'Send delivery documents', -3, -2, null, 'Documents', 'Pending', { callId: c3.id });
      await pr(3, 'Send mobile money payment', -1, 1, 1200000, 'Payment', 'Pending', { callId: c6.id });
      await pr(5, 'Pay remaining balance on printing order', 0, 2, 2300000, 'Payment', 'Pending');
      const p5 = await pr(6, 'Pay 50% deposit', -20, -12, 800000, 'Payment', 'Pending');
      await CD.updatePromise(p5, { status: 'Fulfilled', note: 'Bank transfer confirmed.' });
      const p6 = await pr(7, 'Pay for first consignment', -15, -5, 3000000, 'Payment', 'Pending');
      await CD.updatePromise(p6, { status: 'Partially Fulfilled', amountPaid: 1000000, note: 'Paid UGX 1,000,000, balance to follow.' });
      const p7 = await pr(2, 'Return call about statement query', -8, -4, null, 'Call back', 'Pending');
      await CD.updatePromise(p7, { status: 'Broken', note: 'Did not call back; phone unreachable.' });
      const p8 = await pr(4, 'Share member contribution list', -4, 3, null, 'Documents', 'Pending');
      await CD.updatePromise(p8, { status: 'Rescheduled', expectedDate: d(4), note: 'Asked for one more day.' });

      const fu = async (ci, reason, off, time, priority, status = 'Pending', extra = {}) => CD.saveFollowup({ clientId: ids[ci], reason, date: d(off), time, priority, status, result: '', relatedType: '', relatedId: '', notes: '', demo: true, ...extra });
      await fu(0, 'Confirm invoice payment was received', 0, '15:00', 'Urgent', 'Pending', { relatedType: 'promise', relatedId: p1.id });
      await fu(4, 'Call back as requested', 0, '09:30', 'High');
      await fu(1, 'Check that delivery documents arrived', -1, '10:00', 'High');
      await fu(5, 'Confirm Thursday balance payment', 2, '11:00', 'Normal');
      await fu(2, 'Send statement of account and confirm receipt', 1, '', 'Normal');
      await fu(7, 'Follow up on revised quotation', 5, '', 'Low');
      await fu(6, 'Thank client for deposit', -10, '', 'Low', 'Completed', { result: 'Client appreciative; will place a bigger order next month.', completedDate: d(-10), completedAt: new Date(Date.now() - 10 * 86400000).toISOString() });
    });
  };

  /* ---------- Convenience lookups used by several views ---------- */
  CD.clientPromises = (id) => CD.data.promises.filter((p) => p.clientId === id);
  CD.clientCalls = (id) => CD.data.calls.filter((c) => c.clientId === id);
  CD.clientFollowups = (id) => CD.data.followups.filter((f) => f.clientId === id);
})();
