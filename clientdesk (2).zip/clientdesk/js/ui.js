/* ClientDesk — reusable UI components */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h;
  const ui = (CD.ui = {});

  ui.badge = (text, kind = 'neutral') => h('span', { class: 'badge badge-' + kind }, text);
  ui.demoTag = (rec) => (rec && rec.demo ? h('span', { class: 'tag-demo', title: 'Demonstration record' }, 'DEMO') : null);
  const PK = { Pending: 'info', Fulfilled: 'success', 'Partially Fulfilled': 'warn', Broken: 'danger', Rescheduled: 'purple' };
  ui.promiseBadges = (p) => [ui.badge(p.status, PK[p.status] || 'neutral'), CD.promiseOverdue(p) ? ui.badge('Overdue', 'danger-solid') : null];
  ui.fuBadges = (f) => [CD.fuOverdue(f) ? ui.badge('Overdue', 'danger-solid') : null, ui.badge(f.status, { Pending: 'info', Completed: 'success', Rescheduled: 'purple', Cancelled: 'neutral' }[f.status] || 'neutral')];
  ui.prioBadge = (p) => ui.badge(p, { Low: 'neutral', Normal: 'info', High: 'warn', Urgent: 'danger' }[p] || 'neutral');
  ui.outcomeBadge = (o) => ui.badge(o, o === 'Answered' ? 'success' : o === 'Call back requested' ? 'info' : CD.UNANSWERED.includes(o) ? 'warn' : 'neutral');
  ui.clientStatusBadge = (s) => ui.badge(s, s === 'Active' ? 'success' : s === 'Inactive' ? 'warn' : 'neutral');

  ui.btn = (label, o = {}) => h('button', { type: o.type || 'button', class: 'btn' + (o.kind ? ' btn-' + o.kind : '') + (o.sm ? ' btn-sm' : '') + (o.block ? ' btn-block' : ''), title: o.title, disabled: o.disabled, onclick: o.onclick, autofocus: o.autofocus }, o.icon ? CD.icon(o.icon, o.sm ? 14 : 16) : null, label ? h('span', {}, label) : null);
  ui.iconBtn = (icon, label, onclick, kind) => h('button', { type: 'button', class: 'icon-btn' + (kind ? ' ' + kind : ''), title: label, 'aria-label': label, onclick }, CD.icon(icon, 16));

  ui.field = (label, control, o = {}) => h('div', { class: 'field' + (o.class ? ' ' + o.class : '') },
    h('label', {}, label, o.required ? h('span', { class: 'req', 'aria-hidden': 'true' }, ' *') : null),
    control, o.hint ? h('div', { class: 'hint' }, o.hint) : null, h('div', { class: 'err', role: 'alert' }));
  ui.setErr = (control, msg) => {
    const f = control.closest('.field'); if (!f) return;
    f.classList.toggle('has-err', !!msg); const e = f.querySelector('.err'); if (e) e.textContent = msg || '';
  };
  ui.clearErrs = (root) => root.querySelectorAll('.field.has-err').forEach((f) => { f.classList.remove('has-err'); const e = f.querySelector('.err'); if (e) e.textContent = ''; });
  ui.fail = (control, msg) => { ui.setErr(control, msg); try { control.focus(); control.scrollIntoView({ block: 'center' }); } catch (e) { /* ignore */ } return false; };

  ui.select = (options, value, attrs = {}) => {
    const s = h('select', { class: 'input', ...attrs }, ...options.map((o) => { const v = typeof o === 'string' ? o : o.value, l = typeof o === 'string' ? o : o.label; return h('option', { value: v }, l); }));
    s.value = value == null ? '' : value; if (s.value !== (value == null ? '' : value) && options.length) s.selectedIndex = 0;
    return s;
  };
  ui.categoryOptions = (list, current, blank = '— None —') => {
    const arr = [...list]; if (current && !arr.includes(current)) arr.push(current);
    return [{ value: '', label: blank }, ...arr];
  };

  ui.empty = (icon, title, text, action) => h('div', { class: 'empty' }, h('div', { class: 'empty-ic' }, CD.icon(icon, 26)), h('h3', {}, title), text ? h('p', {}, text) : null, action || null);
  ui.pageHead = (title, sub, ...actions) => h('div', { class: 'page-head' }, h('div', {}, h('h1', {}, title), sub ? h('p', { class: 'muted' }, sub) : null), h('div', { class: 'page-actions' }, ...actions));
  ui.panel = (title, body, o = {}) => h('section', { class: 'panel' + (o.class ? ' ' + o.class : '') },
    h('div', { class: 'panel-head' }, h('h2', {}, title, o.count != null ? h('span', { class: 'count' }, o.count) : null), o.link ? h('a', { href: o.link.href, class: 'link' }, o.link.label) : null, o.actions || null),
    h('div', { class: 'panel-body' + (o.flush ? ' flush' : '') }, body));

  ui.tabs = (items, active, onChange) => h('div', { class: 'tabs', role: 'tablist' }, ...items.map((it) => h('button', { type: 'button', role: 'tab', class: 'tab' + (it.id === active ? ' active' : ''), 'aria-selected': it.id === active, onclick: () => onChange(it.id) }, it.label, it.count != null ? h('span', { class: 'count' }, it.count) : null)));
  ui.chips = (items, active, onChange) => h('div', { class: 'chips' }, ...items.map((it) => h('button', { type: 'button', class: 'chip' + (it.id === active ? ' active' : '') + (it.danger ? ' chip-danger' : ''), onclick: () => onChange(it.id) }, it.label, it.count != null ? h('span', { class: 'count' }, it.count) : null)));

  ui.phone = (p, clientId) => (p ? h('a', { class: 'tel', href: CD.telHref(p), title: 'Call ' + p, onclick: (e) => { e.stopPropagation(); if (clientId && CD.startCall) { e.preventDefault(); CD.startCall(clientId, p); } } }, p) : '');
  ui.cell = (label, ...kids) => h('td', { 'data-label': label }, ...kids);

  /* tiny popup menu anchored to a button */
  ui.menu = (anchor, items) => {
    document.querySelectorAll('.menu').forEach((m) => m.remove());
    const m = h('div', { class: 'menu', role: 'menu' }, ...items.map((it) => h('button', { type: 'button', role: 'menuitem', class: it.danger ? 'danger' : '', onclick: () => { m.remove(); it.fn(); } }, it.icon ? CD.icon(it.icon, 14) : null, it.label)));
    document.body.append(m);
    const r = anchor.getBoundingClientRect();
    const mw = m.offsetWidth, mh = m.offsetHeight;
    m.style.left = Math.max(8, Math.min(window.innerWidth - mw - 8, r.right - mw)) + 'px';
    m.style.top = (r.bottom + mh + 12 > window.innerHeight ? Math.max(8, r.top - mh - 4) : r.bottom + 4) + 'px';
    setTimeout(() => { const off = (e) => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('click', off, true); } }; document.addEventListener('click', off, true); }, 0);
  };

  /* ---------- Client picker with inline "new client" ---------- */
  ui.clientPicker = ({ clientId = '', onChange } = {}) => {
    let selected = clientId ? CD.client(clientId) : null;
    let creating = false;
    const root = h('div', { class: 'picker' });
    const q = h('input', { class: 'input', type: 'text', placeholder: 'Search client by name or phone…', autocomplete: 'off', autofocus: !selected });
    const list = h('div', { class: 'picker-list' });
    const nName = h('input', { class: 'input', placeholder: 'Full name', maxlength: 120, autocomplete: 'off' });
    const nPhone = h('input', { class: 'input', type: 'tel', inputmode: 'tel', placeholder: 'Phone number', maxlength: 25 });
    const wrapField = h('div', { class: 'field picker-field' });

    const matches = () => {
      const t = q.value.trim().toLowerCase(); const digits = t.replace(/\D/g, '');
      let arr = CD.data.clients.filter((c) => c.status !== 'Archived');
      if (t) arr = arr.filter((c) => c.name.toLowerCase().includes(t) || (c.company || '').toLowerCase().includes(t) || (digits.length >= 3 && (c.phoneNorm.includes(CD.normPhone(digits)) || (c.altNorm || '').includes(CD.normPhone(digits)) || c.phone.replace(/\D/g, '').includes(digits))));
      return arr.sort((a, b) => CD.cmp(a.name.toLowerCase(), b.name.toLowerCase()));
    };
    const select = (c) => { selected = c; creating = false; draw(); if (onChange) onChange(c); };
    const drawList = () => {
      const t = q.value.trim(); const arr = matches().slice(0, 6);
      CD.mount(list, ...arr.map((c) => h('button', { type: 'button', class: 'picker-item', onclick: () => select(c) }, h('b', {}, c.name), h('span', { class: 'muted' }, [c.phone, c.company].filter(Boolean).join(' · ')))),
        h('button', { type: 'button', class: 'picker-item picker-new', onclick: () => { creating = true; if (/^[+\d][\d\s()+-]*$/.test(t)) { nPhone.value = t; nName.value = ''; } else { nName.value = t; nPhone.value = ''; } draw(); (nName.value ? nPhone : nName).focus(); } }, CD.icon('plus', 14), t ? `Add new client “${CD.trunc(t, 30)}”` : 'Add a new client'));
    };
    function draw() {
      if (selected) {
        CD.mount(wrapField, h('div', { class: 'picker-chip' }, h('span', { class: 'avatar' }, CD.initials(selected.name)), h('div', {}, h('b', {}, selected.name), h('div', { class: 'muted small' }, [selected.phone, selected.company].filter(Boolean).join(' · '))), ui.btn('Change', { sm: true, onclick: () => { selected = null; q.value = ''; draw(); if (onChange) onChange(null); q.focus(); } })));
      } else if (creating) {
        CD.mount(wrapField, h('div', { class: 'picker-new-form' }, h('div', { class: 'row' }, ui.field('Name', nName, { required: true }), ui.field('Phone', nPhone, { required: true })), h('button', { type: 'button', class: 'link', onclick: () => { creating = false; draw(); q.focus(); } }, '← Choose an existing client instead')));
      } else {
        drawList(); CD.mount(wrapField, q, list);
      }
    }
    q.addEventListener('input', drawList);
    q.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); const m = matches(); if (m.length === 1) select(m[0]); } });
    draw();
    const lab = h('label', {}, 'Client', h('span', { class: 'req' }, ' *'));
    const err = h('div', { class: 'err', role: 'alert' });
    root.append(h('div', { class: 'field' }, lab, wrapField, err));
    return {
      el: root, isCreating: () => creating, selectedId: () => (selected ? selected.id : ''),
      /** Resolves to a saved client record, or null (with an inline error) if invalid. */
      async resolve() {
        ui.clearErrs(root);
        if (selected) return selected;
        const fieldErr = (m) => { const f = wrapField.closest('.field'); f.classList.add('has-err'); err.textContent = m; };
        if (!creating) { fieldErr('Choose a client or add a new one.'); q.focus(); return null; }
        const name = nName.value.trim(), phone = nPhone.value.trim();
        if (!name) { ui.fail(nName, 'Enter the client’s name.'); return null; }
        if (!CD.validPhone(phone)) { ui.fail(nPhone, 'Enter a valid phone number.'); return null; }
        const dup = CD.findDuplicate(phone, '');
        if (dup) {
          const use = await CD.confirm({ title: 'Client already exists', message: `${dup.name} already uses this phone number. Use that client instead?`, confirmText: 'Use existing client', cancelText: 'Go back' });
          if (use) { select(dup); return dup; } return null;
        }
        const c = await CD.saveClient({ name, phone, altPhone: '', company: '', email: '', address: '', category: '', registered: CD.today(), notes: '', status: 'Active' });
        selected = c; creating = false; draw(); return c;
      }
    };
  };
})();
