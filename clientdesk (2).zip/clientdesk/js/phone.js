/* ClientDesk — talking to the phone: start a call (then offer to log it) and import the device call history */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h, ui = CD.ui;

  /* ---------- Start a call ---------- */
  const KEY = 'cd_pending_call';
  let memPending = null;
  const getPending = () => { try { return JSON.parse(localStorage.getItem(KEY) || 'null') || memPending; } catch (e) { return memPending; } };
  const setPending = (v) => { memPending = v; try { if (v) localStorage.setItem(KEY, JSON.stringify(v)); else localStorage.removeItem(KEY); } catch (e) { /* ignore */ } };

  /** Opens the phone's dialer with the client's number ready (one tap to call). Afterwards the app offers to log the call. */
  CD.startCall = (clientId, phone) => {
    const c = CD.client(clientId); const num = phone || (c && c.phone);
    if (!num) { CD.toast('This client has no phone number.', 'error'); return; }
    setPending({ clientId, phone: num, at: Date.now(), date: CD.today(), time: CD.nowTime() });
    const a = h('a', { href: CD.telHref(num), style: { display: 'none' } }); document.body.append(a); a.click(); a.remove();
  };

  CD.checkPendingCall = () => {
    const p = getPending(); if (!p) return;
    const age = Date.now() - p.at;
    if (age < 4000) return;           // still leaving the app
    setPending(null);
    if (age > 6 * 3600e3 || !CD.client(p.clientId) || document.querySelector('.modal-overlay')) return;
    const c = CD.client(p.clientId);
    const m = CD.modal({ title: 'Log your call?', size: 'sm', body: h('div', {}, h('p', {}, `You called ${c.name} at ${CD.fmtTime(p.time)}. Add notes while it is fresh — it takes under a minute.`)),
      footer: [ui.btn('Not now', { onclick: () => m.close() }), ui.btn('Log call', { kind: 'primary', icon: 'phone', autofocus: true, onclick: () => { m.close(); CD.openCallForm({ clientId: p.clientId, date: p.date, time: p.time }); } })] });
  };
  document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(CD.checkPendingCall, 300); });
  window.addEventListener('focus', () => setTimeout(CD.checkPendingCall, 300));

  /* ---------- Import the phone's call history (Android app only) ---------- */
  CD.callTypeMap = (type, sec) => {
    const talked = sec > 0;
    switch (Number(type)) {
      case 1: return { direction: 'Incoming', outcome: 'Answered' };
      case 2: return { direction: 'Outgoing', outcome: talked ? 'Answered' : 'No answer' };
      case 3: return { direction: 'Incoming', outcome: 'No answer' };
      default: return { direction: 'Incoming', outcome: 'Other' };
    }
  };
  const fmtDur = (s) => (!s ? '' : s >= 3600 ? `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m` : s >= 60 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${s}s`);
  const TYPE = { 1: 'Incoming', 2: 'Outgoing', 3: 'Missed', 4: 'Voicemail', 5: 'Rejected', 6: 'Blocked' };

  CD.openCallLogImport = () => {
    if (!(CD.native && CD.native.isNative())) {
      const m = CD.modal({ title: 'Import from phone', size: 'sm', body: h('p', {}, 'Reading the phone’s call history is only possible in the ClientDesk Android app — web browsers do not allow it. In the browser you can still log calls manually, or start a call from ClientDesk and it will offer to log it afterwards.'), footer: [ui.btn('OK', { kind: 'primary', onclick: () => m.close() })] });
      return m;
    }
    const days = ui.select([{ value: '7', label: 'Last 7 days' }, { value: '30', label: 'Last 30 days' }, { value: '90', label: 'Last 90 days' }], '7');
    const out = h('div'); let rows = [];
    const upd = () => { const n = rows.filter((r) => r.on).length; btn.querySelector('span').textContent = n ? `Import ${n} call${n === 1 ? '' : 's'}` : 'Import selected'; btn.disabled = !n; };
    const draw = (info) => {
      if (!rows.length) return CD.mount(out, h('p', { class: 'muted' }, info || 'No new calls found in that period.'));
      CD.mount(out, h('p', { class: 'small' }, h('b', {}, rows.length), ' calls found. Calls with saved clients are ticked; tick others to add them (and their number as a new client).', info ? ' ' + info : ''),
        h('div', { class: 'table-wrap bulk' }, h('table', { class: 'tbl tbl-plain' }, h('thead', {}, h('tr', {}, h('th', {}, h('input', { type: 'checkbox', 'aria-label': 'Select all', checked: rows.every((r) => r.on), onchange: (e) => { rows.forEach((r) => { r.on = e.target.checked; }); draw(info); } })), h('th', {}, 'When'), h('th', {}, 'Who'), h('th', {}, 'Type'), h('th', {}, 'Length'))),
          h('tbody', {}, ...rows.map((r) => h('tr', {}, h('td', {}, h('input', { type: 'checkbox', checked: r.on, 'aria-label': 'Include call', onchange: (e) => { r.on = e.target.checked; upd(); } })), h('td', {}, `${CD.fmtDateShort(r.date)} ${CD.fmtTime(r.time)}`), h('td', {}, r.client ? h('b', {}, r.client.name) : h('span', {}, r.name || r.number, h('div', { class: 'muted small' }, r.name ? r.number + ' · not a saved client' : 'not a saved client'))), h('td', {}, TYPE[r.type] || 'Call'), h('td', {}, fmtDur(r.sec) || '—')))))));
      upd();
    };
    const read = async () => {
      if (!(await CD.disclose('calllog'))) return;
      try {
        const calls = await CD.native.getCalls({ since: Date.now() - Number(days.value) * 86400000, limit: 500 });
        const known = new Set(CD.data.calls.map((c) => c.extId).filter(Boolean)); let skipped = 0; rows = [];
        for (const c of calls) {
          const norm = CD.normPhone(c.number); if (!norm) continue;
          const extId = `${c.date}|${norm}`; if (known.has(extId)) { skipped++; continue; }
          const d = new Date(Number(c.date)); const client = CD.data.clients.find((x) => x.phoneNorm === norm || x.altNorm === norm) || null;
          rows.push({ extId, norm, number: c.number, name: c.name || '', type: c.type, sec: Number(c.duration) || 0, date: CD.ymd(d), time: CD.localISO(d).slice(11, 16), client, on: !!client });
        }
        draw(skipped ? `${skipped} already imported earlier were skipped.` : '');
      } catch (e) { console.error(e); CD.toast(/denied/i.test(String(e && e.message)) ? 'Permission was not granted, so the call history cannot be read. You can allow it in Android Settings → Apps → ClientDesk.' : 'Could not read the call history: ' + (e.message || e), 'error', { ms: 9000 }); }
    };
    const btn = ui.btn('Import selected', { kind: 'primary', icon: 'check', onclick: async (e) => {
      const sel = rows.filter((r) => r.on); if (!sel.length) return; e.currentTarget.disabled = true;
      try {
        const made = new Map(); let n = 0;
        await CD.batch(async () => {
          for (const r of sel) {
            let cl = r.client || made.get(r.norm);
            if (!cl) { cl = await CD.saveClient({ name: r.name || r.number, phone: r.number, altPhone: '', company: '', email: '', address: '', category: '', status: 'Active', registered: CD.today(), notes: 'Added from phone call log', demo: false }); made.set(r.norm, cl); }
            const map = CD.callTypeMap(r.type, r.sec);
            await CD.put('calls', { clientId: cl.id, date: r.date, time: r.time, direction: map.direction, outcome: map.outcome, summary: `Imported from phone call log${r.sec ? ' (talked ' + fmtDur(r.sec) + ')' : ''}. Add what was discussed.`, details: '', response: '', action: '', nextFollowUp: '', notes: '', source: 'phone', extId: r.extId, durationSec: r.sec, demo: false });
            n++;
          }
          await CD.setSetting('lastCallImport', new Date().toISOString());
        });
        CD.toast(`${CD.plural(n, 'call')} imported${made.size ? ` and ${CD.plural(made.size, 'new client')} added` : ''}. Open each one to add notes.`); m.close();
      } catch (err) { console.error(err); CD.toast('Import failed: ' + err.message, 'error'); e.currentTarget.disabled = false; }
    } });
    btn.disabled = true;
    const m = CD.modal({ title: 'Import calls from phone', size: 'lg', body: h('div', {},
      h('p', { class: 'muted small' }, 'Reads the number, date, time, duration and type of recent calls so you do not have to retype them. Never audio or messages. Only the calls you tick are saved, on this device.'),
      h('div', { class: 'row-tight mb' }, days, ui.btn('Read call history', { kind: 'primary', icon: 'phone', onclick: read })), out), footer: [ui.btn('Cancel', { onclick: () => m.close() }), btn] });
    return m;
  };
})();
