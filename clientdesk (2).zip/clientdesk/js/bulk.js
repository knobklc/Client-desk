/* ClientDesk — bulk import of numbers: pasted text, WhatsApp chat exports, Android "Share", phone contacts */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h, ui = CD.ui;

  const PREFIX = /^\s*\[?\d{1,2}[\/.]\d{1,2}[\/.]\d{2,4},?\s+\d{1,2}:\d{2}(?::\d{2})?(?:\s?[APap]\.?[Mm]\.?)?\]?\s*[-–]?\s*[^:]{1,40}:\s*/;
  const LABELS = /\b(tel|phone|mobile|contact|number|no|call|whatsapp|wa)\b\.?:?/gi;

  /** Find phone numbers (with any name text on the same line) in free text. */
  CD.parseNumbers = (text) => {
    const out = [], seen = new Set();
    for (let line of String(text || '').split(/\r?\n/)) {
      line = line.replace(PREFIX, '').trim();
      if (!line) continue;
      const re = /\+?\d[\d\s\-().]{5,24}\d/g; let m; const nums = []; let rest = line;
      while ((m = re.exec(line))) {
        const raw = m[0].trim(), digits = raw.replace(/\D/g, '');
        let parts = [];
        if (digits.length >= 9 && digits.length <= 15) parts = [raw];
        else if (digits.length > 15 && !raw.startsWith('+') && digits.length % 10 === 0 && digits[0] === '0') parts = digits.match(/.{10}/g);
        else continue;
        parts.forEach((p) => nums.push(p)); rest = rest.replace(m[0], ' ');
      }
      if (!nums.length) continue;
      const name = rest.replace(LABELS, ' ').replace(/[:;|,()\[\]–-]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);
      nums.forEach((p, i) => {
        const norm = CD.normPhone(p);
        if (!norm || seen.has(norm)) return; seen.add(norm);
        out.push({ name: i === 0 ? name : '', phone: p, dup: CD.findDuplicate(p, '') });
      });
    }
    return out;
  };

  /** Phone contacts: Android app (after disclosure + permission) or the browser's own contact picker. Returns [{name, numbers[]}] or null if cancelled. */
  CD.pickContacts = async () => {
    if (CD.native && CD.native.isNative()) { if (!(await CD.disclose('contacts'))) return null; return CD.native.getContacts(); }
    if ('contacts' in navigator && navigator.contacts && navigator.contacts.select) {
      const r = await navigator.contacts.select(['name', 'tel'], { multiple: true });
      return r.map((c) => ({ name: (c.name || [])[0] || '', numbers: c.tel || [] }));
    }
    throw new Error('This browser cannot open the phone’s contact picker. Use the Android app, or paste the numbers instead.');
  };

  CD.openBulkImport = (prefill = '') => {
    const ta = h('textarea', { class: 'input mono', rows: 5, maxlength: 200000, placeholder: 'Paste the WhatsApp messages here, one client per line.\n\nExamples:\nGrace Nakato 0772 000 111\nOkello David: +256 752 000 222\n0703 000 333', autofocus: true }, prefill);
    const file = h('input', { type: 'file', accept: '.txt,text/plain', hidden: true, onchange: async (e) => { const f = e.target.files[0]; if (!f) return; if (f.size > 5 * 1024 * 1024) { CD.toast('That file is too large.', 'error'); return; } ta.value = await f.text(); e.target.value = ''; find(); } });
    const cat = ui.select(ui.categoryOptions(CD.settings.categories, '', 'No category'), '');
    const filter = h('input', { class: 'input', type: 'search', placeholder: 'Filter the list…', 'aria-label': 'Filter list', oninput: CD.debounce(() => draw(), 120) });
    const out = h('div');
    let rows = [], searched = false;
    const setRows = (list) => { searched = true; rows = list.map((r) => ({ ...r, on: !r.dup, nameEl: h('input', { class: 'input', value: r.name, maxlength: 120, placeholder: 'Name (optional)' }) })); filter.value = ''; draw(); };
    const find = () => setRows(CD.parseNumbers(ta.value));
    const fromContacts = async () => {
      try {
        const cs = await CD.pickContacts(); if (!cs) return;
        const seen = new Set(), list = [];
        cs.forEach((c) => (c.numbers || []).forEach((n) => { n = String(n).trim(); const norm = CD.normPhone(n); if (!norm || seen.has(norm) || !CD.validPhone(n)) return; seen.add(norm); list.push({ name: c.name || '', phone: n, dup: CD.findDuplicate(n, '') }); }));
        ta.value = ''; setRows(list);
        if (!list.length) CD.toast('No phone numbers were found in the selected contacts.', 'info');
      } catch (e) { if (e && e.name !== 'AbortError') CD.toast(String(e.message || e), 'error'); }
    };
    function draw() {
      if (!searched) return CD.mount(out);
      if (!rows.length) return CD.mount(out, h('p', { class: 'muted' }, 'No phone numbers found. Numbers need at least 9 digits.'));
      const q = filter.value.trim().toLowerCase();
      const vis = rows.filter((r) => !q || (r.nameEl.value + ' ' + r.phone).toLowerCase().includes(q));
      const shown = vis.slice(0, 300), fresh = rows.filter((r) => !r.dup).length;
      CD.mount(out, h('p', { class: 'small' }, h('b', {}, rows.length), ` numbers found · ${fresh} new · ${rows.length - fresh} already saved (not selected)`), rows.length > 12 ? h('div', { class: 'mb' }, filter) : null,
        h('div', { class: 'table-wrap bulk' }, h('table', { class: 'tbl tbl-plain' }, h('thead', {}, h('tr', {}, h('th', {}, h('input', { type: 'checkbox', checked: vis.length > 0 && vis.every((r) => r.on), 'aria-label': 'Select all shown', onchange: (e) => { vis.forEach((r) => { r.on = e.target.checked; }); draw(); } })), h('th', {}, 'Name'), h('th', {}, 'Phone'), h('th', {}, 'Status'))),
          h('tbody', {}, ...shown.map((r) => h('tr', {}, h('td', {}, h('input', { type: 'checkbox', checked: r.on, 'aria-label': 'Include ' + r.phone, onchange: (e) => { r.on = e.target.checked; upd(); } })), h('td', {}, r.nameEl), h('td', { class: 'mono' }, r.phone), h('td', {}, r.dup ? h('span', { class: 'txt-danger small' }, 'Already: ' + r.dup.name) : h('span', { class: 'txt-ok small' }, 'New'))))))),
        vis.length > 300 ? h('p', { class: 'muted small' }, `Showing the first 300 of ${vis.length}. Use the filter to find others.`) : null);
      upd();
    }
    const btn = ui.btn('Import selected', { kind: 'primary', icon: 'check', onclick: async (e) => {
      const sel = rows.filter((r) => r.on); if (!sel.length) return;
      e.currentTarget.disabled = true;
      try {
        let n = 0;
        await CD.batch(async () => { for (const r of sel) { await CD.saveClient({ name: r.nameEl.value.trim() || `New client ${r.phone}`, phone: r.phone, altPhone: '', company: '', email: '', address: '', category: cat.value, status: 'Active', registered: CD.today(), notes: 'Added by bulk import', demo: false }); n++; } });
        CD.toast(`${CD.plural(n, 'client')} imported. Add names later by editing a client.`); m.close();
      } catch (err) { console.error(err); CD.toast('Import failed: ' + err.message, 'error'); e.currentTarget.disabled = false; }
    } });
    function upd() { const n = rows.filter((r) => r.on).length; btn.querySelector('span').textContent = n ? `Import ${n} selected` : 'Import selected'; btn.disabled = !n; }
    const m = CD.modal({ title: 'Import numbers', size: 'lg', body: h('div', {},
      h('div', { class: 'btn-row wrap' }, ui.btn('Pick from phone contacts', { icon: 'users', kind: 'primary', onclick: fromContacts }), h('span', { class: 'muted small' }, 'or paste numbers / load a WhatsApp chat below')),
      h('p', { class: 'muted small' }, 'WhatsApp: open the chat → ⋮ → More → Export chat → Without media, then pick the .txt file. Numbers are read on this device — nothing is uploaded.'),
      ta, h('div', { class: 'btn-row wrap' }, ui.btn('Find numbers', { icon: 'search', onclick: find }), ui.btn('Choose .txt file…', { icon: 'upload', onclick: () => file.click() }), file),
      h('div', { class: 'field' }, h('label', {}, 'Category for imported clients'), cat), out),
      footer: [ui.btn('Cancel', { onclick: () => m.close() }), btn] });
    btn.disabled = true;
    if (prefill) find();
    return m;
  };

  /* Android "Share" → ClientDesk (installed PWA): the shared text arrives as ?text= */
  CD.handleSharedText = () => {
    const q = new URLSearchParams(location.search);
    const text = [q.get('title'), q.get('text'), q.get('url')].filter(Boolean).join('\n');
    if (!text) return;
    history.replaceState(null, '', location.pathname + location.hash);
    setTimeout(() => CD.openBulkImport(text), 400);
  };
})();
