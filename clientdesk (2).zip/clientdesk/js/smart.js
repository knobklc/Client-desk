/* ClientDesk — smart suggestions after a call, WhatsApp/SMS quick replies, weekly summary */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h, ui = CD.ui;
  const val = (el) => el.value.trim();

  /* =====================================================================
     1. Reading a call note: payment / promise signals, amount and date
     ===================================================================== */
  const NEG = /\b(not|never|no|yet to|hasn'?t|haven'?t|didn'?t|did not|won'?t|unable to|couldn'?t|without|failed to)\b(\W+\w+){0,2}\W+(paid|pay|payment|sent|send|deposit(ed)?|transferred?|cleared?|settled?)\b/;
  const PAID = /\b(paid|has paid|have paid|made (the |a )?payment|payment (was )?(made|received|done|sent)|sent (the )?(money|payment|funds)|deposited|transferred|bank slip|cleared (the )?(balance|debt|invoice)|settled|fully paid|mobile money (sent|payment)|momo (sent|payment)|confirmed (the )?payment|received (the )?payment)\b/;
  const FUTURE = /\b(will|shall|promised?|promises|promising|going to|plans? to|expects? to|to (pay|send|deposit|bring|clear)|agreed to|says? (he|she|they) will|by (tomorrow|today|friday|monday|tuesday|wednesday|thursday|saturday|sunday|next week|end of)|on (friday|monday|tuesday|wednesday|thursday|saturday|sunday)|next week)\b/;
  const PAYWORD = /\b(pay|payment|deposit|send|clear|settle|balance|instalment|installment|bring|order|buy|purchase|transfer)\b/;

  CD.parseAmount = (t) => {
    const re = /(?:ugx|ush|shs?\.?|usd|\$)?\s*(\d{1,3}(?:[, ]\d{3})+|\d+(?:\.\d+)?)\s*(k\b|m\b|million|thousand)?/gi;
    let m, best = null;
    while ((m = re.exec(t))) {
      let n = Number(m[1].replace(/[, ]/g, '')); if (!isFinite(n)) continue;
      const u = (m[2] || '').toLowerCase();
      if (u === 'k' || u === 'thousand') n *= 1e3; else if (u === 'm' || u === 'million') n *= 1e6;
      const hasCur = /ugx|ush|sh|usd|\$/i.test(m[0]);
      if (n >= 1000 || (hasCur && n > 0)) { if (!best || n > best) best = n; }
    }
    return best;
  };

  const DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  CD.parseWhen = (t, base) => {
    base = base || CD.today(); t = t.toLowerCase();
    if (/\btomorrow\b/.test(t)) return CD.addDays(base, 1);
    if (/\b(today|this evening|tonight)\b/.test(t)) return base;
    let m = /\bin (\d{1,2}) days?\b/.exec(t); if (m) return CD.addDays(base, Number(m[1]));
    for (let i = 0; i < 7; i++) if (new RegExp('\\b' + DAYS[i] + '\\b').test(t)) { const cur = CD.parseYMD(base).getDay(); let diff = (i - cur + 7) % 7; if (diff === 0) diff = 7; return CD.addDays(base, diff); }
    if (/\bnext week\b/.test(t)) return CD.addDays(base, 7);
    if (/\bend of (the )?month\b/.test(t)) return CD.monthEnd(base);
    m = /\b(\d{1,2})(st|nd|rd|th)\b/.exec(t);
    if (m) { const d = Number(m[1]); if (d >= 1 && d <= 28) { const b = CD.parseYMD(base); let c = new Date(b.getFullYear(), b.getMonth(), d); if (c < b) c = new Date(b.getFullYear(), b.getMonth() + 1, d); return `${c.getFullYear()}-${String(c.getMonth() + 1).padStart(2, '0')}-${String(c.getDate()).padStart(2, '0')}`; } }
    return '';
  };

  /** Returns {paid, promise, amount, when, text} — only a hint, the user always confirms. */
  CD.analyseCall = (call) => {
    const text = [call.summary, call.response, call.details, call.action, call.notes].filter(Boolean).join('. ');
    const t = text.toLowerCase();
    const negated = NEG.test(t);
    const paid = !negated && PAID.test(t) && !/\bwill (be )?(paid|pay)\b/.test(t.replace(PAID, ' '));
    const promise = !paid && FUTURE.test(t) && PAYWORD.test(t);
    return { paid, promise, amount: CD.parseAmount(text), when: CD.parseWhen(t, call.date), text };
  };

  /* =====================================================================
     2. After a call is saved: suggest the follow-through
     ===================================================================== */
  CD.suggestAfterCall = (call, opts = {}) => {
    if (CD.settings.smartSuggestions === false || document.querySelector('.modal-overlay')) return;
    const a = CD.analyseCall(call), client = CD.client(call.clientId); if (!client) return;
    const open = CD.clientPromises(call.clientId).filter(CD.promiseOpen).sort((x, y) => CD.cmp(x.expectedDate, y.expectedDate));

    if (a.paid) {
      let chosen = open[0] || null;
      const amt = h('input', { class: 'input', type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: a.amount != null ? String(a.amount) : (chosen && CD.promiseBalance(chosen) != null ? String(CD.promiseBalance(chosen)) : '') });
      const list = h('div', { class: 'pick-list' });
      const draw = () => CD.mount(list, ...open.map((p) => h('label', { class: 'check pick-row' }, h('input', { type: 'radio', name: 'sp', checked: chosen === p, onchange: () => { chosen = p; const b = CD.promiseBalance(p); if (a.amount == null && b != null) amt.value = String(b); } }), h('span', {}, `${CD.trunc(p.description, 60)} · due ${CD.fmtDate(p.expectedDate)}${p.amount != null ? ' · balance ' + CD.money(CD.promiseBalance(p)) : ''}`))));
      draw();
      const note = `From call on ${CD.fmtDate(call.date)}: ${CD.trunc(a.text, 140)}`;
      const apply = async (full) => {
        const n = amt.value === '' ? 0 : Number(amt.value);
        if (!(n >= 0)) { CD.toast('Enter a valid amount.', 'error'); return; }
        if (chosen) {
          const bal = CD.promiseBalance(chosen);
          const done = full || (bal != null && n >= bal && n > 0);
          await CD.updatePromise(chosen, done ? { status: 'Fulfilled', amountPaid: bal != null ? Math.max(0, Math.min(n || bal, bal)) : 0, note } : { status: 'Partially Fulfilled', amountPaid: n, note });
          CD.toast(done ? 'Promise marked as fulfilled.' : 'Partial payment recorded.', 'success');
        } else {
          const rec = await CD.recordPromise({ clientId: call.clientId, callId: call.id, description: 'Payment received', dateMade: call.date, expectedDate: call.date, amount: n || null, amountFulfilled: 0, category: 'Payment', notes: '', status: 'Pending' });
          await CD.updatePromise(rec, { status: 'Fulfilled', note });
          CD.toast('Successful payment recorded.', 'success');
        }
        m.close();
      };
      const m = CD.modal({ title: 'Payment mentioned', size: 'md', body: h('div', {},
        h('p', {}, `Your note says ${client.name} has paid. Want to update the records?`),
        h('blockquote', { class: 'quote' }, CD.trunc(a.text, 200)),
        open.length ? h('div', { class: 'field' }, h('label', {}, 'Which commitment?'), list) : h('p', { class: 'muted small' }, 'There is no open commitment for this client, so this will be recorded as a completed payment.'),
        ui.field(`Amount received (${CD.settings.currency})`, amt)),
      footer: [ui.btn('Not now', { onclick: () => m.close() }), open.length ? ui.btn('Part payment', { onclick: () => apply(false) }) : null, ui.btn(open.length ? 'Mark fulfilled' : 'Record payment', { kind: 'primary', icon: 'check', onclick: () => apply(true) })] });
      return;
    }

    if (a.promise && !opts.promiseRecorded) {
      const desc = h('input', { class: 'input', maxlength: 300, value: CD.trunc(call.response || call.summary || 'Client promise', 120) });
      const due = h('input', { class: 'input', type: 'date', value: a.when || '' });
      const amt = h('input', { class: 'input', type: 'number', min: 0, step: 'any', inputmode: 'decimal', value: a.amount != null ? String(a.amount) : '' });
      const fu = h('input', { type: 'checkbox', checked: true });
      const m = CD.modal({ title: 'A promise was made?', size: 'md', body: h('div', {},
        h('p', {}, 'Your note sounds like the client promised something. Record it so ClientDesk can track it.'),
        ui.field('What was promised?', desc), h('div', { class: 'row' }, ui.field('Expected by', due, { required: true }), ui.field(`Amount (${CD.settings.currency})`, amt)),
        h('label', { class: 'check' }, fu, h('span', {}, 'Also schedule a follow-up on that date'))),
      footer: [ui.btn('Not now', { onclick: () => m.close() }), ui.btn('Record promise', { kind: 'primary', icon: 'handshake', onclick: async () => {
        if (!val(desc)) return CD.toast('Describe what was promised.', 'error');
        if (!CD.isDate(due.value)) return CD.toast('Pick the expected date.', 'error');
        await CD.batch(async () => {
          await CD.recordPromise({ clientId: call.clientId, callId: call.id, description: val(desc), dateMade: call.date, expectedDate: due.value, amount: amt.value === '' ? null : Number(amt.value), category: 'Payment', notes: '', status: 'Pending' });
          if (fu.checked) await CD.saveFollowup({ clientId: call.clientId, reason: 'Check: ' + CD.trunc(val(desc), 80), date: due.value, time: '', priority: 'Normal', status: 'Pending', relatedType: 'call', relatedId: call.id, result: '', notes: '' });
        });
        CD.toast('Promise recorded' + (fu.checked ? ' and follow-up scheduled.' : '.'), 'success'); m.close();
      } })] });
    }
  };

  /* =====================================================================
     3. WhatsApp / SMS quick replies
     ===================================================================== */
  CD.DEFAULT_TEMPLATES = [
    { id: 't1', name: 'Checking in', text: 'Hello {name}, this is {me}{org}. I am following up on our last conversation. Is this a good time to talk?' },
    { id: 't2', name: 'Payment reminder', text: 'Hello {name}, a friendly reminder about {description}{amount}, expected by {date}. Kindly confirm when it is done. Thank you.' },
    { id: 't3', name: 'Thank you for payment', text: 'Hello {name}, thank you for your payment. We have received it and appreciate your business. — {me}' },
    { id: 't4', name: 'Missed your call', text: 'Hello {name}, sorry I missed you. I will try again shortly, or call me back when you are free. — {me}' },
    { id: 't5', name: 'Confirm callback', text: 'Hello {name}, confirming that I will call you {date}. Please let me know if another time suits you better. — {me}' }
  ];
  CD.templates = () => (Array.isArray(CD.settings.templates) && CD.settings.templates.length ? CD.settings.templates : CD.DEFAULT_TEMPLATES);

  CD.fillTemplate = (text, c) => {
    const S = CD.settings;
    const p = CD.clientPromises(c.id).filter(CD.promiseOpen).sort((a, b) => CD.cmp(a.expectedDate, b.expectedDate))[0];
    const fu = CD.data.followups.filter((f) => f.clientId === c.id && CD.fuOpen(f)).sort(CD.fuSort)[0];
    const when = p ? CD.fmtDate(p.expectedDate) : fu ? CD.fmtDate(fu.date) : 'soon';
    const bal = p && CD.promiseBalance(p) ? ` (${CD.money(CD.promiseBalance(p))})` : '';
    const map = { name: (c.name || '').split(' ')[0] || c.name, fullname: c.name, me: S.userName || 'your account officer', org: S.org ? ' from ' + S.org : '', description: p ? p.description : 'our arrangement', amount: bal, date: when, company: c.company || '' };
    return text.replace(/\{(\w+)\}/g, (all, k) => (k in map ? map[k] : all)).replace(/\s+([.,!?])/g, '$1').replace(/ {2,}/g, ' ');
  };

  CD.quickReply = (clientId) => {
    const c = CD.client(clientId); if (!c) return;
    const tpls = CD.templates();
    const ta = h('textarea', { class: 'input', rows: 5, maxlength: 1500 }, CD.fillTemplate(tpls[0].text, c));
    const chips = ui.chips(tpls.map((t) => ({ id: t.id, label: t.name })), tpls[0].id, (id) => { const t = tpls.find((x) => x.id === id); ta.value = CD.fillTemplate(t.text, c); });
    const m = CD.modal({ title: 'Message ' + c.name, size: 'md', body: h('div', {}, h('p', { class: 'muted small' }, 'Pick a message, edit it if you want, then send it from your own WhatsApp or SMS. ClientDesk cannot confirm that it was sent.'), chips, ui.field('Message', ta)),
      footer: [ui.btn('Copy', { icon: 'copy', onclick: async () => { const ok = await CD.copyText(val(ta)); CD.toast(ok ? 'Message copied.' : 'Could not copy — select the text manually.', ok ? 'success' : 'error'); } }),
        ui.btn('SMS', { icon: 'msg', onclick: () => { window.location.href = `sms:${CD.normPhone(c.phone) ? '+' + CD.normPhone(c.phone) : c.phone}?body=${encodeURIComponent(val(ta))}`; } }),
        ui.btn('Open WhatsApp', { kind: 'primary', icon: 'msg', onclick: () => { if (!val(ta)) return CD.toast('Write a message first.', 'error'); window.open(CD.waHref(c.phone, val(ta)), '_blank', 'noopener'); m.close(); CD.toast('WhatsApp opened. Review and send there.', 'info'); } })] });
  };

  /* =====================================================================
     4. Weekly summary
     ===================================================================== */
  CD.openWeeklySummary = (which = 'this') => {
    const t = CD.today();
    const from = which === 'last' ? CD.addDays(CD.weekStart(t), -7) : CD.weekStart(t), to = CD.addDays(from, 6);
    const real = CD.data.calls.some((x) => !x.demo) || CD.data.promises.some((x) => !x.demo);
    const rep = CD.buildReport({ type: 'weekly', from, to, clientId: '', includeDemo: !real, include: {}, notes: '' });
    const stat = (s) => h('div', { class: 'ws-stat' + (s.warn ? ' warn' : '') }, h('b', {}, String(s.value)), h('span', {}, s.label));
    const toggle = ui.chips([{ id: 'this', label: 'This week' }, { id: 'last', label: 'Last week' }], which, (id) => { m.close(); CD.openWeeklySummary(id); });
    const text = CD.reportToText(rep, { markdown: false });
    const S = CD.settings;
    const m = CD.modal({ title: 'Weekly summary', size: 'md', body: h('div', {},
      h('p', { class: 'muted' }, rep.periodLabel), toggle,
      h('div', { class: 'ws-grid' }, ...rep.stats.slice(0, 8).map(stat)),
      rep.observations && rep.observations.length ? h('div', {}, h('h4', { class: 'sec' }, 'Highlights'), h('ul', { class: 'plain' }, ...rep.observations.slice(0, 5).map((o) => h('li', {}, o)))) : null,
      rep.actions && rep.actions.length ? h('div', {}, h('h4', { class: 'sec' }, 'Next week'), h('ul', { class: 'plain' }, ...rep.actions.slice(0, 5).map((o) => h('li', {}, o)))) : null),
    footer: [ui.btn('Full report', { onclick: () => { m.close(); location.hash = '#/reports'; } }),
      ui.btn('Share PDF', { icon: 'share', onclick: async () => { try { const r = await CD.sharePDF(rep); CD.toast(r === 'shared' ? 'PDF shared.' : r === 'cancelled' ? 'Sharing was cancelled.' : 'PDF downloaded.', 'info'); } catch (e) { CD.toast('Could not share: ' + e.message, 'error'); } } }),
      ui.btn('WhatsApp', { kind: 'primary', icon: 'msg', onclick: () => { window.open(CD.waHref(S.supervisorPhone || '', text), '_blank', 'noopener'); CD.toast('WhatsApp opened. Review and send there.', 'info'); } })] });
  };

  /** Once a week, at the chosen day/time, offer the summary. */
  CD.maybeWeeklyPrompt = () => {
    const S = CD.settings; if (S.weeklyPrompt === false || !S.onboarded || document.querySelector('.modal-overlay')) return;
    const now = new Date(), wk = CD.weekStart(CD.today());
    const day = Number(S.weeklyDay == null ? 5 : S.weeklyDay);
    if (S.lastWeeklyPrompt === wk || now.getDay() !== day || now.getHours() < 15) return;
    CD.setSetting('lastWeeklyPrompt', wk);
    const m = CD.modal({ title: 'Your week is ready', size: 'sm', body: h('p', {}, 'Your weekly summary is ready. Review it and send it to your supervisor.'), footer: [ui.btn('Later', { onclick: () => m.close() }), ui.btn('Open summary', { kind: 'primary', onclick: () => { m.close(); CD.openWeeklySummary('this'); } })] });
  };

  /* =====================================================================
     5. Settings card (called from the settings view)
     ===================================================================== */
  CD.settingsSmart = (secCard) => {
    const S = CD.settings;
    const smart = h('input', { type: 'checkbox', checked: S.smartSuggestions !== false });
    const wk = h('input', { type: 'checkbox', checked: S.weeklyPrompt !== false });
    const day = ui.select(DAYS.map((d, i) => ({ value: String(i), label: d[0].toUpperCase() + d.slice(1) })), String(S.weeklyDay == null ? 5 : S.weeklyDay));
    const tpls = CD.templates().map((t) => ({ ...t }));
    const box = h('div', { class: 'tpl-list' });
    const draw = () => CD.mount(box, ...tpls.map((t, i) => h('div', { class: 'tpl' }, h('input', { class: 'input', value: t.name, maxlength: 40, 'aria-label': 'Template name', oninput: (e) => { t.name = e.target.value; } }), h('textarea', { class: 'input', rows: 3, maxlength: 600, 'aria-label': 'Template text', oninput: (e) => { t.text = e.target.value; } }, t.text), ui.btn('Remove', { sm: true, kind: 'danger-ghost', onclick: () => { tpls.splice(i, 1); draw(); } }))));
    draw();
    return secCard('Smart assistance', 'Helpers that save typing after calls and at the end of the week. Everything is computed on this device.',
      h('label', { class: 'check' }, smart, h('span', {}, 'Suggest recording a promise or payment when my call notes mention one')),
      h('label', { class: 'check' }, wk, h('span', {}, 'Offer my weekly summary once a week (after 3 pm)')),
      ui.field('Weekly summary day', day),
      h('div', { class: 'field' }, h('label', {}, 'Quick-reply messages'), h('p', { class: 'hint' }, 'Placeholders: {name} {fullname} {me} {org} {description} {amount} {date} {company}'), box,
        ui.btn('Add message', { sm: true, icon: 'plus', onclick: () => { tpls.push({ id: 't' + Date.now(), name: 'New message', text: 'Hello {name}, ' }); draw(); } })),
      h('div', { class: 'btn-row' }, ui.btn('Save', { kind: 'primary', icon: 'check', onclick: async () => {
        const clean = tpls.filter((t) => t.name.trim() && t.text.trim()).map((t) => ({ id: t.id, name: t.name.trim(), text: t.text.trim() }));
        await CD.batch(async () => { await CD.setSetting('smartSuggestions', smart.checked); await CD.setSetting('weeklyPrompt', wk.checked); await CD.setSetting('weeklyDay', Number(day.value)); await CD.setSetting('templates', clean); });
        CD.toast('Saved.');
      } }), ui.btn('Reset messages', { onclick: async () => { await CD.setSetting('templates', []); CD.toast('Messages reset.'); CD.render(); } })));
  };
})();
