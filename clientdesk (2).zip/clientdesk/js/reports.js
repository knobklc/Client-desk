/* ClientDesk — report model builder. Every number is computed from stored records; nothing is invented. */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h;

  CD.REPORT_TYPES = [
    { id: 'daily', name: 'Daily Call Report', range: 'day' },
    { id: 'weekly', name: 'Weekly Activity Report', range: 'week' },
    { id: 'monthly', name: 'Monthly Activity Report', range: 'month' },
    { id: 'followup', name: 'Client Follow-up Report', range: 'month' },
    { id: 'outstanding', name: 'Outstanding Commitments Report', range: 'none' },
    { id: 'fulfilled', name: 'Fulfilled Commitments Report', range: 'month' },
    { id: 'client', name: 'Individual Client History', range: 'all' },
    { id: 'custom', name: 'Custom Date Range Report', range: 'week' }
  ];
  CD.reportRangeDefaults = (type) => {
    const t = CD.today(), r = CD.REPORT_TYPES.find((x) => x.id === type).range;
    if (r === 'day') return { from: t, to: t };
    if (r === 'week') return { from: CD.weekStart(t), to: CD.weekEnd(t) };
    if (r === 'month') return { from: CD.monthStart(t), to: CD.monthEnd(t) };
    return { from: '', to: '' };
  };

  const dash = (v) => (v == null || v === '' ? '—' : v);
  const named = (list, max) => list.slice(0, max).join('; ') + (list.length > max ? `; +${list.length - max} more` : '');

  CD.buildReport = (o) => {
    const S = CD.settings, today = CD.today(), now = new Date();
    const type = CD.REPORT_TYPES.find((t) => t.id === o.type);
    const inc = o.include || {};
    const from = o.from || '', to = o.to || '';
    const inRange = (d) => !!d && (!from || d >= from) && (!to || d <= to);
    const scope = (arr) => arr.filter((x) => (o.includeDemo || !x.demo) && (!o.clientId || x.clientId === o.clientId));
    const client = o.clientId ? CD.client(o.clientId) : null;

    const calls = scope(CD.data.calls).filter((c) => inRange(c.date)).sort((a, b) => CD.cmp(a.date + a.time, b.date + b.time));
    const allFU = scope(CD.data.followups), allP = scope(CD.data.promises);
    const openFU = allFU.filter(CD.fuOpen), overdueFU = openFU.filter(CD.fuOverdue), pendingFU = openFU.filter((f) => !CD.fuOverdue(f));
    const openP = allP.filter(CD.promiseOpen), overdueP = openP.filter(CD.promiseOverdue);
    const answered = calls.filter((c) => c.outcome === 'Answered').length;
    const unanswered = calls.filter((c) => CD.UNANSWERED.includes(c.outcome)).length;
    const contacted = new Set(calls.map((c) => c.clientId)).size;
    const completedFU = allFU.filter((f) => f.status === 'Completed' && inRange(f.completedDate || CD.toLocalDate(f.completedAt)));
    const fuInRange = allFU.filter((f) => inRange(f.date) || completedFU.includes(f)).sort(CD.fuSort);
    const madeP = allP.filter((p) => inRange(p.dateMade));
    const fulfilledP = allP.filter((p) => p.status === 'Fulfilled' && inRange(p.fulfilledAt));
    const asAt = `as at ${CD.fmtDate(today)}`;

    const m = {
      type: o.type, title: o.title || type.name, heading: S.reportTitle || '', orgName: S.org || '',
      generatedLabel: CD.fmtDT(today, CD.nowTime()), generatedDate: today,
      preparedBy: S.userName || '', jobTitle: S.jobTitle || '', supervisor: S.supervisor || '',
      scopeLabel: client ? `Client: ${client.name}` : 'All clients', stats: [], sections: [], observations: [], actions: [], statsFootnote: ''
    };
    m.periodLabel = type.range === 'none' ? `As at ${CD.fmtDate(today)}`
      : o.type === 'daily' && from === to ? CD.fmtDate(from)
        : (from || to) ? `${from ? CD.fmtDate(from) : 'Beginning'} – ${to ? CD.fmtDate(to) : CD.fmtDate(today)}` : 'All time';
    const usedDemo = o.includeDemo && [...calls, ...allFU, ...allP].some((x) => x.demo);
    if (usedDemo) m.demoNote = 'This report includes DEMONSTRATION records (sample data), not real client information.';

    /* row formatters */
    const callRow = (c) => [CD.fmtDateShort(c.date) + (c.time ? ' ' + CD.fmtTime(c.time) : ''), CD.clientName(c.clientId), (CD.client(c.clientId) || {}).phone || '', c.direction === 'Incoming' ? 'In' : 'Out', c.outcome, [c.summary, c.response && 'Client: ' + c.response, c.action && 'Action: ' + c.action].filter(Boolean).join(' | ')];
    const callCols = [{ label: 'Date / time', w: 13 }, { label: 'Client', w: 15 }, { label: 'Phone', w: 13 }, { label: 'Dir', w: 5 }, { label: 'Outcome', w: 11 }, { label: 'Summary, response & action', w: 43 }];
    const fuStatus = (f) => (CD.fuOverdue(f) ? 'Overdue' : f.status);
    const fuRow = (f) => [CD.fmtDateShort(f.date) + (f.time ? ' ' + CD.fmtTime(f.time) : ''), CD.clientName(f.clientId), (CD.client(f.clientId) || {}).phone || '', f.reason, f.priority, fuStatus(f), f.result || ''];
    const fuCols = [{ label: 'Scheduled', w: 12 }, { label: 'Client', w: 14 }, { label: 'Phone', w: 12 }, { label: 'Reason', w: 24 }, { label: 'Priority', w: 8 }, { label: 'Status', w: 10 }, { label: 'Result', w: 20 }];
    const pStatus = (p) => (CD.promiseOverdue(p) ? `${p.status} (Overdue)` : p.status);
    const pRow = (p) => [CD.clientName(p.clientId), p.description, CD.fmtDateShort(p.dateMade), CD.fmtDate(p.expectedDate), p.amount != null ? CD.money(p.amount) : '', pStatus(p)];
    const pCols = [{ label: 'Client', w: 16 }, { label: 'Commitment', w: 32 }, { label: 'Made', w: 9 }, { label: 'Due', w: 12 }, { label: 'Amount', w: 14, align: 'right' }, { label: 'Status', w: 17 }];

    const stat = (label, value, extra = {}) => m.stats.push({ label, value, ...extra });

    if (['daily', 'weekly', 'monthly', 'custom'].includes(o.type)) {
      stat('Total calls made', calls.length); stat('Clients contacted', contacted);
      stat('Successful calls (answered)', answered); stat('Unanswered calls', unanswered);
      stat('Follow-ups completed', completedFU.length);
      stat('Pending follow-ups*', pendingFU.length); stat('Overdue follow-ups*', overdueFU.length, { warn: overdueFU.length > 0 });
      stat('Client promises recorded', madeP.length); stat('Fulfilled commitments', fulfilledP.length);
      stat('Outstanding commitments*', openP.length, { warn: overdueP.length > 0 });
      m.statsFootnote = `* Pending, overdue and outstanding figures are ${asAt}; all other figures are for the reporting period.`;
      m.sections.push({ key: 'calls', heading: `Call log (${calls.length})`, table: { cols: callCols, rows: calls.map(callRow), empty: 'No calls were logged in this period.' } });
      m.sections.push({ key: 'followups', heading: `Follow-ups in period (${fuInRange.length})`, table: { cols: fuCols, rows: fuInRange.map(fuRow), flagCol: 5, empty: 'No follow-ups scheduled or completed in this period.' } });
      const cm = [...new Set([...madeP, ...fulfilledP])];
      m.sections.push({ key: 'commitments', heading: `Commitments recorded or fulfilled in period (${cm.length})`, table: { cols: pCols, rows: cm.map(pRow), flagCol: 5, empty: 'No commitments recorded or fulfilled in this period.' } });
    }

    if (o.type === 'followup') {
      let list = fuInRange.filter((f) => !o.status || o.status === 'All' || (o.status === 'Overdue' ? CD.fuOverdue(f) : o.status === 'Open' ? CD.fuOpen(f) : f.status === o.status));
      list = list.sort(CD.fuSort);
      stat('Follow-ups listed', list.length); stat('Completed', list.filter((f) => f.status === 'Completed').length);
      stat('Pending / rescheduled', list.filter((f) => CD.fuOpen(f) && !CD.fuOverdue(f)).length);
      stat('Overdue', list.filter(CD.fuOverdue).length, { warn: list.some(CD.fuOverdue) });
      stat('Cancelled', list.filter((f) => f.status === 'Cancelled').length);
      stat('Urgent / high priority (open)', list.filter((f) => CD.fuOpen(f) && ['Urgent', 'High'].includes(f.priority)).length);
      m.statsFootnote = `Overdue status is ${asAt}.${o.status && o.status !== 'All' ? ' Status filter: ' + o.status + '.' : ''}`;
      m.sections.push({ key: 'followups', heading: `Follow-ups (${list.length})`, table: { cols: fuCols, rows: list.map(fuRow), flagCol: 5, empty: 'No follow-ups match the selected filters.' } });
    }

    if (o.type === 'outstanding') {
      const list = openP.slice().sort((a, b) => CD.cmp(a.expectedDate, b.expectedDate));
      const bal = list.reduce((s, p) => s + (CD.promiseBalance(p) || 0), 0);
      stat('Outstanding commitments', list.length); stat('Overdue', overdueP.length, { warn: overdueP.length > 0 });
      stat('Not yet due', list.length - overdueP.length); stat('Partially fulfilled', list.filter((p) => p.status === 'Partially Fulfilled').length);
      stat('Outstanding amount', CD.money(bal), { warn: bal > 0 && overdueP.length > 0 });
      const rows = list.map((p) => [CD.clientName(p.clientId), p.description, CD.fmtDateShort(p.dateMade), CD.fmtDate(p.expectedDate), CD.promiseOverdue(p) ? CD.overdueText(p.expectedDate) : CD.relDay(p.expectedDate), p.amount != null ? CD.money(CD.promiseBalance(p)) : '', pStatus(p)]);
      m.sections.push({ key: 'commitments', heading: `Outstanding commitments (${list.length})`, table: { flagCol: 4, cols: [{ label: 'Client', w: 14 }, { label: 'Commitment', w: 27 }, { label: 'Made', w: 8 }, { label: 'Due', w: 11 }, { label: 'Timing', w: 12 }, { label: 'Balance due', w: 13, align: 'right' }, { label: 'Status', w: 15 }], rows, empty: 'There are no outstanding commitments.' } });
      m.statsFootnote = 'Open = Pending, Partially Fulfilled or Rescheduled. Statuses are never changed automatically when a date passes.';
    }

    if (o.type === 'fulfilled') {
      const list = fulfilledP.sort((a, b) => CD.cmp(a.fulfilledAt, b.fulfilledAt));
      stat('Fulfilled commitments', list.length); stat('Clients', new Set(list.map((p) => p.clientId)).size);
      stat('Total amount', CD.money(list.reduce((s, p) => s + (p.amount || 0), 0)));
      m.sections.push({ key: 'commitments', heading: `Fulfilled commitments (${list.length})`, table: { cols: [{ label: 'Client', w: 16 }, { label: 'Commitment', w: 34 }, { label: 'Due', w: 12 }, { label: 'Fulfilled', w: 12 }, { label: 'Amount', w: 14, align: 'right' }, { label: 'Category', w: 12 }], rows: list.map((p) => [CD.clientName(p.clientId), p.description, CD.fmtDate(p.expectedDate), CD.fmtDate(p.fulfilledAt), p.amount != null ? CD.money(p.amount) : '', p.category || '']), empty: 'No commitments were fulfilled in this period.' } });
    }

    if (o.type === 'client' && client) {
      const last = calls.length ? calls[calls.length - 1] : null;
      m.sections.push({ key: 'profile', heading: 'Client details', kv: [['Name', client.name], ['Phone', [client.phone, client.altPhone].filter(Boolean).join(' / ')], ['Company', client.company], ['Email', client.email], ['Address', client.address], ['Category / status', `${client.category || '—'} / ${client.status}`], ['Registered', CD.fmtDate(client.registered)], ['Notes', client.notes]] });
      stat('Calls logged', calls.length); stat('Answered', answered); stat('Unanswered', unanswered);
      stat('Last contact', last ? CD.fmtDateShort(last.date) : 'None');
      stat('Promises recorded', allP.filter((p) => inRange(p.dateMade) || !from && !to).length); stat('Fulfilled', allP.filter((p) => p.status === 'Fulfilled').length);
      stat('Outstanding', openP.length, { warn: overdueP.length > 0 }); stat('Broken', allP.filter((p) => p.status === 'Broken').length, { warn: allP.some((p) => p.status === 'Broken') });
      m.sections.push({ key: 'calls', heading: `Calls (${calls.length})`, table: { cols: callCols, rows: calls.map(callRow), empty: 'No calls recorded.' } });
      m.sections.push({ key: 'commitments', heading: `Promises & commitments (${allP.length})`, table: { cols: pCols, rows: allP.sort((a, b) => CD.cmp(a.dateMade, b.dateMade)).map(pRow), flagCol: 5, empty: 'No promises recorded.' } });
      m.sections.push({ key: 'followups', heading: `Follow-ups (${allFU.length})`, table: { cols: fuCols, rows: allFU.sort(CD.fuSort).map(fuRow), flagCol: 5, empty: 'No follow-ups.' } });
    }

    /* Auto-generated observations — statements derived strictly from the data */
    const obs = m.observations;
    if (m.sections.some((s) => s.key === 'calls')) {
      if (!calls.length) obs.push('No calls were logged in this period.');
      else {
        obs.push(`${CD.plural(calls.length, 'call')} logged to ${CD.plural(contacted, 'client')}: ${answered} answered (${Math.round((answered / calls.length) * 100)}%), ${unanswered} unanswered.`);
        const cnt = {}; calls.filter((c) => CD.UNANSWERED.includes(c.outcome)).forEach((c) => { cnt[c.clientId] = (cnt[c.clientId] || 0) + 1; });
        const rep = Object.entries(cnt).filter(([, n]) => n >= 2).map(([id, n]) => `${CD.clientName(id)} (${n})`);
        if (rep.length) obs.push(`Repeated unanswered calls: ${named(rep, 5)}.`);
        const cb = calls.filter((c) => c.outcome === 'Call back requested').length;
        if (cb) obs.push(`${CD.plural(cb, 'client')} asked to be called back.`);
      }
    }
    if (['daily', 'weekly', 'monthly', 'custom', 'outstanding', 'client'].includes(o.type) && overdueP.length)
      obs.push(`${CD.plural(overdueP.length, 'commitment')} overdue ${asAt}: ${named(overdueP.sort((a, b) => CD.cmp(a.expectedDate, b.expectedDate)).map((p) => `${CD.clientName(p.clientId)} – ${CD.trunc(p.description, 50)} (due ${CD.fmtDateShort(p.expectedDate)})`), 5)}.`);
    if (['daily', 'weekly', 'monthly', 'custom', 'followup'].includes(o.type) && overdueFU.length) obs.push(`${CD.plural(overdueFU.length, 'follow-up')} overdue ${asAt}.`);
    const brokenP = allP.filter((p) => p.status === 'Broken' && (type.range === 'none' || o.type === 'client' || inRange(CD.toLocalDate(p.updated_at))));
    if (['daily', 'weekly', 'monthly', 'custom', 'client'].includes(o.type) && brokenP.length) obs.push(`${CD.plural(brokenP.length, 'commitment')} marked as broken: ${named(brokenP.map((p) => CD.clientName(p.clientId)), 5)}.`);
    if (o.type === 'fulfilled' && m.stats[0].value === 0) obs.push('No commitments were marked fulfilled in this period.');
    if (o.type === 'outstanding' && !openP.length) obs.push('All recorded commitments have been settled or closed.');
    if (o.notes && o.notes.trim()) obs.push(`Preparer's remark: ${o.notes.trim()}`);

    /* Next actions — derived from open items and the "action required" notes */
    const act = m.actions;
    overdueFU.sort(CD.fuSort).slice(0, 8).forEach((f) => act.push(`Overdue follow-up: ${CD.clientName(f.clientId)} – ${CD.trunc(f.reason, 60)} (was due ${CD.fmtDateShort(f.date)}).`));
    const soon = pendingFU.filter((f) => f.date <= CD.addDays(today, 7)).sort(CD.fuSort);
    soon.slice(0, 8).forEach((f) => act.push(`${CD.fmtDateShort(f.date)}${f.time ? ' ' + CD.fmtTime(f.time) : ''}: follow up ${CD.clientName(f.clientId)} – ${CD.trunc(f.reason, 60)}.`));
    overdueP.slice(0, 6).forEach((p) => act.push(`Chase ${CD.clientName(p.clientId)} – ${CD.trunc(p.description, 60)} (promised ${CD.fmtDateShort(p.expectedDate)}).`));
    if (m.sections.some((s) => s.key === 'calls')) calls.filter((c) => c.action && c.action.trim()).slice(-6).forEach((c) => act.push(`${CD.clientName(c.clientId)}: ${CD.trunc(c.action, 80)}`));
    const hidden = overdueFU.length + soon.length + overdueP.length;
    if (!act.length) act.push('No outstanding actions recorded.');
    void hidden;

    /* Apply "what to include" choices */
    if (inc.stats === false) { m.stats = []; m.statsFootnote = ''; }
    m.sections = m.sections.filter((s) => s.key === 'profile' || inc[s.key] !== false);
    if (inc.observations !== false) m.sections.push({ key: 'observations', heading: 'Important observations', bullets: obs, empty: 'No observations.' });
    if (inc.actions !== false) m.sections.push({ key: 'actions', heading: 'Next actions required', bullets: act, empty: 'No outstanding actions.' });
    m.counts = { calls: calls.length };
    return m;
  };

  /* ---------- Text summary (WhatsApp / email / clipboard) ---------- */
  CD.reportToText = (m, { markdown = true } = {}) => {
    const b = (s) => (markdown ? `*${s}*` : s);
    const L = [];
    if (m.orgName) L.push(b(m.orgName));
    L.push(b(m.title));
    L.push(`Period: ${m.periodLabel}`);
    if (m.scopeLabel && m.scopeLabel !== 'All clients') L.push(m.scopeLabel);
    if (m.preparedBy) L.push(`Prepared by: ${m.preparedBy}${m.jobTitle ? ' (' + m.jobTitle + ')' : ''}`);
    if (m.demoNote) L.push('[Includes DEMONSTRATION data]');
    if (m.stats.length) { L.push('', b('Summary')); m.stats.forEach((s) => L.push(`• ${s.label.replace('*', '')}: ${s.value}`)); if (m.statsFootnote) L.push(`(Pending/overdue/outstanding figures are as at ${CD.fmtDate(m.generatedDate)}.)`); }
    for (const s of m.sections) {
      if (!s.table && !s.bullets) continue;
      L.push('', b(s.heading));
      if (s.bullets) { (s.bullets.length ? s.bullets : [s.empty || 'None']).forEach((x) => L.push(`• ${x}`)); continue; }
      const rows = s.table.rows;
      if (!rows.length) { L.push(s.table.empty || 'None'); continue; }
      rows.slice(0, 12).forEach((r) => {
        if (s.key === 'calls') L.push(`• ${r[0]} – ${r[1]}: ${r[4]}${r[5] ? ' – ' + CD.trunc(r[5], 90) : ''}`);
        else if (s.key === 'followups') L.push(`• ${r[0]} – ${r[1]}: ${CD.trunc(r[3], 60)} [${r[5]}]`);
        else L.push(`• ${r.filter(Boolean).slice(0, 5).map((x) => CD.trunc(x, 50)).join(' – ')}`);
      });
      if (rows.length > 12) L.push(`… and ${rows.length - 12} more (see the PDF).`);
    }
    return L.join('\n');
  };

  /* ---------- On-screen preview (paper-style) ---------- */
  CD.reportPreview = (m) => {
    const page = h('div', { class: 'paper' });
    page.append(h('div', { class: 'paper-top' }, h('span', {}, m.orgName), h('span', {}, 'Generated ' + m.generatedLabel)));
    if (m.heading) page.append(h('div', { class: 'paper-heading' }, m.heading));
    page.append(h('h2', { class: 'paper-title' }, m.title), h('div', { class: 'paper-period' }, m.periodLabel));
    page.append(h('div', { class: 'paper-meta' }, ...[['Prepared by', m.preparedBy], ['Job title', m.jobTitle], ['Supervisor', m.supervisor], ['Scope', m.scopeLabel]].map(([k, v]) => h('div', {}, h('small', {}, k), h('b', {}, dash(v))))));
    if (m.demoNote) page.append(h('div', { class: 'alert alert-warn' }, CD.icon('alert', 15), m.demoNote));
    if (m.stats.length) {
      page.append(h('div', { class: 'paper-stats' }, ...m.stats.map((s) => h('div', { class: 'pstat' + (s.warn ? ' warn' : '') }, h('b', {}, s.value), h('small', {}, s.label)))));
      if (m.statsFootnote) page.append(h('p', { class: 'muted small' }, m.statsFootnote));
    }
    for (const s of m.sections) {
      page.append(h('h3', { class: 'paper-h' }, s.heading));
      if (s.kv) page.append(h('dl', { class: 'kv' }, ...s.kv.flatMap(([k, v]) => [h('dt', {}, k), h('dd', {}, dash(v))])));
      if (s.table) {
        const t = s.table;
        page.append(t.rows.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl tbl-plain' },
          h('thead', {}, h('tr', {}, ...t.cols.map((c) => h('th', { style: { textAlign: c.align || 'left' } }, c.label)))),
          h('tbody', {}, ...t.rows.map((r) => h('tr', {}, ...r.map((v, i) => h('td', { class: t.flagCol === i && /overdue|broken/i.test(v) ? 'txt-danger' : '', style: { textAlign: t.cols[i].align || 'left' } }, v))))))) : h('p', { class: 'muted' }, t.empty || 'No records.'));
      }
      if (s.bullets) page.append(s.bullets.length ? h('ul', { class: 'bullets' }, ...s.bullets.map((x) => h('li', {}, x))) : h('p', { class: 'muted' }, s.empty || 'None.'));
    }
    return page;
  };

  CD.reportFileName = (m, ext) => `${CD.slug(m.orgName ? m.orgName + '-' : '')}${CD.slug(m.title)}_${m.generatedDate}.${ext}`.replace(/^-/, '');

  /* ---------- Sharing (never claims success unless the share/clipboard action actually succeeded) ---------- */
  CD.sharePDF = async (m) => {
    const blob = CD.reportToPDF(m).toBlob();
    if (CD.native && CD.native.isNative()) return CD.native.saveBlob(blob, CD.reportFileName(m, 'pdf'));
    const file = new File([blob], CD.reportFileName(m, 'pdf'), { type: 'application/pdf' });
    if (navigator.canShare && navigator.canShare({ files: [file] }) && navigator.share) {
      try { await navigator.share({ files: [file], title: m.title, text: `${m.title} – ${m.periodLabel}` }); return 'shared'; }
      catch (e) { if (e && e.name === 'AbortError') return 'cancelled'; throw e; }
    }
    CD.downloadBlob(blob, file.name);
    return 'downloaded';
  };
})();
