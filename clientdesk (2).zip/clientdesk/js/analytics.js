/* ClientDesk — Analytics: animated, dependency-free SVG/CSS charts computed from stored records.
 * Mapping used: SUCCESSFUL = fulfilled commitments / answered calls; PENDING = open commitments
 * (pending, partial, rescheduled) / call-back requested; FAILED = broken commitments / unanswered calls. */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h, ui = CD.ui;
  const AN = { range: '30', last: 0 };
  const reduce = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const raf2 = (fn) => requestAnimationFrame(() => requestAnimationFrame(fn));

  function countUp(el, to, fmt, animate) {
    const f = fmt || ((n) => Math.round(n).toLocaleString('en-US'));
    if (!animate || reduce()) { el.textContent = f(to); return; }
    const t0 = performance.now(), dur = 900; el.textContent = f(0);
    const step = (t) => { const p = Math.min(1, (t - t0) / dur); el.textContent = f(to * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(step); };
    raf2(() => requestAnimationFrame(step));
  }
  const num = (to, animate, fmt) => { const s = h('span', { class: 'an-num' }); countUp(s, to, fmt, animate); return s; };

  function donut(segs, centerValue, centerLabel, animate) {
    const NS = 'http://www.w3.org/2000/svg', total = segs.reduce((s, x) => s + x.v, 0);
    const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('viewBox', '0 0 42 42'); svg.setAttribute('class', 'an-donut'); svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', segs.map((s) => `${s.label}: ${s.v}`).join(', '));
    const mk = (cls, extra) => { const c = document.createElementNS(NS, 'circle'); c.setAttribute('cx', 21); c.setAttribute('cy', 21); c.setAttribute('r', 15.9155); c.setAttribute('fill', 'none'); c.setAttribute('stroke-width', 5); c.setAttribute('class', cls); Object.entries(extra || {}).forEach(([k, v]) => c.style.setProperty(k, v)); svg.append(c); return c; };
    mk('an-track');
    let start = 0; const arcs = [];
    if (total) segs.forEach((s) => {
      if (!s.v) return; const len = (s.v / total) * 100, c = mk('an-seg ' + s.cls);
      c.style.strokeDashoffset = String(-start); c.style.strokeDasharray = animate && !reduce() ? `0 100` : `${Math.max(0, len - 0.6)} ${100 - Math.max(0, len - 0.6)}`;
      arcs.push([c, len]); start += len;
    });
    if (animate && !reduce()) raf2(() => arcs.forEach(([c, len], i) => { c.style.transitionDelay = `${i * 120}ms`; c.style.strokeDasharray = `${Math.max(0, len - 0.6)} ${100 - Math.max(0, len - 0.6)}`; }));
    const v = h('b', { class: 'an-dv' }); countUp(v, centerValue, null, animate);
    return h('div', { class: 'an-donut-wrap' }, svg, h('div', { class: 'an-dc' }, v, h('small', {}, centerLabel)));
  }
  const legend = (items) => h('ul', { class: 'an-legend' }, ...items.map((i) => h('li', {}, h('span', { class: 'an-dot ' + i.cls }), h('span', { class: 'grow' }, i.label), h('b', {}, i.v), h('span', { class: 'muted small' }, i.pct))));
  const pct = (a, b) => (b ? Math.round((a / b) * 100) + '%' : '—');

  CD.views.analytics = () => {
    const now = performance.now(); const animate = now - AN.last > 2500; AN.last = now;
    const root = h('div', { class: 'view' });
    root.append(ui.pageHead('Analytics', 'Successful, pending and failed outcomes from your calls and commitments'));
    root.append(ui.chips([['7', 'Last 7 days'], ['30', 'Last 30 days'], ['90', 'Last 90 days'], ['all', 'All time']].map(([id, label]) => ({ id, label })), AN.range, (r) => { AN.range = r; AN.last = 0; CD.render(); }));
    const today = CD.today(), from = AN.range === 'all' ? '' : CD.addDays(today, -(Number(AN.range) - 1));
    const calls = CD.data.calls.filter((c) => !from || c.date >= from), proms = CD.data.promises.filter((p) => !from || p.dateMade >= from);

    if (!calls.length && !proms.length) { root.append(h('div', { class: 'card' }, ui.empty('chart', 'No activity in this period', 'Log calls and record promises and your results will be charted here.', ui.btn('Log a call', { kind: 'primary', sm: true, onclick: () => CD.openCallForm() })))); return root; }

    const ok = proms.filter((p) => p.status === 'Fulfilled'), bad = proms.filter((p) => p.status === 'Broken'), pend = proms.filter((p) => CD.promiseOpen(p));
    const cOk = calls.filter((c) => c.outcome === 'Answered'), cBad = calls.filter((c) => CD.UNANSWERED.includes(c.outcome)), cPend = calls.filter((c) => c.outcome === 'Call back requested');
    const sum = (arr, f) => arr.reduce((s, p) => s + (f(p) || 0), 0);
    const money = (n) => CD.money(n);
    const collected = sum(proms, (p) => p.amountFulfilled), open = sum(pend, (p) => CD.promiseBalance(p)), lost = sum(bad, (p) => CD.promiseBalance(p));
    const overdue = pend.filter(CD.promiseOverdue).length;

    /* KPI cards */
    root.append(h('div', { class: 'an-kpis' },
      ...[['Successful', ok.length, 'ok', `${pct(ok.length, proms.length)} of ${CD.plural(proms.length, 'promise')}`], ['Pending', pend.length, 'pend', overdue ? `${overdue} overdue` : 'none overdue'], ['Failed', bad.length, 'bad', `${pct(bad.length, proms.length)} broken`], ['Calls answered', cOk.length, 'ok', `${pct(cOk.length, calls.length)} of ${CD.plural(calls.length, 'call')}`]]
        .map(([l, v, k, s], i) => h('div', { class: 'an-kpi an-' + k + (animate ? ' an-in' : ''), style: { '--i': i } }, h('small', {}, l), h('div', { class: 'an-big' }, num(v, animate)), h('span', { class: 'muted small' }, s)))));

    /* Two donuts */
    const pLegend = [{ cls: 'seg-ok', label: 'Successful (fulfilled)', v: ok.length, pct: pct(ok.length, proms.length) }, { cls: 'seg-pend', label: 'Pending (open)', v: pend.length, pct: pct(pend.length, proms.length) }, { cls: 'seg-bad', label: 'Failed (broken)', v: bad.length, pct: pct(bad.length, proms.length) }];
    const cLegend = [{ cls: 'seg-ok', label: 'Successful (answered)', v: cOk.length, pct: pct(cOk.length, calls.length) }, { cls: 'seg-pend', label: 'Pending (call back requested)', v: cPend.length, pct: pct(cPend.length, calls.length) }, { cls: 'seg-bad', label: 'Failed (no answer, busy, off)', v: cBad.length, pct: pct(cBad.length, calls.length) }];
    const other = calls.length - cOk.length - cBad.length - cPend.length;
    root.append(h('div', { class: 'grid-2' },
      ui.panel('Promises & commitments', h('div', { class: 'an-split' }, donut([{ v: ok.length, cls: 'seg-ok', label: 'Successful' }, { v: pend.length, cls: 'seg-pend', label: 'Pending' }, { v: bad.length, cls: 'seg-bad', label: 'Failed' }], proms.length, 'promises', animate), legend(pLegend))),
      ui.panel('Call results', h('div', {}, h('div', { class: 'an-split' }, donut([{ v: cOk.length, cls: 'seg-ok', label: 'Successful' }, { v: cPend.length, cls: 'seg-pend', label: 'Pending' }, { v: cBad.length, cls: 'seg-bad', label: 'Failed' }], calls.length, 'calls', animate), legend(cLegend)), other > 0 ? h('p', { class: 'muted small' }, `${CD.plural(other, 'call')} with outcome “Other” not counted above.`) : null))));

    /* Trend bars */
    const days = AN.range === 'all' ? Math.max(1, CD.daysBetween(calls.reduce((m, c) => (c.date < m ? c.date : m), today), today) + 1) : Number(AN.range);
    const weekly = days > 31; const buckets = [];
    if (weekly) { let s = CD.weekStart(AN.range === 'all' ? calls.reduce((m, c) => (c.date < m ? c.date : m), today) : from); while (s <= today && buckets.length < 60) { buckets.push({ s, e: CD.addDays(s, 6), label: CD.fmtDateShort(s) }); s = CD.addDays(s, 7); } }
    else for (let i = days - 1; i >= 0; i--) { const d = CD.addDays(today, -i); buckets.push({ s: d, e: d, label: days <= 7 ? new Date(CD.parseYMD(d)).toLocaleDateString(undefined, { weekday: 'short' }) : String(CD.parseYMD(d).getDate()) }); }
    buckets.forEach((b) => { const cs = CD.data.calls.filter((c) => c.date >= b.s && c.date <= b.e); b.ok = cs.filter((c) => c.outcome === 'Answered').length; b.bad = cs.filter((c) => CD.UNANSWERED.includes(c.outcome)).length; b.pend = cs.length - b.ok - b.bad; });
    const max = Math.max(1, ...buckets.map((b) => b.ok + b.bad + b.pend));
    root.append(ui.panel(weekly ? 'Calls per week' : 'Calls per day', h('div', {}, h('div', { class: 'an-bars' + (animate ? ' an-in' : ''), style: { '--n': buckets.length } }, ...buckets.map((b, i) => h('div', { class: 'an-col', style: { '--i': i }, title: `${b.label}: ${b.ok} answered, ${b.bad} failed, ${b.pend} other/pending` },
      h('div', { class: 'an-stack', style: { height: ((b.ok + b.bad + b.pend) / max) * 100 + '%' } }, b.bad ? h('i', { class: 'seg-bad', style: { flexGrow: b.bad } }) : null, b.pend ? h('i', { class: 'seg-pend', style: { flexGrow: b.pend } }) : null, b.ok ? h('i', { class: 'seg-ok', style: { flexGrow: b.ok } }) : null),
      h('span', { class: 'an-x' }, b.label)))),
      h('div', { class: 'an-key' }, h('span', {}, h('span', { class: 'an-dot seg-ok' }), 'Successful'), h('span', {}, h('span', { class: 'an-dot seg-pend' }), 'Pending / other'), h('span', {}, h('span', { class: 'an-dot seg-bad' }), 'Failed')))));

    /* Funnel + money */
    const fun = [['Calls made', calls.length, ''], ['Answered', cOk.length, 'seg-ok'], ['Promises recorded', proms.length, 'seg-pend'], ['Promises fulfilled', ok.length, 'seg-ok']];
    root.append(h('div', { class: 'grid-2' },
      ui.panel('From call to result', h('div', { class: 'an-funnel' }, ...fun.map(([l, v, cls], i) => h('div', { class: 'an-frow' }, h('div', { class: 'an-fl' }, h('span', {}, l), h('b', {}, num(v, animate))), h('div', { class: 'an-ft' }, h('div', { class: 'an-fb ' + (cls || 'seg-info') + (animate ? ' an-in' : ''), style: { width: (calls.length || proms.length ? Math.max(v ? 2 : 0, (v / Math.max(1, calls.length, proms.length)) * 100) : 0) + '%', '--i': i } }))))),
        { }),
      ui.panel('Value of commitments', h('div', { class: 'an-money' },
        ...[['Collected so far', collected, 'ok'], ['Still outstanding', open, 'pend'], ['Lost (broken promises)', lost, 'bad']].map(([l, v, k], i) => h('div', { class: 'an-m an-' + k }, h('small', {}, l), h('b', {}, num(v, animate, (n) => money(Math.round(n))))))),
        h('p', { class: 'muted small' }, 'Amounts come from promises that have an amount recorded. Balance = amount minus payments received.'))));

    /* Needs attention */
    const per = new Map();
    CD.data.promises.forEach((p) => { if (!(CD.promiseOverdue(p) || p.status === 'Broken')) return; const o = per.get(p.clientId) || { od: 0, br: 0, bal: 0 }; if (p.status === 'Broken') o.br++; else o.od++; o.bal += CD.promiseBalance(p) || 0; per.set(p.clientId, o); });
    const worst = [...per.entries()].sort((a, b) => (b[1].od + b[1].br) - (a[1].od + a[1].br) || b[1].bal - a[1].bal).slice(0, 5);
    root.append(ui.panel('Clients needing attention', worst.length ? h('div', { class: 'list' }, ...worst.map(([id, o]) => h('button', { type: 'button', class: 'list-row', onclick: () => CD.openClientDetail(id, 'promises') }, h('div', { class: 'grow' }, h('b', {}, CD.clientName(id)), h('div', { class: 'muted small' }, [o.od ? `${o.od} overdue` : '', o.br ? `${o.br} broken` : ''].filter(Boolean).join(' · '))), o.bal ? h('b', {}, money(o.bal)) : null))) : ui.empty('check', 'No overdue or broken promises', 'Every open promise is still within its expected date.')));
    return root;
  };
})();
