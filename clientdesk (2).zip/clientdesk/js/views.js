/* ClientDesk — main screens */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h, ui = CD.ui;
  CD.VERSION = '1.4.0';
  const V = (CD.views = {});
  const val = (el) => el.value.trim();
  const act = (icon, label, fn) => ui.iconBtn(icon, label, (e) => { e.stopPropagation(); fn(e); });
  const tbl = (cols, rows) => h('div', { class: 'table-wrap' }, h('table', { class: 'tbl resp' }, h('thead', {}, h('tr', {}, ...cols.map((c) => h('th', { class: c.cls || '' }, c.label)))), h('tbody', {}, ...rows)));
  const trow = (fn, ...cells) => h('tr', { class: 'click', tabindex: 0, onclick: fn, onkeydown: (e) => { if (e.key === 'Enter' && e.target === e.currentTarget) fn(); } }, ...cells);
  const clientLink = (id) => h('button', { type: 'button', class: 'link-btn strong', onclick: (e) => { e.stopPropagation(); CD.openClientDetail(id); } }, CD.clientName(id));
  const askText = (title, label, value = '') => new Promise((resolve) => {
    const inp = h('input', { class: 'input', value, maxlength: 60, autofocus: true });
    let done = false; const fin = (v) => { if (done) return; done = true; resolve(v); m.close(); };
    const m = CD.modal({ title, size: 'sm', body: h('form', { class: 'form', onsubmit: (e) => { e.preventDefault(); fin(val(inp)); } }, ui.field(label, inp)), footer: [ui.btn('Cancel', { onclick: () => fin(null) }), ui.btn('Save', { kind: 'primary', onclick: () => fin(val(inp)) })], onClose: () => fin(null) });
  });

  /* =============== DASHBOARD =============== */
  V.dashboard = () => {
    const st = CD.stats(), today = CD.today(), d = CD.data;
    const root = h('div', { class: 'view' });
    root.append(ui.pageHead('Dashboard', `${new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}${CD.settings.userName ? ' · ' + CD.settings.userName : ''}`));

    if (CD.hasDemo()) root.append(h('div', { class: 'alert alert-warn' }, CD.icon('info', 16), h('span', {}, 'Demonstration data is loaded. Items marked DEMO are samples, not real clients.'), ui.btn('Remove demo data', { sm: true, onclick: removeDemo })));
    const days = Number(CD.settings.backupReminderDays) || 0;
    if (days && d.clients.length) {
      const last = CD.settings.lastBackupAt;
      const age = last ? Math.floor((Date.now() - new Date(last)) / 86400000) : Infinity;
      if (age >= days) root.append(h('div', { class: 'alert alert-info' }, CD.icon('download', 16), h('span', {}, last ? `Your last backup was ${age} day${age === 1 ? '' : 's'} ago.` : 'You have not backed up your data yet. Data lives only in this browser.'), ui.btn('Back up now', { sm: true, onclick: () => CD.exportBackup() })));
    }

    root.append(h('div', { class: 'tiles' },
      tile('Total clients', st.totalClients, `${st.activeClients} active`, '#/clients'),
      tile('Calls today', st.callsToday, '', '#/calls'),
      tile('Calls this week', st.callsWeek, '', '#/calls'),
      tile('Pending follow-ups', st.fuPending, 'not yet due', '#/followups'),
      tile('Overdue follow-ups', st.fuOverdue, '', '#/followups', st.fuOverdue > 0 ? 'bad' : ''),
      tile('Outstanding promises', st.promOutstanding, st.promOverdue ? `${st.promOverdue} overdue` : 'none overdue', '#/promises', st.promOverdue > 0 ? 'warn' : ''),
      tile('Fulfilled promises', st.promFulfilled, '', '#/promises', 'good')));

    root.append(h('section', { class: 'quick' }, h('span', { class: 'quick-l' }, 'Quick actions'),
      ui.btn('Add new client', { icon: 'plus', onclick: () => CD.openClientForm() }),
      ui.btn('Log a call', { icon: 'phone', kind: 'primary', onclick: () => CD.openCallForm() }),
      ui.btn('Schedule follow-up', { icon: 'calendar', onclick: () => CD.openFollowupForm() }),
      ui.btn('Record a promise', { icon: 'handshake', onclick: () => CD.openPromiseForm() }),
      ui.btn('Weekly summary', { icon: 'chart', onclick: () => CD.openWeeklySummary('this') }),
      ui.btn('Generate report', { icon: 'file', onclick: () => { location.hash = '#/reports'; } })));

    /* A. Today's follow-ups (due today + overdue) */
    const fus = d.followups.filter((f) => CD.fuOpen(f) && f.date <= today).sort(CD.fuSort);
    const A = fus.length ? h('div', { class: 'list' }, ...fus.slice(0, 8).map((f) => h('div', { class: 'list-row' },
      h('div', { class: 'grow' }, h('div', {}, clientLink(f.clientId), ' ', ui.demoTag(f)), h('div', { class: 'muted small' }, CD.trunc(f.reason, 70)), h('div', { class: 'small ' + (CD.fuOverdue(f) ? 'txt-danger' : 'muted') }, CD.fuOverdue(f) ? (f.date < today ? CD.overdueText(f.date) : 'Overdue · ' + CD.fmtTime(f.time)) : 'Today' + (f.time ? ' · ' + CD.fmtTime(f.time) : ''))),
      h('div', { class: 'row-acts' }, ui.prioBadge(f.priority), (CD.client(f.clientId) || {}).phone ? act('phone', 'Call', () => CD.startCall(f.clientId)) : null, act('check', 'Complete', () => CD.completeFollowup(f)))))) : ui.empty('check', 'Nothing due today', 'No follow-ups are due or overdue. Schedule one after your next call.', ui.btn('Schedule follow-up', { sm: true, onclick: () => CD.openFollowupForm() }));

    /* B. Overdue commitments */
    const op = d.promises.filter(CD.promiseOverdue).sort((a, b) => CD.cmp(a.expectedDate, b.expectedDate));
    const B = op.length ? h('div', { class: 'list' }, ...op.slice(0, 8).map((p) => h('button', { type: 'button', class: 'list-row', onclick: () => CD.openPromiseDetail(p.id) },
      h('div', { class: 'grow' }, h('div', {}, h('b', {}, CD.clientName(p.clientId)), ' ', ui.demoTag(p)), h('div', { class: 'muted small' }, CD.trunc(p.description, 70)), h('div', { class: 'txt-danger small' }, `${CD.overdueText(p.expectedDate)} · was due ${CD.fmtDateShort(p.expectedDate)}`)),
      h('div', { class: 'right' }, p.amount != null ? h('b', {}, CD.money(CD.promiseBalance(p))) : null, ui.badge(p.status, p.status === 'Pending' ? 'info' : 'warn'))))) : ui.empty('shield', 'No overdue commitments', 'Promises that pass their expected date without being fulfilled will appear here.');

    /* C. Recent calls */
    const rc = d.calls.slice().sort((a, b) => CD.cmp(b.date + (b.time || ''), a.date + (a.time || ''))).slice(0, 7);
    const C = rc.length ? h('div', { class: 'list' }, ...rc.map((c) => h('button', { type: 'button', class: 'list-row', onclick: () => CD.openCallDetail(c.id) },
      h('div', { class: 'grow' }, h('div', {}, h('b', {}, CD.clientName(c.clientId)), ' ', ui.demoTag(c)), h('div', { class: 'muted small' }, CD.trunc(c.summary || '(no summary)', 80))),
      h('div', { class: 'right' }, ui.outcomeBadge(c.outcome), h('div', { class: 'muted small' }, `${CD.relDay(c.date) === 'Today' ? '' : CD.fmtDateShort(c.date) + ' '}${CD.fmtTime(c.time)}`))))) : ui.empty('phone', 'No calls logged yet', 'Log a call right after you speak with a client.', ui.btn('Log a call', { kind: 'primary', sm: true, onclick: () => CD.openCallForm() }));

    /* D. Upcoming reminders */
    const rem = d.reminders.filter((r) => !r.done).sort((a, b) => CD.cmp(CD.localISO(CD.remDue(a)), CD.localISO(CD.remDue(b)))).slice(0, 6);
    const D = rem.length ? h('div', { class: 'list' }, ...rem.map((r) => h('div', { class: 'list-row' }, h('div', { class: 'grow' }, h('div', {}, h('b', {}, r.title)), r.note ? h('div', { class: 'muted small' }, CD.trunc(r.note, 70)) : null), h('div', { class: 'right ' + (CD.remOverdue(r) ? 'txt-danger' : 'muted') }, h('div', { class: 'small' }, CD.remOverdue(r) ? 'Overdue' : CD.relDay(r.date)), h('div', { class: 'small' }, CD.fmtDateShort(r.date) + ' ' + CD.fmtTime(r.time)))))) : ui.empty('bell', 'No upcoming reminders', 'Follow-ups and promise due dates create reminders automatically.');

    root.append(h('div', { class: 'grid-2' },
      ui.panel('Today’s Follow-ups', A, { count: fus.length, link: { href: '#/followups', label: 'View all' } }),
      ui.panel('Overdue Commitments', B, { count: op.length, link: { href: '#/promises', label: 'View all' } }),
      ui.panel('Recent Call Activity', C, { link: { href: '#/calls', label: 'View all' } }),
      ui.panel('Upcoming Reminders', D, { link: { href: '#/reminders', label: 'Open reminders' } })));
    return root;
  };
  function tile(label, value, sub, href, kind) {
    return h('a', { class: 'tile' + (kind ? ' tile-' + kind : ''), href }, h('div', { class: 'tile-l' }, label), h('div', { class: 'tile-v' }, value), h('div', { class: 'tile-s' }, sub || ' '));
  }
  async function removeDemo() {
    if (!(await CD.confirm({ title: 'Remove demonstration data?', message: 'Only records marked DEMO are removed. Your real clients and records are not touched.', confirmText: 'Remove demo data', danger: true }))) return;
    await CD.removeDemoData(); CD.toast('Demonstration data removed.');
  }
  CD.removeDemo = removeDemo;

  /* =============== CLIENTS =============== */
  const CV = { q: '', cat: '', status: 'live' };
  V.clients = () => {
    const root = h('div', { class: 'view' });
    root.append(ui.pageHead('Clients', 'Everyone you speak with, with full history', ui.btn('Import numbers', { icon: 'upload', onclick: () => CD.openBulkImport() }), ui.btn('Add client', { icon: 'plus', kind: 'primary', onclick: () => CD.openClientForm() })));
    const q = h('input', { class: 'input', type: 'search', placeholder: 'Search by name or phone…', value: CV.q, 'aria-label': 'Search clients' });
    const cat = ui.select([{ value: '', label: 'All categories' }, ...CD.settings.categories], CV.cat, { 'aria-label': 'Category', onchange: (e) => { CV.cat = e.target.value; draw(); } });
    const stt = ui.select([{ value: 'live', label: 'Active & inactive' }, 'Active', 'Inactive', 'Archived', { value: 'all', label: 'All (incl. archived)' }], CV.status, { 'aria-label': 'Status', onchange: (e) => { CV.status = e.target.value; draw(); } });
    q.addEventListener('input', CD.debounce(() => { CV.q = q.value; draw(); }, 120));
    root.append(h('div', { class: 'toolbar' }, h('div', { class: 'search' }, CD.icon('search', 16), q), cat, stt));
    const out = h('div'); root.append(h('div', { class: 'card flush' }, out));
    function draw() {
      const t = CV.q.trim().toLowerCase(), digits = t.replace(/\D/g, '');
      let list = CD.data.clients.filter((c) => (CV.status === 'all' ? true : CV.status === 'live' ? c.status !== 'Archived' : c.status === CV.status) && (!CV.cat || c.category === CV.cat)
        && (!t || c.name.toLowerCase().includes(t) || (c.company || '').toLowerCase().includes(t) || (digits.length >= 3 && ((c.phone + ' ' + (c.altPhone || '')).replace(/\D/g, '').includes(digits) || c.phoneNorm.includes(CD.normPhone(digits))))));
      list.sort((a, b) => CD.cmp(a.name.toLowerCase(), b.name.toLowerCase()));
      if (!CD.data.clients.length) return CD.mount(out, ui.empty('users', 'No clients yet', 'Add your first client — only a name and phone number are needed. You can also load demonstration data from Settings.', ui.btn('Add client', { kind: 'primary', icon: 'plus', onclick: () => CD.openClientForm() })));
      if (!list.length) return CD.mount(out, ui.empty('search', 'No clients match', 'Try a different name or number, or clear the filters.', ui.btn('Clear filters', { sm: true, onclick: () => { CV.q = ''; CV.cat = ''; CV.status = 'live'; CD.render(); } })));
      const last = new Map(), next = new Map(), prom = new Map();
      CD.data.calls.forEach((c) => { const l = last.get(c.clientId); if (!l || c.date + c.time > l.date + l.time) last.set(c.clientId, c); });
      CD.data.followups.filter(CD.fuOpen).forEach((f) => { const n = next.get(f.clientId); if (!n || CD.fuSort(f, n) < 0) next.set(f.clientId, f); });
      CD.data.promises.filter(CD.promiseOpen).forEach((p) => { const o = prom.get(p.clientId) || { n: 0, od: 0 }; o.n++; if (CD.promiseOverdue(p)) o.od++; prom.set(p.clientId, o); });
      const rows = list.map((c) => { const l = last.get(c.id), n = next.get(c.id), p = prom.get(c.id);
        return trow(() => CD.openClientDetail(c.id),
          ui.cell('Client', h('div', { class: 'cl-cell' }, h('span', { class: 'avatar' }, CD.initials(c.name)), h('div', {}, h('b', {}, c.name, ' ', ui.demoTag(c)), c.company ? h('div', { class: 'muted small' }, c.company) : null))),
          ui.cell('Phone', ui.phone(c.phone, c.id)), ui.cell('Category', c.category || '—'), ui.cell('Status', ui.clientStatusBadge(c.status)),
          ui.cell('Open promises', p ? h('span', { class: p.od ? 'txt-danger' : '' }, p.n + (p.od ? ` (${p.od} overdue)` : '')) : '—'),
          ui.cell('Next follow-up', n ? h('span', { class: CD.fuOverdue(n) ? 'txt-danger' : '' }, CD.fmtDateShort(n.date)) : '—'),
          ui.cell('Last call', l ? CD.fmtDateShort(l.date) : '—'),
          h('td', { class: 'acts', 'data-label': '' }, act('phone', 'Log call', () => CD.openCallForm({ clientId: c.id })), act('edit', 'Edit', () => CD.openClientForm({ client: c }))));
      });
      CD.mount(out, tbl([{ label: 'Client' }, { label: 'Phone' }, { label: 'Category' }, { label: 'Status' }, { label: 'Open promises' }, { label: 'Next follow-up' }, { label: 'Last call' }, { label: '', cls: 'acts' }], rows), h('div', { class: 'tbl-foot' }, `${CD.plural(list.length, 'client')} shown`));
    }
    draw();
    return root;
  };

  /* =============== CALL LOGS =============== */
  const CL = { q: '', outcome: '', dir: '', range: 'all', from: '', to: '' };
  V.calls = () => {
    const root = h('div', { class: 'view' });
    root.append(ui.pageHead('Call Logs', 'Every conversation, newest first', ui.btn('Import from phone', { icon: 'download', onclick: () => CD.openCallLogImport() }), ui.btn('Log a call', { icon: 'phone', kind: 'primary', onclick: () => CD.openCallForm() })));
    const q = h('input', { class: 'input', type: 'search', placeholder: 'Search client, phone or notes…', value: CL.q, 'aria-label': 'Search calls' });
    q.addEventListener('input', CD.debounce(() => { CL.q = q.value; draw(); }, 120));
    const from = h('input', { class: 'input', type: 'date', value: CL.from, 'aria-label': 'From date', onchange: (e) => { CL.from = e.target.value; CL.range = 'custom'; CD.render(); } });
    const to = h('input', { class: 'input', type: 'date', value: CL.to, 'aria-label': 'To date', onchange: (e) => { CL.to = e.target.value; CL.range = 'custom'; CD.render(); } });
    const setRange = (r) => { const t = CD.today(); CL.range = r; [CL.from, CL.to] = r === 'today' ? [t, t] : r === 'week' ? [CD.weekStart(t), CD.weekEnd(t)] : r === 'month' ? [CD.monthStart(t), CD.monthEnd(t)] : ['', '']; CD.render(); };
    root.append(h('div', { class: 'toolbar' }, h('div', { class: 'search' }, CD.icon('search', 16), q),
      ui.select([{ value: '', label: 'All outcomes' }, ...CD.OUTCOMES], CL.outcome, { 'aria-label': 'Outcome', onchange: (e) => { CL.outcome = e.target.value; draw(); } }),
      ui.select([{ value: '', label: 'Incoming & outgoing' }, 'Outgoing', 'Incoming'], CL.dir, { 'aria-label': 'Direction', onchange: (e) => { CL.dir = e.target.value; draw(); } })),
      h('div', { class: 'toolbar' }, ui.chips([{ id: 'all', label: 'All time' }, { id: 'today', label: 'Today' }, { id: 'week', label: 'This week' }, { id: 'month', label: 'This month' }], CL.range, setRange), h('div', { class: 'date-range' }, from, h('span', { class: 'muted' }, 'to'), to)));
    const out = h('div'); root.append(h('div', { class: 'card flush' }, out));
    function draw() {
      const t = CL.q.trim().toLowerCase();
      const list = CD.data.calls.filter((c) => (!CL.outcome || c.outcome === CL.outcome) && (!CL.dir || c.direction === CL.dir) && (!CL.from || c.date >= CL.from) && (!CL.to || c.date <= CL.to)
        && (!t || [CD.clientName(c.clientId), (CD.client(c.clientId) || {}).phone, c.summary, c.details, c.response, c.action, c.notes].join(' ').toLowerCase().includes(t)))
        .sort((a, b) => CD.cmp(b.date + (b.time || ''), a.date + (a.time || '')));
      if (!CD.data.calls.length) return CD.mount(out, ui.empty('phone', 'No calls logged yet', 'Press “Log a call” right after talking to a client. It takes under a minute and appears in that client’s history automatically.', ui.btn('Log your first call', { kind: 'primary', icon: 'phone', onclick: () => CD.openCallForm() })));
      if (!list.length) return CD.mount(out, ui.empty('search', 'No calls match your filters', 'Change the date range, outcome or search text.'));
      CD.mount(out, tbl([{ label: 'Date & time' }, { label: 'Client' }, { label: 'Direction' }, { label: 'Outcome' }, { label: 'Summary' }, { label: 'Follow-up' }, { label: '', cls: 'acts' }],
        list.slice(0, 300).map((c) => trow(() => CD.openCallDetail(c.id),
          ui.cell('Date & time', h('div', {}, CD.fmtDateShort(c.date), h('div', { class: 'muted small' }, CD.fmtTime(c.time)))),
          ui.cell('Client', clientLink(c.clientId), ' ', ui.demoTag(c)), ui.cell('Direction', c.direction), ui.cell('Outcome', ui.outcomeBadge(c.outcome)),
          ui.cell('Summary', h('span', { class: 'clamp' }, c.summary || '—')), ui.cell('Follow-up', c.nextFollowUp ? CD.fmtDateShort(c.nextFollowUp) : '—'),
          h('td', { class: 'acts' }, act('edit', 'Edit call', () => CD.openCallForm({ call: c }))))))
        , h('div', { class: 'tbl-foot' }, `${CD.plural(list.length, 'call')}${list.length > 300 ? ' (showing the latest 300 — narrow the date range to see others)' : ''}`));
    }
    draw();
    return root;
  };

  /* =============== FOLLOW-UPS =============== */
  const FV = { tab: 'today', q: '' };
  V.followups = () => {
    const root = h('div', { class: 'view' });
    root.append(ui.pageHead('Follow-ups', 'Scheduled calls and checks, with automatic overdue flags', ui.btn('Schedule follow-up', { icon: 'plus', kind: 'primary', onclick: () => CD.openFollowupForm() })));
    const today = CD.today(), tm = CD.addDays(today, 1), ws = CD.weekStart(today), we = CD.weekEnd(today);
    const all = CD.data.followups;
    const filters = {
      today: (f) => CD.fuOpen(f) && f.date <= today && (f.date === today || CD.fuOverdue(f)),
      tomorrow: (f) => CD.fuOpen(f) && f.date === tm,
      week: (f) => CD.fuOpen(f) && f.date >= ws && f.date <= we,
      overdue: CD.fuOverdue, completed: (f) => f.status === 'Completed', all: () => true
    };
    const tabs = [['today', 'Today'], ['tomorrow', 'Tomorrow'], ['week', 'This week'], ['overdue', 'Overdue'], ['completed', 'Completed'], ['all', 'All follow-ups']].map(([id, label]) => ({ id, label, count: all.filter(filters[id]).length, danger: id === 'overdue' && all.some(CD.fuOverdue) }));
    root.append(ui.chips(tabs, FV.tab, (t) => { FV.tab = t; CD.render(); }));
    const q = h('input', { class: 'input', type: 'search', placeholder: 'Search client, phone or reason…', value: FV.q, 'aria-label': 'Search follow-ups' });
    q.addEventListener('input', CD.debounce(() => { FV.q = q.value; draw(); }, 120));
    root.append(h('div', { class: 'toolbar' }, h('div', { class: 'search' }, CD.icon('search', 16), q)));
    const out = h('div'); root.append(h('div', { class: 'card flush' }, out));
    function draw() {
      const t = FV.q.trim().toLowerCase();
      let list = all.filter(filters[FV.tab]).filter((f) => !t || [CD.clientName(f.clientId), (CD.client(f.clientId) || {}).phone, f.reason].join(' ').toLowerCase().includes(t));
      list = FV.tab === 'completed' ? list.sort((a, b) => CD.cmp(b.completedAt || b.date, a.completedAt || a.date)) : FV.tab === 'all' ? list.sort((a, b) => CD.cmp(b.date, a.date)) : list.sort(CD.fuSort);
      if (!list.length) {
        const msg = { today: ['check', 'Nothing due today', 'No follow-ups are due today or overdue.'], tomorrow: ['calendar', 'Nothing scheduled for tomorrow', ''], week: ['calendar', 'No follow-ups this week', ''], overdue: ['check', 'No overdue follow-ups', 'Great — nothing has been missed.'], completed: ['check', 'No completed follow-ups yet', 'Completed follow-ups and their results appear here.'], all: ['calendar', 'No follow-ups yet', 'Schedule a follow-up from a call, a promise, or here.'] }[FV.tab];
        return CD.mount(out, ui.empty(msg[0], msg[1], t ? 'Nothing matches your search.' : msg[2], ui.btn('Schedule follow-up', { sm: true, onclick: () => CD.openFollowupForm() })));
      }
      CD.mount(out, tbl([{ label: 'Scheduled' }, { label: 'Client' }, { label: 'Phone' }, { label: 'Reason' }, { label: 'Priority' }, { label: 'Status' }, { label: 'Related' }, { label: '', cls: 'acts' }],
        list.map((f) => { const cl = CD.client(f.clientId); const rel = f.relatedType === 'call' ? CD.byId('calls', f.relatedId) : f.relatedType === 'promise' ? CD.byId('promises', f.relatedId) : null;
          return trow(() => CD.openFollowupForm({ followup: f }),
            ui.cell('Scheduled', h('div', { class: CD.fuOverdue(f) ? 'txt-danger' : '' }, h('b', {}, CD.fmtDateShort(f.date)), h('div', { class: 'small' }, f.time ? CD.fmtTime(f.time) : CD.relDay(f.date)))),
            ui.cell('Client', clientLink(f.clientId), ' ', ui.demoTag(f)), ui.cell('Phone', cl ? ui.phone(cl.phone, cl.id) : ''),
            ui.cell('Reason', h('div', {}, f.reason, f.result ? h('div', { class: 'muted small' }, 'Result: ' + CD.trunc(f.result, 80)) : null)), ui.cell('Priority', ui.prioBadge(f.priority)),
            ui.cell('Status', h('div', { class: 'badges' }, ...ui.fuBadges(f))), ui.cell('Related', rel ? (f.relatedType === 'call' ? `Call ${CD.fmtDateShort(rel.date)}` : 'Promise: ' + CD.trunc(rel.description, 28)) : '—'),
            h('td', { class: 'acts' }, ...(CD.fuOpen(f) ? [act('check', 'Mark completed', () => CD.completeFollowup(f)), act('calendar', 'Reschedule', () => CD.rescheduleFollowup(f))] : []),
              act('more', 'More', (e) => ui.menu(e.currentTarget, [{ label: 'Edit', icon: 'edit', fn: () => CD.openFollowupForm({ followup: f }) }, ...(CD.fuOpen(f) ? [{ label: 'Cancel follow-up', icon: 'x', fn: () => CD.cancelFollowup(f) }] : []), { label: 'Delete', icon: 'trash', danger: true, fn: () => CD.deleteFollowup(f) }]))));
        })), h('div', { class: 'tbl-foot' }, CD.plural(list.length, 'follow-up')));
    }
    draw();
    return root;
  };

  /* =============== PROMISES =============== */
  const PV = { tab: 'outstanding', q: '', cat: '' };
  V.promises = () => {
    const root = h('div', { class: 'view' });
    root.append(ui.pageHead('Promises & Commitments', 'What clients said they would do — and whether they did it', ui.btn('Record promise', { icon: 'plus', kind: 'primary', onclick: () => CD.openPromiseForm() })));
    const all = CD.data.promises;
    const filters = { outstanding: CD.promiseOpen, overdue: CD.promiseOverdue, fulfilled: (p) => p.status === 'Fulfilled', broken: (p) => p.status === 'Broken', all: () => true };
    root.append(ui.chips([['outstanding', 'Outstanding'], ['overdue', 'Overdue'], ['fulfilled', 'Fulfilled'], ['broken', 'Broken'], ['all', 'All']].map(([id, label]) => ({ id, label, count: all.filter(filters[id]).length, danger: id === 'overdue' && all.some(CD.promiseOverdue) })), PV.tab, (t) => { PV.tab = t; CD.render(); }));
    const q = h('input', { class: 'input', type: 'search', placeholder: 'Search client or commitment…', value: PV.q, 'aria-label': 'Search promises' });
    q.addEventListener('input', CD.debounce(() => { PV.q = q.value; draw(); }, 120));
    root.append(h('div', { class: 'toolbar' }, h('div', { class: 'search' }, CD.icon('search', 16), q), ui.select([{ value: '', label: 'All categories' }, ...CD.settings.promiseCategories], PV.cat, { 'aria-label': 'Category', onchange: (e) => { PV.cat = e.target.value; draw(); } })));
    const out = h('div'); root.append(h('div', { class: 'card flush' }, out));
    function draw() {
      const t = PV.q.trim().toLowerCase();
      const list = all.filter(filters[PV.tab]).filter((p) => (!PV.cat || p.category === PV.cat) && (!t || (CD.clientName(p.clientId) + ' ' + p.description).toLowerCase().includes(t)))
        .sort((a, b) => (PV.tab === 'fulfilled' ? CD.cmp(b.fulfilledAt || '', a.fulfilledAt || '') : CD.cmp(a.expectedDate, b.expectedDate)));
      if (!list.length) return CD.mount(out, ui.empty('shield', all.length ? 'Nothing in this view' : 'No promises recorded yet', all.length ? 'Try another tab or clear the search.' : 'When a client promises to pay, send documents or call back, record it here or from the call form so you can follow it up.', ui.btn('Record a promise', { sm: true, kind: 'primary', onclick: () => CD.openPromiseForm() })));
      const bal = list.filter(CD.promiseOpen).reduce((s, p) => s + (CD.promiseBalance(p) || 0), 0);
      CD.mount(out, tbl([{ label: 'Client' }, { label: 'Commitment' }, { label: 'Made' }, { label: 'Expected' }, { label: 'Amount' }, { label: 'Category' }, { label: 'Status' }, { label: '', cls: 'acts' }],
        list.map((p) => trow(() => CD.openPromiseDetail(p.id),
          ui.cell('Client', clientLink(p.clientId), ' ', ui.demoTag(p)), ui.cell('Commitment', h('span', { class: 'clamp' }, p.description)), ui.cell('Made', CD.fmtDateShort(p.dateMade)),
          ui.cell('Expected', h('div', { class: CD.promiseOverdue(p) ? 'txt-danger' : '' }, CD.fmtDateShort(p.expectedDate), h('div', { class: 'small' }, CD.promiseOpen(p) ? (CD.promiseOverdue(p) ? CD.overdueText(p.expectedDate) : CD.relDay(p.expectedDate)) : ''))),
          ui.cell('Amount', p.amount != null ? h('div', {}, CD.money(p.amount), p.amountFulfilled ? h('div', { class: 'muted small' }, 'paid ' + CD.money(p.amountFulfilled)) : null) : '—'), ui.cell('Category', p.category || '—'),
          ui.cell('Status', h('div', { class: 'badges' }, ...ui.promiseBadges(p))), h('td', { class: 'acts' }, act('edit', 'Update promise', () => CD.openPromiseDetail(p.id)))))),
        h('div', { class: 'tbl-foot' }, `${CD.plural(list.length, 'promise')}${bal > 0 ? ` · outstanding balance in this list: ${CD.money(bal)}` : ''}`));
    }
    draw();
    return root;
  };

  /* =============== REPORTS =============== */
  const RV = { type: 'daily', from: CD.today(), to: CD.today(), clientId: '', status: 'All', includeDemo: null, include: {}, notes: '', model: null };
  const KEYS = { daily: ['stats', 'calls', 'followups', 'commitments', 'observations', 'actions'], followup: ['stats', 'followups', 'observations', 'actions'], outstanding: ['stats', 'commitments', 'observations', 'actions'], fulfilled: ['stats', 'commitments', 'observations', 'actions'], client: ['stats', 'calls', 'commitments', 'followups', 'observations', 'actions'] };
  const KEYLABEL = { stats: 'Summary statistics', calls: 'Call details', followups: 'Follow-ups', commitments: 'Commitments', observations: 'Important observations', actions: 'Next actions' };
  const keysFor = (type) => KEYS[type] || KEYS.daily;
  const hasReal = () => CD.data.clients.some((c) => !c.demo);
  const buildNow = () => {
    const include = {}; keysFor(RV.type).forEach((k) => { include[k] = RV.include[k] !== false; });
    return CD.buildReport({ type: RV.type, from: RV.from, to: RV.to, clientId: RV.clientId, status: RV.status, include, includeDemo: RV.includeDemo == null ? !hasReal() : RV.includeDemo, notes: RV.notes });
  };
  V.reports = () => {
    const root = h('div', { class: 'view' });
    root.append(ui.pageHead('Reports', 'Generate professional PDF reports for your supervisor — built only from the records stored here'));
    const rt = CD.REPORT_TYPES.find((t) => t.id === RV.type);
    const typeSel = ui.select(CD.REPORT_TYPES.map((t) => ({ value: t.id, label: t.name })), RV.type, { onchange: (e) => { RV.type = e.target.value; Object.assign(RV, CD.reportRangeDefaults(RV.type)); RV.model = null; CD.render(); } });
    const from = h('input', { class: 'input', type: 'date', value: RV.from, onchange: (e) => { RV.from = e.target.value; if (RV.type === 'daily') RV.to = RV.from; } });
    const to = h('input', { class: 'input', type: 'date', value: RV.to, onchange: (e) => { RV.to = e.target.value; } });
    const setPreset = (a, b) => { RV.from = a; RV.to = b; CD.render(); };
    const t = CD.today(), lm = CD.ymd(new Date(CD.parseYMD(t).getFullYear(), CD.parseYMD(t).getMonth() - 1, 1));
    const presets = rt.range === 'day' ? [['Today', t, t], ['Yesterday', CD.addDays(t, -1), CD.addDays(t, -1)]] : [['This week', CD.weekStart(t), CD.weekEnd(t)], ['Last week', CD.addDays(CD.weekStart(t), -7), CD.addDays(CD.weekEnd(t), -7)], ['This month', CD.monthStart(t), CD.monthEnd(t)], ['Last month', lm, CD.monthEnd(lm)], ['All time', '', '']];
    const clientSel = ui.select([{ value: '', label: RV.type === 'client' ? 'Select a client…' : 'All clients' }, ...CD.data.clients.slice().sort((a, b) => CD.cmp(a.name.toLowerCase(), b.name.toLowerCase())).map((c) => ({ value: c.id, label: c.name + (c.demo ? ' (demo)' : '') }))], RV.clientId, { onchange: (e) => { RV.clientId = e.target.value; } });
    const statusSel = ui.select(['All', 'Open', 'Overdue', 'Completed', 'Cancelled'], RV.status, { onchange: (e) => { RV.status = e.target.value; } });
    const notes = h('textarea', { class: 'input', rows: 2, maxlength: 1000, placeholder: 'Optional remark to include under observations', oninput: (e) => { RV.notes = e.target.value; } }, RV.notes);
    const incl = keysFor(RV.type).map((k) => h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: RV.include[k] !== false, onchange: (e) => { RV.include[k] = e.target.checked; } }), h('span', {}, KEYLABEL[k])));
    const form = h('div', { class: 'card' },
      h('h2', { class: 'card-h' }, 'Report options'),
      ui.field('Report type', typeSel),
      rt.range === 'none' ? h('p', { class: 'muted small' }, 'This report is a snapshot of all open commitments as at today.') : rt.range === 'day' ? ui.field('Date', from) : h('div', { class: 'field' }, h('label', {}, 'Reporting period'), h('div', { class: 'row-tight' }, from, to), h('div', { class: 'hint' }, 'Leave a date empty for no limit.')),
      rt.range !== 'none' ? ui.chips(presets.map(([l]) => ({ id: l, label: l })), '', (l) => { const p = presets.find((x) => x[0] === l); setPreset(p[1], p[2]); }) : null,
      ui.field(RV.type === 'client' ? 'Client' : 'Client (optional filter)', clientSel, { required: RV.type === 'client' }),
      RV.type === 'followup' ? ui.field('Follow-up status', statusSel) : null,
      h('div', { class: 'field' }, h('label', {}, 'Include in report'), h('div', { class: 'checks' }, ...incl)),
      CD.hasDemo() ? h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: RV.includeDemo == null ? !hasReal() : RV.includeDemo, onchange: (e) => { RV.includeDemo = e.target.checked; } }), h('span', {}, 'Include demonstration records (clearly marked in the report)')) : null,
      ui.field('Remarks', notes),
      ui.btn('Generate report', { kind: 'primary', icon: 'file', block: true, onclick: () => { if (RV.type === 'client' && !RV.clientId) { CD.toast('Choose a client first.', 'error'); return; } if (RV.from && RV.to && RV.from > RV.to) { CD.toast('The start date is after the end date.', 'error'); return; } RV.model = buildNow(); CD.render(); setTimeout(() => { const p = document.getElementById('report-out'); if (p && window.innerWidth < 960) p.scrollIntoView({ behavior: 'smooth' }); }, 50); } }));

    const out = h('div', { id: 'report-out' });
    if (RV.model) { try { RV.model = buildNow(); } catch (e) { console.error(e); } }
    if (!RV.model) CD.mount(out, h('div', { class: 'card' }, ui.empty('file', 'Choose options, then generate', 'The preview appears here, ready to download as an A4 PDF or share with your supervisor. Figures are calculated from your stored records only.')));
    else {
      const m = RV.model;
      CD.mount(out, h('div', { class: 'card share-bar' },
        h('div', { class: 'share-title' }, h('b', {}, m.title), h('span', { class: 'muted small' }, `${m.periodLabel}`)),
        h('div', { class: 'btn-row wrap' },
          ui.btn('Download PDF', { kind: 'primary', icon: 'download', onclick: () => { try { CD.downloadBlob(CD.reportToPDF(m).toBlob(), CD.reportFileName(m, 'pdf')); CD.toast('PDF created and downloaded.'); } catch (e) { console.error(e); CD.toast('Could not create the PDF: ' + e.message, 'error'); } } }),
          ui.btn('Share PDF', { icon: 'share', onclick: async () => { try { const r = await CD.sharePDF(m); if (r === 'shared') CD.toast('PDF shared.'); else if (r === 'cancelled') CD.toast('Sharing was cancelled — nothing was sent.', 'info'); else CD.toast('Sharing files is not supported here, so the PDF was downloaded instead.', 'info'); } catch (e) { CD.toast('Could not share: ' + e.message, 'error'); } } }),
          ui.btn('WhatsApp', { icon: 'msg', onclick: () => shareDialog('whatsapp', m) }),
          ui.btn('Email', { icon: 'mail', onclick: () => shareDialog('email', m) }),
          ui.btn('Copy summary', { icon: 'copy', onclick: async () => { const ok = await CD.copyText(CD.reportToText(m)); CD.toast(ok ? 'Summary copied to clipboard.' : 'Could not copy — select the text manually.', ok ? 'success' : 'error'); } }),
          ui.btn('Print', { icon: 'print', onclick: () => window.print() }))), CD.reportPreview(m));
    }
    root.append(h('div', { class: 'report-layout' }, form, out));
    return root;
  };

  function shareDialog(kind, m) {
    const text = CD.reportToText(m, { markdown: kind === 'whatsapp' });
    const subject = `${m.title} – ${m.periodLabel}${m.orgName ? ' – ' + m.orgName : ''}`;
    const ta = h('textarea', { class: 'input mono', rows: 12, maxlength: 20000 }, text);
    const S = CD.settings;
    const to = kind === 'whatsapp' ? S.supervisorPhone : S.supervisorEmail;
    const body = h('div', {},
      h('p', {}, kind === 'whatsapp' ? `This opens WhatsApp with the text below${to ? ' addressed to ' + (S.supervisor || to) : ''}. You review it and press Send yourself.` : `This opens your email app with the text below${to ? ' addressed to ' + to : ''}. A PDF cannot be attached automatically — download it first, or use “Share PDF” and choose your email app.`),
      ui.field('Message (you can edit it)', ta), !to ? h('p', { class: 'muted small' }, `Tip: add your supervisor’s ${kind === 'whatsapp' ? 'WhatsApp number' : 'email address'} in Settings to pre-fill the recipient.`) : null);
    const dlg = CD.modal({ title: kind === 'whatsapp' ? 'Share on WhatsApp' : 'Prepare email', body, footer: [ui.btn('Cancel', { onclick: () => dlg.close() }),
      ui.btn(kind === 'whatsapp' ? 'Open WhatsApp' : 'Open email app', { kind: 'primary', icon: kind === 'whatsapp' ? 'msg' : 'mail', onclick: () => {
        const t = ta.value;
        let url;
        if (kind === 'whatsapp') url = CD.waHref(S.supervisorPhone || '', t);
        else { const b = t.length > 1800 ? t.slice(0, 1800) + '\n\n[Message shortened — see the attached PDF for the full report.]' : t; url = `mailto:${encodeURIComponent(S.supervisorEmail || '').replace('%40', '@')}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(b)}`; }
        if (kind === 'whatsapp') window.open(url, '_blank', 'noopener'); else window.location.href = url;
        dlg.close(); CD.toast(`${kind === 'whatsapp' ? 'WhatsApp' : 'Your email app'} was opened. Review and send there — ClientDesk cannot confirm that it was sent.`, 'info', { ms: 8000 });
      } })] });
  }

  /* =============== REMINDERS =============== */
  V.reminders = () => {
    const root = h('div', { class: 'view' });
    root.append(ui.pageHead('Reminders', 'Your in-app reminder centre', ui.btn('Add reminder', { icon: 'plus', kind: 'primary', onclick: () => CD.openReminderForm() })));
    const ns = CD.notifState();
    root.append(h('div', { class: 'alert ' + (ns === 'granted' ? 'alert-ok' : 'alert-info') }, CD.icon(ns === 'granted' ? 'check' : 'bell', 16), h('div', { class: 'grow' },
      h('b', {}, ns === 'granted' ? 'Browser notifications are on' : ns === 'denied' ? 'Browser notifications are blocked' : ns === 'unsupported' ? 'Browser notifications are not supported here' : 'Browser notifications are off'),
      h('div', { class: 'small' }, 'This page is the reliable reminder centre and works offline. Browser notifications are an extra: they need your permission, a supporting browser (installing the app helps), and the app or browser running in the background — they may not fire if the browser is fully closed.')),
      ns === 'default' ? ui.btn('Enable notifications', { sm: true, kind: 'primary', onclick: async () => { const r = await CD.requestNotifications(); CD.toast(r === 'granted' ? 'Notifications enabled.' : 'Notifications were not enabled.', r === 'granted' ? 'success' : 'info'); CD.render(); } }) : null,
      ns === 'denied' ? h('span', { class: 'small' }, 'Change this in your browser’s site settings.') : null));
    const rem = CD.data.reminders, now = new Date();
    const open = rem.filter((r) => !r.done).sort((a, b) => CD.cmp(CD.localISO(CD.remDue(a)), CD.localISO(CD.remDue(b))));
    const today = CD.today();
    const groups = [
      ['Overdue', open.filter(CD.remOverdue), 'danger'], ['Snoozed', open.filter(CD.remSnoozed), ''],
      ['Today', open.filter((r) => !CD.remOverdue(r) && !CD.remSnoozed(r) && r.date === today), ''],
      ['Next 7 days', open.filter((r) => !CD.remOverdue(r) && !CD.remSnoozed(r) && r.date > today && r.date <= CD.addDays(today, 7)), ''],
      ['Later', open.filter((r) => !CD.remOverdue(r) && !CD.remSnoozed(r) && r.date > CD.addDays(today, 7)), '']
    ];
    /* daily overview */
    const fuToday = CD.data.followups.filter((f) => CD.fuOpen(f) && f.date === today).length, fuOver = CD.data.followups.filter(CD.fuOverdue).length;
    root.append(h('div', { class: 'overview' }, h('h2', { class: 'card-h' }, 'Daily overview'),
      h('div', { class: 'mini-stats' }, ...[['Follow-ups today', fuToday], ['Overdue follow-ups', fuOver, fuOver > 0], ['Overdue promises', CD.data.promises.filter(CD.promiseOverdue).length, CD.data.promises.some(CD.promiseOverdue)], ['Reminders due now', open.filter(CD.remTriggered).length, open.some(CD.remOverdue)]].map(([l, v, w]) => h('div', { class: w ? 'warn' : '' }, h('b', {}, v), h('small', {}, l))))));
    const row = (r) => h('div', { class: 'list-row' + (CD.remOverdue(r) ? ' row-over' : '') },
      h('div', { class: 'grow' }, h('div', {}, h('b', {}, r.title), ' ', ui.demoTag(r)), r.note ? h('div', { class: 'muted small' }, CD.trunc(r.note, 100)) : null,
        h('div', { class: 'small ' + (CD.remOverdue(r) ? 'txt-danger' : 'muted') }, CD.fmtDT(r.date, r.time) + (CD.remSnoozed(r) ? ` · snoozed until ${CD.fmtStamp(r.snoozedUntil)}` : ''))),
      h('div', { class: 'row-acts' },
        r.followupId ? ui.btn('Open', { sm: true, onclick: () => { const f = CD.byId('followups', r.followupId); if (f) CD.openFollowupForm({ followup: f }); } }) : r.promiseId ? ui.btn('Open', { sm: true, onclick: () => CD.openPromiseDetail(r.promiseId) }) : ui.iconBtn('edit', 'Edit', () => CD.openReminderForm({ reminder: r })),
        act('clock', 'Snooze', (e) => ui.menu(e.currentTarget, [{ label: 'Snooze 10 minutes', icon: 'clock', fn: () => CD.snoozeReminder(r, 10).then(() => CD.toast('Snoozed for 10 minutes.', 'info')) }, { label: 'Snooze 1 hour', icon: 'clock', fn: () => CD.snoozeReminder(r, 60).then(() => CD.toast('Snoozed for 1 hour.', 'info')) }, { label: 'Tomorrow 9:00', icon: 'clock', fn: () => CD.snoozeReminder(r, 'tomorrow').then(() => CD.toast('Snoozed until tomorrow.', 'info')) }])),
        act('check', 'Mark done', async () => { await CD.put('reminders', { ...r, done: true, doneAt: new Date().toISOString() }); CD.toast('Reminder marked done.'); }),
        !r.followupId && !r.promiseId ? act('trash', 'Delete', async () => { if (await CD.confirm({ title: 'Delete reminder?', message: r.title, confirmText: 'Delete', danger: true })) { await CD.del('reminders', r.id); CD.toast('Reminder deleted.'); } }) : null));
    let any = false;
    groups.forEach(([title, list, kind]) => { if (!list.length) return; any = true; root.append(ui.panel(title, h('div', { class: 'list' }, ...list.map(row)), { count: list.length, class: kind === 'danger' ? 'panel-danger' : '' })); });
    if (!any) root.append(h('div', { class: 'card' }, ui.empty('bell', 'No active reminders', 'Reminders are created automatically when you schedule a follow-up or record a promise. You can also add your own.', ui.btn('Add reminder', { sm: true, kind: 'primary', onclick: () => CD.openReminderForm() }))));
    const done = rem.filter((r) => r.done).sort((a, b) => CD.cmp(b.doneAt || '', a.doneAt || '')).slice(0, 8);
    if (done.length) root.append(ui.panel('Recently completed', h('div', { class: 'list' }, ...done.map((r) => h('div', { class: 'list-row muted' }, h('div', { class: 'grow' }, h('s', {}, r.title), h('div', { class: 'small' }, CD.fmtDT(r.date, r.time))), ui.iconBtn('refresh', 'Reopen', async () => { await CD.put('reminders', { ...r, done: false, doneAt: '', notifiedAt: '', snoozedUntil: '' }); }))))));
    void now;
    return root;
  };

  /* =============== SETTINGS =============== */
  CD.exportBackup = async () => {
    const blob = new Blob([JSON.stringify(CD.exportAll(), null, 2)], { type: 'application/json' });
    CD.downloadBlob(blob, `clientdesk-backup_${CD.today()}.json`);
    await CD.setSetting('lastBackupAt', new Date().toISOString());
    CD.toast('Backup file downloaded. Keep it somewhere safe (e.g. WhatsApp it to yourself or save to Drive).');
  };

  V.settings = () => {
    const S = CD.settings;
    const root = h('div', { class: 'view narrow' });
    root.append(ui.pageHead('Settings', 'Your details, preferences, categories and backups'));
    const inp = (k, o = {}) => h('input', { class: 'input', value: S[k] || '', maxlength: o.max || 120, type: o.type || 'text', placeholder: o.ph || '' });
    const secCard = (title, sub, ...kids) => h('section', { class: 'card' }, h('h2', { class: 'card-h' }, title), sub ? h('p', { class: 'muted small mb' }, sub) : null, ...kids);

    /* profile */
    const P = { userName: inp('userName'), org: inp('org'), jobTitle: inp('jobTitle'), supervisor: inp('supervisor'), supervisorEmail: inp('supervisorEmail', { type: 'email' }), supervisorPhone: inp('supervisorPhone', { type: 'tel', ph: 'e.g. 0772 000 000' }), reportTitle: inp('reportTitle') };
    root.append(secCard('Profile & reports', 'These appear on report headers and PDFs.',
      h('div', { class: 'row' }, ui.field('Your name', P.userName), ui.field('Job title', P.jobTitle)),
      h('div', { class: 'row' }, ui.field('Company / organisation name', P.org), ui.field('Supervisor / boss name', P.supervisor)),
      h('div', { class: 'row' }, ui.field('Supervisor email', P.supervisorEmail), ui.field('Supervisor WhatsApp number', P.supervisorPhone)),
      ui.field('Default report heading', P.reportTitle, { hint: 'Shown above the report type, e.g. “Client Communication Report”.' }),
      ui.btn('Save profile', { kind: 'primary', icon: 'check', onclick: async (e) => { ui.clearErrs(root); if (val(P.supervisorEmail) && !CD.validEmail(val(P.supervisorEmail))) return ui.fail(P.supervisorEmail, 'That email address does not look right.'); if (val(P.supervisorPhone) && !CD.validPhone(val(P.supervisorPhone))) return ui.fail(P.supervisorPhone, 'Enter a valid phone number.'); for (const [k, el] of Object.entries(P)) await CD.setSetting(k, val(el)); CD.toast('Profile saved.'); } })));

    /* preferences */
    const dfmt = ui.select([{ value: 'D MMM YYYY', label: `19 Nov 2026 (D MMM YYYY)` }, { value: 'DD/MM/YYYY', label: '19/11/2026 (DD/MM/YYYY)' }, { value: 'MM/DD/YYYY', label: '11/19/2026 (MM/DD/YYYY)' }], S.dateFormat);
    const theme = ui.select([{ value: 'system', label: 'Match my device' }, { value: 'light', label: 'Light' }, { value: 'dark', label: 'Dark' }], S.theme);
    const cur = inp('currency', { max: 8 }), cc = inp('countryCode', { max: 4 });
    root.append(secCard('Preferences', null,
      h('div', { class: 'row' }, ui.field('Date format', dfmt), ui.field('Theme', theme)),
      h('div', { class: 'row' }, ui.field('Currency label', cur, { hint: 'Shown next to amounts, e.g. UGX' }), ui.field('Default country code', cc, { hint: 'Used to match numbers like 0772… and +256772… (duplicate detection). Uganda = 256.' })),
      ui.btn('Save preferences', { kind: 'primary', icon: 'check', onclick: async () => { await CD.setSetting('dateFormat', dfmt.value); await CD.setSetting('theme', theme.value); await CD.setSetting('currency', val(cur)); const code = val(cc).replace(/\D/g, ''); await CD.setSetting('countryCode', code || '256'); CD.applyTheme(); CD.toast('Preferences saved.'); CD.render(); } })));

    /* reminders */
    const ns = CD.notifState();
    const lead = ui.select([{ value: '0', label: 'At the scheduled time' }, { value: '5', label: '5 minutes before' }, { value: '15', label: '15 minutes before' }, { value: '30', label: '30 minutes before' }, { value: '60', label: '1 hour before' }], String(S.leadMinutes));
    const notif = h('input', { type: 'checkbox', checked: S.notify }), over = h('input', { type: 'checkbox', checked: S.dailyOverview });
    root.append(secCard('Reminders', 'In-app reminders always work offline. Browser notifications are optional and best-effort.',
      ui.field('Alert me', lead),
      h('label', { class: 'check' }, notif, h('span', {}, 'Show browser notifications when a reminder is due (needs permission)')),
      h('label', { class: 'check' }, over, h('span', {}, 'Show a daily overview when I open the app')),
      h('p', { class: 'small muted' }, `Notification permission: ${ns === 'unsupported' ? 'not supported by this browser' : ns}.`),
      h('div', { class: 'btn-row' }, ui.btn('Save reminder settings', { kind: 'primary', icon: 'check', onclick: async () => { await CD.setSetting('leadMinutes', Number(lead.value)); await CD.setSetting('notify', notif.checked); await CD.setSetting('dailyOverview', over.checked); if (notif.checked && ns === 'default') await CD.requestNotifications(); CD.toast('Reminder settings saved.'); CD.render(); } }), ns === 'default' ? ui.btn('Allow notifications', { icon: 'bell', onclick: async () => { await CD.requestNotifications(); CD.render(); } }) : null)));

    /* categories */
    const catEditor = (key, title) => {
      const box = h('div', { class: 'cat-box' });
      const add = h('input', { class: 'input', placeholder: 'New category', maxlength: 40 });
      const draw = () => CD.mount(box, h('div', { class: 'cat-list' }, ...(S[key] || []).map((name) => h('span', { class: 'cat-chip' }, name,
        h('button', { type: 'button', title: 'Rename', 'aria-label': 'Rename ' + name, onclick: async () => { const n = await askText('Rename category', 'Name', name); if (!n || n === name) return; if ((S[key] || []).includes(n)) { CD.toast('That category already exists.', 'error'); return; } await CD.batch(async () => { await CD.setSetting(key, S[key].map((x) => (x === name ? n : x))); const store = key === 'categories' ? 'clients' : 'promises'; for (const r of CD.data[store].filter((x) => x.category === name)) await CD.put(store, { ...r, category: n }); }); CD.toast('Category renamed.'); draw(); } }, CD.icon('edit', 12)),
        h('button', { type: 'button', title: 'Remove', 'aria-label': 'Remove ' + name, onclick: async () => { const used = CD.data[key === 'categories' ? 'clients' : 'promises'].filter((x) => x.category === name).length; if (!(await CD.confirm({ title: `Remove “${name}”?`, message: used ? `${CD.plural(used, 'record')} currently use this category. They keep the label but it will no longer be offered in the list.` : 'It will no longer be offered in the list.', confirmText: 'Remove', danger: true }))) return; await CD.setSetting(key, S[key].filter((x) => x !== name)); draw(); } }, CD.icon('x', 12)))),
      ), h('form', { class: 'inline-add', onsubmit: async (e) => { e.preventDefault(); const n = val(add); if (!n) return; if ((S[key] || []).some((x) => x.toLowerCase() === n.toLowerCase())) { CD.toast('That category already exists.', 'error'); return; } await CD.setSetting(key, [...(S[key] || []), n]); add.value = ''; draw(); } }, add, ui.btn('Add', { type: 'submit', icon: 'plus', sm: true })));
      draw();
      return h('div', { class: 'field' }, h('label', {}, title), box);
    };
    root.append(secCard('Categories', 'Customise the lists used in forms and filters.', catEditor('categories', 'Client categories'), catEditor('promiseCategories', 'Commitment categories')));

    /* backup */
    const fileIn = h('input', { type: 'file', accept: 'application/json,.json', hidden: true, onchange: (e) => importFile(e.target.files[0], e.target) });
    const bdays = ui.select([{ value: '0', label: 'Never remind me' }, { value: '3', label: 'Every 3 days' }, { value: '7', label: 'Every week' }, { value: '14', label: 'Every 2 weeks' }, { value: '30', label: 'Every month' }], String(S.backupReminderDays), { onchange: async (e) => { await CD.setSetting('backupReminderDays', Number(e.target.value)); CD.toast('Backup reminder saved.'); } });
    root.append(secCard('Backup & restore', 'Your data is stored only in this browser on this device. Clearing browser data or losing the device loses it — export backups regularly.',
      h('p', { class: 'small' }, 'Last backup: ', h('b', {}, S.lastBackupAt ? CD.fmtStamp(S.lastBackupAt) : 'never')),
      h('div', { class: 'btn-row wrap' }, ui.btn('Export all data (JSON)', { kind: 'primary', icon: 'download', onclick: () => CD.exportBackup() }), ui.btn('Import backup…', { icon: 'upload', onclick: () => fileIn.click() }), fileIn),
      ui.field('Backup reminder', bdays), persistRow()));

    /* demo */
    root.append(secCard('Demonstration data', 'Sample clients, calls and promises with fictional Ugandan names, clearly marked DEMO, so you can explore. Real data is never changed.',
      h('div', { class: 'btn-row' }, ui.btn(CD.hasDemo() ? 'Reload demo data' : 'Load demo data', { icon: 'users', onclick: async (e) => { e.currentTarget.disabled = true; if (CD.hasDemo()) await CD.removeDemoData(); await CD.loadDemoData(); CD.toast('Demonstration data loaded.'); } }), CD.hasDemo() ? ui.btn('Remove demo data', { kind: 'danger-ghost', icon: 'trash', onclick: removeDemo }) : null)));

    root.append(CD.settingsSecurity(secCard), CD.settingsSmart(secCard));

    /* privacy & legal */
    root.append(secCard('Privacy & legal', 'How ClientDesk treats your information, and what you agreed to.',
      h('div', { class: 'btn-row wrap' }, ui.btn('Privacy Policy', { icon: 'shield', onclick: () => CD.showLegal('privacy') }), ui.btn('Terms of Use', { icon: 'file', onclick: () => CD.showLegal('terms') })),
      h('p', { class: 'small muted' }, S.consentAt ? `You accepted version ${S.consentVersion} on ${CD.fmtStamp(S.consentAt)}.` : 'Not yet accepted.'),
      h('p', { class: 'small muted' }, 'Contacts, call history and notifications are used only when you tap the matching button. You can withdraw any permission in Android Settings \u2192 Apps \u2192 ClientDesk \u2192 Permissions, and erase all stored data under Danger zone.')));

    /* danger */
    root.append(secCard('Danger zone', null, h('div', { class: 'btn-row' }, ui.btn('Erase all data on this device…', { kind: 'danger-ghost', icon: 'trash', onclick: eraseAll }))));

    /* about */
    const about = h('div', { class: 'about' }, h('dl', { class: 'kv' }, h('dt', {}, 'Version'), h('dd', {}, `ClientDesk ${CD.VERSION} (database v${CD.SCHEMA_VERSION})`), h('dt', {}, 'Offline mode'), h('dd', { id: 'sw-status' }, 'Checking…'), h('dt', {}, 'Storage used'), h('dd', { id: 'storage-use' }, '…'), h('dt', {}, 'Created by'), h('dd', {}, `${CD.LEGAL.creator} \u00A9 ${CD.LEGAL.year}`), h('dt', {}, 'Device ID'), h('dd', { class: 'mono small' }, S.deviceId)));
    CD.swStatus().then((t) => { const e = document.getElementById('sw-status'); if (e) e.textContent = t; });
    CD.storageEstimate().then((e) => { const el = document.getElementById('storage-use'); if (el) el.textContent = e ? `${(e.usage / 1048576).toFixed(2)} MB of ${(e.quota / 1048576).toFixed(0)} MB available` : 'not available'; });
    root.append(secCard('About', null, about, CD.canInstall() ? ui.btn('Install app on this device', { icon: 'download', kind: 'primary', onclick: () => CD.promptInstall() }) : h('p', { class: 'small muted' }, 'Tip: use your browser’s “Install app” / “Add to Home screen” option to install ClientDesk and open it like a normal app.'),
      h('p', { class: 'small muted' }, 'Privacy: ClientDesk has no accounts, no tracking and no analytics. Client information never leaves this device unless you export, share or send it yourself. Cloud sync is not enabled in this version.')));
    return root;
  };

  function persistRow() {
    const wrap = h('div', { class: 'small' });
    if (navigator.storage && navigator.storage.persisted) navigator.storage.persisted().then((p) => {
      CD.mount(wrap, p ? h('span', { class: 'txt-ok' }, 'Storage is protected from automatic clean-up by the browser.') : h('span', {}, 'The browser may clear stored data if the device runs low on space. ', ui.btn('Protect my data', { sm: true, onclick: async () => { const ok = await navigator.storage.persist(); CD.toast(ok ? 'Storage is now protected.' : 'The browser did not grant protection (installing the app usually helps).', ok ? 'success' : 'info'); CD.render(); } })));
    });
    return wrap;
  }

  async function eraseAll() {
    const typed = h('input', { class: 'input', placeholder: 'Type DELETE to confirm', autocomplete: 'off' });
    const ok = await CD.confirm({ title: 'Erase ALL data?', danger: true, confirmText: 'Erase everything', message: 'This permanently deletes every client, call, promise, follow-up and reminder on this device. Export a backup first if you might need it.', extra: typed });
    if (!ok) return;
    if (typed.value.trim() !== 'DELETE') { CD.toast('Nothing was erased — you did not type DELETE.', 'info'); return; }
    await CD.wipeAll(); CD.toast('All data erased.');
  }

  async function importFile(file, input) {
    if (!file) return;
    try {
      if (file.size > 60 * 1024 * 1024) throw new Error('That file is too large.');
      const parsed = CD.parseBackup(await file.text());
      if (!parsed.ok) { CD.toast(parsed.error, 'error'); return; }
      const c = parsed.counts;
      let mode = 'merge';
      const modeSel = h('div', { class: 'radios' },
        h('label', { class: 'check' }, h('input', { type: 'radio', name: 'imode', checked: true, onchange: () => { mode = 'merge'; } }), h('span', {}, h('b', {}, 'Merge'), ' – add missing records; replace a record only if the backup copy is newer. Nothing newer on this device is overwritten.')),
        h('label', { class: 'check' }, h('input', { type: 'radio', name: 'imode', onchange: () => { mode = 'replace'; } }), h('span', {}, h('b', {}, 'Replace everything'), ' – erase current data first, then restore the backup exactly.')));
      const ok = await CD.confirm({ title: 'Import this backup?', confirmText: 'Import', message: `Backup from ${parsed.exportedAt ? CD.fmtStamp(parsed.exportedAt) : 'unknown date'} contains ${c.clients} clients, ${c.calls} calls, ${c.promises} promises, ${c.followups} follow-ups.${parsed.skipped ? ` ${parsed.skipped} invalid or orphaned records will be skipped.` : ''}`, extra: modeSel });
      if (!ok) return;
      if (mode === 'replace' && !(await CD.confirm({ title: 'Replace all current data?', danger: true, confirmText: 'Yes, replace', message: 'Your current records on this device will be erased and replaced by the backup.' }))) return;
      const r = await CD.applyBackup(parsed, mode);
      CD.toast(`Import complete: ${r.added} added, ${r.updated} updated${r.keptLocal ? `, ${r.keptLocal} kept (local copy was newer or identical)` : ''}.`);
    } catch (e) { console.error(e); CD.toast('Import failed: ' + (e.message || e), 'error'); } finally { if (input) input.value = ''; }
  }
})();
