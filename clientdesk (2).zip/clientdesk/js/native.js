/* ClientDesk — optional native (Capacitor/Android) bridge.
 * In a normal browser none of this activates and the app behaves as a PWA.
 * Inside the Android app it swaps in: native file saving/sharing, scheduled local notifications
 * (which fire even when the app is closed), the Android back button, and "Share to ClientDesk". */
(function () {
  'use strict';
  const CD = window.CD;
  const cap = () => window.Capacitor;
  const N = (CD.native = { perm: 'default' });
  N.isNative = () => !!(cap() && typeof cap().isNativePlatform === 'function' && cap().isNativePlatform());
  N.plugin = (name) => (cap() && cap().Plugins && cap().Plugins[name]) || null;
  const msg = (e) => String((e && (e.message || e.errorMessage)) || e || '');

  /* ---- files: write to the app cache, then open the Android share sheet (Save to Drive / WhatsApp / Files ...) ---- */
  const toBase64 = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });
  N.saveBlob = async (blob, filename) => {
    const FS = N.plugin('Filesystem'), Share = N.plugin('Share');
    if (!FS || !Share) throw new Error('Native file plugins are not installed.');
    const file = await FS.writeFile({ path: filename, data: await toBase64(blob), directory: 'CACHE' });
    try { await Share.share({ title: filename, url: file.uri, dialogTitle: 'Save or send ' + filename }); return 'shared'; }
    catch (e) { if (/cancel/i.test(msg(e))) return 'cancelled'; throw e; }
  };

  /* ---- notifications ---- */
  const toId = (s) => { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h) % 2147483000 + 1; };
  const mapPerm = (r) => (r === 'granted' ? 'granted' : r === 'denied' ? 'denied' : 'default');
  N.initNotifications = async () => {
    const LN = N.plugin('LocalNotifications');
    if (!LN) { N.perm = 'unsupported'; return; }
    try { N.perm = mapPerm((await LN.checkPermissions()).display); } catch (e) { N.perm = 'unsupported'; }
  };
  N.requestNotifications = async () => {
    const LN = N.plugin('LocalNotifications'); if (!LN) return 'unsupported';
    try { N.perm = mapPerm((await LN.requestPermissions()).display); } catch (e) { N.perm = 'denied'; }
    await CD.setSetting('notify', N.perm === 'granted'); N.syncReminders(); return N.perm;
  };
  N.syncReminders = async () => {
    const LN = N.plugin('LocalNotifications');
    if (!LN || !N.isNative() || !CD.data) return;
    try {
      const pending = await LN.getPending();
      if (pending.notifications && pending.notifications.length) await LN.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
      if (N.perm !== 'granted' || !CD.settings.notify) return;
      const soon = Date.now() + 5000;
      const list = CD.data.reminders.filter((r) => !r.done).map((r) => ({ r, at: CD.remAlertAt(r) })).filter((x) => x.at.getTime() > soon).sort((a, b) => a.at - b.at).slice(0, 60);
      if (list.length) await LN.schedule({ notifications: list.map(({ r, at }) => ({ id: toId(r.id), title: r.title, body: [CD.fmtTime(r.time), r.note].filter(Boolean).join(' – '), schedule: { at, allowWhileIdle: true } })) });
    } catch (e) { console.warn('Could not schedule native reminders', e); }
  };

  /* ---- contacts & call history (custom ClientDeskDevice plugin, see native/android) ---- */
  const device = () => N.plugin('ClientDeskDevice') || (cap() && cap().registerPlugin ? cap().registerPlugin('ClientDeskDevice') : null);
  N.getContacts = async () => { const d = device(); if (!d) throw new Error('Contacts are not available in this build.'); return (await d.getContacts()).contacts || []; };
  N.getCalls = async (opts) => { const d = device(); if (!d) throw new Error('Call history is not available in this build.'); return (await d.getCalls(opts)).calls || []; };

  /* ---- boot hook (called by app.js after the database is open) ---- */
  N.start = async () => {
    if (!N.isNative()) return;
    document.documentElement.classList.add('native-app');
    await N.initNotifications();
    const sync = CD.debounce(() => N.syncReminders(), 800);
    CD.on('change', sync); CD.on('settings', sync); sync();
    const App = N.plugin('App');
    if (App && App.addListener) {
      App.addListener('appStateChange', (s) => { if (s && s.isActive && CD.checkPendingCall) setTimeout(CD.checkPendingCall, 300); });
      App.addListener('backButton', () => {
        if (CD.closeTopModal && CD.closeTopModal()) return;
        const r = (location.hash || '').replace(/^#\/?/, '');
        if (r && r !== 'dashboard') { location.hash = '#/dashboard'; return; }
        if (App.exitApp) App.exitApp();
      });
    }
    const ST = N.plugin('CapacitorShareTarget'); // optional plugin: @capgo/capacitor-share-target
    if (ST && ST.addListener) { try { ST.addListener('shareReceived', (e) => { const t = [].concat((e && e.texts) || [], (e && e.title) || []).filter(Boolean).join('\n'); if (t) CD.openBulkImport(t); }); } catch (e) { /* optional */ } }
  };
})();
