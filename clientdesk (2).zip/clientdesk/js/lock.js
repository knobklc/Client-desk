/* ClientDesk — app lock (PIN, optional device fingerprint/screen-lock via WebAuthn).
   This keeps casual onlookers out of the app. It does not encrypt the data stored on the device. */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h, ui = CD.ui;
  const L = (CD.lock = { locked: false });
  const enc = new TextEncoder();
  const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  const unhex = (s) => new Uint8Array((s.match(/../g) || []).map((x) => parseInt(x, 16)));

  L.supported = () => !!(window.crypto && crypto.subtle);
  L.enabled = () => !!CD.settings.pinHash;

  async function derive(pin, saltHex) {
    const key = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveBits']);
    return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: unhex(saltHex), iterations: 150000 }, key, 256));
  }
  const timingSafe = (a, b) => { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; };
  L.verify = async (pin) => timingSafe(await derive(pin, CD.settings.pinSalt), CD.settings.pinHash);
  L.setPin = async (pin) => { const salt = hex(crypto.getRandomValues(new Uint8Array(16))); const hash = await derive(pin, salt); await CD.batch(async () => { await CD.setSetting('pinSalt', salt); await CD.setSetting('pinHash', hash); }); };
  L.clear = async () => { await CD.batch(async () => { await CD.setSetting('pinHash', ''); await CD.setSetting('pinSalt', ''); await CD.setSetting('bioId', ''); }); };

  /* failed-attempt back-off, kept across reloads */
  const ls = { get: (k) => { try { return localStorage.getItem(k); } catch (e) { return L['_' + k] || null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) { L['_' + k] = v; } } };
  const waitLeft = () => Math.max(0, Number(ls.get('cd_lock_until') || 0) - Date.now());
  const fail = () => { const n = Number(ls.get('cd_lock_fails') || 0) + 1; ls.set('cd_lock_fails', String(n)); if (n >= 5) ls.set('cd_lock_until', String(Date.now() + Math.min(300, 15 * 2 ** (n - 5)) * 1000)); return n; };
  const ok = () => { ls.set('cd_lock_fails', '0'); ls.set('cd_lock_until', '0'); };

  /* ---------- fingerprint / screen lock through the browser's platform authenticator ---------- */
  L.bioAvailable = async () => { try { return !!(window.PublicKeyCredential && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable && await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()); } catch (e) { return false; } };
  L.bioEnroll = async () => {
    const cred = await navigator.credentials.create({ publicKey: { challenge: crypto.getRandomValues(new Uint8Array(32)), rp: { name: 'ClientDesk' }, user: { id: crypto.getRandomValues(new Uint8Array(16)), name: 'clientdesk-user', displayName: 'ClientDesk user' }, pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }], authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required', residentKey: 'discouraged' }, timeout: 60000 } });
    await CD.setSetting('bioId', hex(cred.rawId));
  };
  L.bioCheck = async () => {
    const id = CD.settings.bioId; if (!id) return false;
    try { const r = await navigator.credentials.get({ publicKey: { challenge: crypto.getRandomValues(new Uint8Array(32)), allowCredentials: [{ type: 'public-key', id: unhex(id) }], userVerification: 'required', timeout: 60000 } }); return !!r; } catch (e) { return false; }
  };

  /* ---------- the lock screen ---------- */
  let screen = null, resolvers = [];
  L.show = () => new Promise((resolve) => {
    resolvers.push(resolve);
    if (screen) return;
    document.querySelectorAll('.modal-overlay').forEach((o) => { o.style.visibility = 'hidden'; });
    L.locked = true; document.documentElement.classList.add('is-locked');
    const pin = h('input', { class: 'input lock-pin', type: 'password', inputmode: 'numeric', autocomplete: 'off', maxlength: 6, placeholder: 'PIN', 'aria-label': 'PIN' });
    const msg = h('div', { class: 'err lock-msg', role: 'alert' });
    let busy = false, tick = null;
    const unlock = () => { ok(); screen.remove(); screen = null; L.locked = false; document.querySelectorAll('.modal-overlay').forEach((o) => { o.style.visibility = ''; }); document.documentElement.classList.remove('is-locked'); if (tick) clearInterval(tick); const r = resolvers; resolvers = []; r.forEach((f) => f()); if (CD.checkPendingCall) setTimeout(CD.checkPendingCall, 300); };
    const showWait = () => { const w = waitLeft(); if (w > 0) { msg.textContent = `Too many wrong attempts. Try again in ${Math.ceil(w / 1000)}s.`; return true; } return false; };
    const submit = async () => {
      if (busy || showWait()) return;
      if (!/^\d{4,6}$/.test(pin.value)) { msg.textContent = 'Enter your 4–6 digit PIN.'; return; }
      busy = true; let good = false;
      try { good = await L.verify(pin.value); } catch (e) { console.error(e); }
      busy = false;
      if (good) return unlock();
      const n = fail(); pin.value = ''; msg.textContent = showWait() ? msg.textContent : `Wrong PIN. ${Math.max(0, 5 - n)} attempt(s) left before a short wait.`; pin.focus();
    };
    const bioBtn = CD.settings.bioId ? ui.btn('Use fingerprint', { icon: 'shield', onclick: async () => { if (await L.bioCheck()) unlock(); else msg.textContent = 'Fingerprint was not recognised. Use your PIN.'; } }) : null;
    const forgot = h('button', { class: 'link-btn small', type: 'button', onclick: async () => {
      const typed = h('input', { class: 'input', placeholder: 'Type DELETE to confirm', autocomplete: 'off' });
      const yes = await CD.confirm({ title: 'Forgot your PIN?', danger: true, confirmText: 'Erase data and unlock', message: 'ClientDesk cannot recover a lost PIN. The only way back in is to erase all data on this device. You can then restore a backup file from Settings.', extra: typed });
      if (yes && typed.value.trim() === 'DELETE') { await CD.wipeAll(); await L.clear(); CD.toast('Data erased and lock removed.', 'info'); unlock(); }
    } }, 'Forgot PIN?');
    screen = h('div', { class: 'lock-screen', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'ClientDesk is locked' },
      h('form', { class: 'lock-card', onsubmit: (e) => { e.preventDefault(); submit(); } }, CD.logo(56), h('h1', {}, 'ClientDesk is locked'), h('p', { class: 'muted' }, 'Enter your PIN to continue.'), pin, msg,
        h('div', { class: 'btn-row center' }, ui.btn('Unlock', { type: 'submit', kind: 'primary' }), bioBtn), forgot));
    document.body.append(screen);
    showWait(); tick = setInterval(() => { if (waitLeft() > 0) showWait(); else if (/Too many/.test(msg.textContent)) msg.textContent = ''; }, 1000);
    setTimeout(() => { pin.focus(); if (CD.settings.bioId) L.bioCheck().then((g) => { if (g && screen) unlock(); }); }, 100);
  });

  /* ---------- auto-lock when the app was in the background ---------- */
  let hiddenAt = 0;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { hiddenAt = Date.now(); return; }
    if (!L.enabled() || L.locked || !hiddenAt) return;
    const mins = Number(CD.settings.lockAfter || 0);
    if (Date.now() - hiddenAt >= mins * 60000) L.show();
  });

  /* ---------- settings ---------- */
  const askPin = (title, text) => new Promise((resolve) => {
    const a = h('input', { class: 'input', type: 'password', inputmode: 'numeric', maxlength: 6, autocomplete: 'off', 'aria-label': 'PIN' });
    const b = h('input', { class: 'input', type: 'password', inputmode: 'numeric', maxlength: 6, autocomplete: 'off', 'aria-label': 'Confirm PIN' });
    const err = h('div', { class: 'err', role: 'alert' });
    let done = false; const finish = (v) => { if (done) return; done = true; m.close(); resolve(v); };
    const go = () => { if (!/^\d{4,6}$/.test(a.value)) { err.textContent = 'Use 4 to 6 digits.'; return; } if (b && a.value !== b.value) { err.textContent = 'The two PINs do not match.'; return; } finish(a.value); };
    const m = CD.modal({ title, size: 'sm', onClose: () => finish(null), body: h('form', { onsubmit: (e) => { e.preventDefault(); go(); } }, h('p', { class: 'muted small' }, text), ui.field('PIN', a), ui.field('Confirm PIN', b), err, h('button', { type: 'submit', hidden: true })), footer: [ui.btn('Cancel', { onclick: () => finish(null) }), ui.btn('Save PIN', { kind: 'primary', onclick: go })] });
    setTimeout(() => a.focus(), 50);
  });
  const checkPin = (title) => new Promise((resolve) => {
    const a = h('input', { class: 'input', type: 'password', inputmode: 'numeric', maxlength: 6, autocomplete: 'off', 'aria-label': 'Current PIN' });
    const err = h('div', { class: 'err', role: 'alert' });
    let done = false; const finish = (v) => { if (done) return; done = true; m.close(); resolve(v); };
    const go = async () => { if (await L.verify(a.value)) finish(true); else err.textContent = 'Wrong PIN.'; };
    const m = CD.modal({ title, size: 'sm', onClose: () => finish(false), body: h('form', { onsubmit: (e) => { e.preventDefault(); go(); } }, ui.field('Current PIN', a), err, h('button', { type: 'submit', hidden: true })), footer: [ui.btn('Cancel', { onclick: () => finish(false) }), ui.btn('Continue', { kind: 'primary', onclick: go })] });
    setTimeout(() => a.focus(), 50);
  });

  CD.settingsSecurity = (secCard) => {
    const S = CD.settings;
    if (!L.supported()) return secCard('App lock', null, h('p', { class: 'muted small' }, 'App lock needs a secure (https) context, which this browser is not providing.'));
    const after = ui.select([{ value: '0', label: 'Every time I leave the app' }, { value: '1', label: 'After 1 minute away' }, { value: '5', label: 'After 5 minutes away' }, { value: '15', label: 'After 15 minutes away' }], String(S.lockAfter || 0));
    const bioRow = h('div', { class: 'btn-row' });
    const body = [];
    if (!L.enabled()) {
      body.push(h('p', { class: 'muted small' }, 'Protect ClientDesk with a PIN. It is asked each time you open the app. It stops other people using the app on your phone; it does not encrypt your data.'),
        h('div', { class: 'btn-row' }, ui.btn('Set a PIN', { kind: 'primary', icon: 'shield', onclick: async () => { const p = await askPin('Create a PIN', 'Choose 4 to 6 digits you will remember. A lost PIN cannot be recovered.'); if (!p) return; await L.setPin(p); CD.toast('App lock is on.', 'success'); CD.render(); } })));
    } else {
      body.push(h('p', { class: 'small' }, 'App lock is ', h('b', {}, 'on'), '.'), ui.field('Lock', after),
        bioRow,
        h('div', { class: 'btn-row' },
          ui.btn('Save', { kind: 'primary', icon: 'check', onclick: async () => { await CD.setSetting('lockAfter', Number(after.value)); CD.toast('Lock settings saved.'); } }),
          ui.btn('Change PIN', { onclick: async () => { if (!(await checkPin('Confirm current PIN'))) return; const p = await askPin('New PIN', 'Choose 4 to 6 digits.'); if (!p) return; await L.setPin(p); CD.toast('PIN changed.', 'success'); } }),
          ui.btn('Turn off', { kind: 'danger-ghost', onclick: async () => { if (!(await checkPin('Turn off app lock'))) return; await L.clear(); CD.toast('App lock is off.', 'info'); CD.render(); } })));
      L.bioAvailable().then((yes) => {
        if (!yes) { CD.mount(bioRow, h('p', { class: 'small muted' }, 'Fingerprint unlock is not available in this browser or build. Your PIN always works.')); return; }
        CD.mount(bioRow, CD.settings.bioId
          ? ui.btn('Turn off fingerprint', { onclick: async () => { await CD.setSetting('bioId', ''); CD.toast('Fingerprint unlock is off.', 'info'); CD.render(); } })
          : ui.btn('Use fingerprint / screen lock', { icon: 'shield', onclick: async () => { try { await L.bioEnroll(); CD.toast('Fingerprint unlock is on. Your PIN still works.', 'success'); CD.render(); } catch (e) { CD.toast('Could not set up fingerprint: ' + (e && e.message || e), 'error'); } } }));
      });
    }
    return secCard('App lock', null, ...body);
  };
})();
