/* ClientDesk — utilities: safe DOM builder, icons, dates, phone, toasts, modals */
(function () {
  'use strict';
  const CD = (window.CD = window.CD || {});
  const NS = 'http://www.w3.org/2000/svg';

  /* ---------- Safe DOM builder (never uses innerHTML with user data → XSS-safe) ---------- */
  function append(el, kids) {
    for (const k of kids.flat(Infinity)) {
      if (k == null || k === false) continue;
      el.append(k.nodeType ? k : document.createTextNode(String(k)));
    }
  }
  CD.h = function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    let value;
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'style' && typeof v === 'object') { for (const [sk, sv] of Object.entries(v)) { if (sk.startsWith('--')) el.style.setProperty(sk, sv); else el.style[sk] = sv; } }
        else if (k === 'value') value = v;
        else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (v === true) el.setAttribute(k, '');
        else el.setAttribute(k, String(v));
      }
    }
    append(el, kids);
    if (value !== undefined) el.value = value;
    return el;
  };
  const h = CD.h;
  CD.clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };
  CD.mount = (el, ...kids) => { CD.clear(el); append(el, kids); return el; };

  /* ---------- Icons (static, trusted markup only) ---------- */
  const ICONS = {
    grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    handshake: '<path d="M20 6 9 17l-5-5"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>',
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    trash: '<path d="M3 6h18M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    check: '<path d="m20 6-11 11-5-5"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
    share: '<path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8M16 6l-4-4-4 4M12 2v13"/>',
    menu: '<path d="M3 12h18M3 6h18M3 18h18"/>',
    alert: '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/>',
    archive: '<path d="M21 8v13H3V8M1 3h22v5H1zM10 12h4"/>',
    mail: '<path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="m22 6-10 7L2 6"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    msg: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    print: '<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
    refresh: '<path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    more: '<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
    wifi: '<path d="M5 12.55a11 11 0 0 1 14.08 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
    arrow: '<path d="M5 12h14M12 5l7 7-7 7"/>',
    chart: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
    dot: '<circle cx="12" cy="12" r="4"/>'
  };
  CD.icon = (name, size = 16) => {
    const s = document.createElementNS(NS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    s.setAttribute('width', size);
    s.setAttribute('height', size);
    s.setAttribute('fill', 'none');
    s.setAttribute('stroke', 'currentColor');
    s.setAttribute('stroke-width', '2');
    s.setAttribute('stroke-linecap', 'round');
    s.setAttribute('stroke-linejoin', 'round');
    s.setAttribute('aria-hidden', 'true');
    s.setAttribute('class', 'ic');
    s.innerHTML = ICONS[name] || ICONS.dot; // static trusted strings only
    return s;
  };
  CD.logo = (size = 28) => h('img', { src: 'icons/icon-192.png', width: size, height: size, alt: 'ClientDesk logo', class: 'logo-img', draggable: 'false' });

  /* ---------- IDs ---------- */
  CD.uuid = () => {
    if (window.crypto && crypto.randomUUID) { try { return crypto.randomUUID(); } catch (e) { /* insecure ctx */ } }
    const b = new Uint8Array(16); crypto.getRandomValues(b);
    b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
    const x = [...b].map((v) => v.toString(16).padStart(2, '0')).join('');
    return `${x.slice(0, 8)}-${x.slice(8, 12)}-${x.slice(12, 16)}-${x.slice(16, 20)}-${x.slice(20)}`;
  };

  /* ---------- Dates (all stored as local 'YYYY-MM-DD' and 'HH:MM') ---------- */
  const p2 = (n) => String(n).padStart(2, '0');
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const ymd = (d) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
  CD.ymd = ymd;
  CD.today = () => ymd(new Date());
  CD.nowTime = () => { const d = new Date(); return `${p2(d.getHours())}:${p2(d.getMinutes())}`; };
  CD.isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(CD.parseYMD(s));
  CD.isTime = (s) => typeof s === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
  CD.parseYMD = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  CD.addDays = (s, n) => { const d = CD.parseYMD(s); d.setDate(d.getDate() + n); return ymd(d); };
  CD.daysBetween = (a, b) => Math.round((CD.parseYMD(b) - CD.parseYMD(a)) / 86400000);
  CD.weekStart = (s) => { const d = CD.parseYMD(s); const wd = (d.getDay() + 6) % 7; d.setDate(d.getDate() - wd); return ymd(d); };
  CD.weekEnd = (s) => CD.addDays(CD.weekStart(s), 6);
  CD.monthStart = (s) => s.slice(0, 8) + '01';
  CD.monthEnd = (s) => { const d = CD.parseYMD(s); return ymd(new Date(d.getFullYear(), d.getMonth() + 1, 0)); };
  CD.localISO = (d) => `${ymd(d)}T${p2(d.getHours())}:${p2(d.getMinutes())}`;
  CD.toLocalDate = (iso) => (iso ? ymd(new Date(iso)) : '');
  CD.dateTime = (date, time) => { const d = CD.parseYMD(date); if (time) { const [H, M] = time.split(':').map(Number); d.setHours(H, M, 0, 0); } return d; };

  CD.fmtDate = (s, fmt) => {
    if (!s || !CD.isDate(s)) return '';
    fmt = fmt || (CD.settings && CD.settings.dateFormat) || 'D MMM YYYY';
    const [y, m, d] = s.split('-').map(Number);
    if (fmt === 'DD/MM/YYYY') return `${p2(d)}/${p2(m)}/${y}`;
    if (fmt === 'MM/DD/YYYY') return `${p2(m)}/${p2(d)}/${y}`;
    return `${d} ${MON[m - 1]} ${y}`;
  };
  CD.fmtDateShort = (s) => { if (!CD.isDate(s)) return ''; const f = CD.settings.dateFormat; if (f !== 'D MMM YYYY') return CD.fmtDate(s); const [, m, d] = s.split('-').map(Number); return `${d} ${MON[m - 1]}`; };
  CD.fmtTime = (t) => { if (!CD.isTime(t)) return ''; let [H, M] = t.split(':').map(Number); const ap = H >= 12 ? 'PM' : 'AM'; H = H % 12 || 12; return `${H}:${p2(M)} ${ap}`; };
  CD.fmtDT = (date, time) => [CD.fmtDate(date), CD.fmtTime(time)].filter(Boolean).join(', ');
  CD.fmtStamp = (iso) => { if (!iso) return ''; const d = new Date(iso); return CD.fmtDT(ymd(d), `${p2(d.getHours())}:${p2(d.getMinutes())}`); };
  CD.relDay = (s) => {
    if (!CD.isDate(s)) return '';
    const n = CD.daysBetween(CD.today(), s);
    if (n === 0) return 'Today'; if (n === 1) return 'Tomorrow'; if (n === -1) return 'Yesterday';
    return n > 0 ? `In ${n} days` : `${-n} days ago`;
  };
  CD.overdueText = (s) => { const n = CD.daysBetween(s, CD.today()); return n <= 0 ? 'Due today' : `${n} day${n === 1 ? '' : 's'} overdue`; };

  CD.money = (n, cur) => {
    cur = cur || (CD.settings && CD.settings.currency) || '';
    if (n == null || n === '' || isNaN(n)) return '';
    return `${cur} ${Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 })}`.trim();
  };

  /* ---------- Phone / text helpers ---------- */
  CD.normPhone = (p) => {
    let d = String(p || '').trim();
    const plus = d.startsWith('+');
    d = d.replace(/\D/g, '');
    if (!d) return '';
    if (plus) return d;
    if (d.startsWith('00')) return d.slice(2);
    if (d.startsWith('0')) return ((CD.settings && CD.settings.countryCode) || '256') + d.slice(1);
    return d;
  };
  CD.validPhone = (p) => /^[+()\d\s-]{6,25}$/.test(p) && (p.replace(/\D/g, '').length >= 7) && p.replace(/\D/g, '').length <= 15;
  CD.telHref = (p) => 'tel:' + String(p).replace(/[^\d+]/g, '');
  CD.waHref = (p, text) => `https://wa.me/${CD.normPhone(p)}${text ? '?text=' + encodeURIComponent(text) : ''}`;
  CD.validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
  CD.trunc = (s, n) => { s = String(s || '').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  CD.initials = (name) => String(name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('');
  CD.cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
  CD.plural = (n, w, pl) => `${n} ${n === 1 ? w : pl || w + 's'}`;
  CD.debounce = (fn, ms = 150) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  CD.slug = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'file';

  /* ---------- Tiny event bus ---------- */
  const bus = {};
  CD.on = (evt, fn) => { (bus[evt] = bus[evt] || new Set()).add(fn); return () => bus[evt].delete(fn); };
  CD.emit = (evt, arg) => { (bus[evt] ? [...bus[evt]] : []).forEach((fn) => { try { fn(arg); } catch (e) { console.error(e); } }); };

  /* ---------- Toasts ---------- */
  CD.toast = (msg, type = 'success', opts = {}) => {
    let box = document.getElementById('toasts');
    if (!box) { box = h('div', { id: 'toasts', 'aria-live': 'polite' }); document.body.append(box); }
    const t = h('div', { class: 'toast toast-' + type, role: type === 'error' ? 'alert' : 'status' },
      CD.icon(type === 'error' ? 'alert' : type === 'info' ? 'info' : 'check', 16),
      h('span', {}, msg),
      opts.action ? h('button', { type: 'button', class: 'toast-act', onclick: () => { opts.action.fn(); t.remove(); } }, opts.action.label) : null,
      h('button', { type: 'button', class: 'toast-x', 'aria-label': 'Dismiss', onclick: () => t.remove() }, CD.icon('x', 14)));
    box.append(t);
    setTimeout(() => t.remove(), opts.ms || (type === 'error' ? 7000 : 4000));
    return t;
  };

  /* ---------- Modals ---------- */
  const stack = [];
  CD.modal = function modal(opts) {
    const { title, size = 'md', body, footer, live = false, onClose, locked = false } = opts;
    const prevFocus = document.activeElement;
    const overlay = h('div', { class: 'modal-overlay' });
    const titleEl = h('h2', {}, title);
    const bodyEl = h('div', { class: 'modal-body' });
    const footEl = footer ? h('div', { class: 'modal-foot' }) : null;
    const dlg = h('div', { class: 'modal modal-' + size, role: 'dialog', 'aria-modal': 'true' },
      h('div', { class: 'modal-head' }, titleEl, locked ? null : h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Close', onclick: () => api.close() }, CD.icon('x'))),
      bodyEl, footEl);
    overlay.append(dlg);
    let off = null, closed = false;
    const api = {
      el: dlg, body: bodyEl, locked,
      setTitle: (t) => { titleEl.textContent = t; },
      render() {
        const top = bodyEl.scrollTop;
        CD.mount(bodyEl, typeof body === 'function' ? body(api) : body);
        bodyEl.scrollTop = top;
        if (footEl) CD.mount(footEl, typeof footer === 'function' ? footer(api) : footer);
      },
      close() {
        if (closed) return; closed = true;
        if (off) off();
        const i = stack.indexOf(api); if (i >= 0) stack.splice(i, 1);
        overlay.remove();
        if (!stack.length) document.body.classList.remove('modal-open');
        try { if (prevFocus && prevFocus.focus && document.contains(prevFocus)) prevFocus.focus(); } catch (e) { /* ignore */ }
        if (onClose) onClose();
      }
    };
    api.render();
    if (live) off = CD.on('change', () => api.render());
    stack.push(api);
    document.body.append(overlay);
    document.body.classList.add('modal-open');
    const af = dlg.querySelector('[autofocus]'); if (af) setTimeout(() => af.focus(), 30);
    return api;
  };
  CD.closeTopModal = () => { if (!stack.length) return false; if (!stack[stack.length - 1].locked) stack[stack.length - 1].close(); return true; };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && stack.length && !stack[stack.length - 1].locked) stack[stack.length - 1].close(); });
  CD.closeAllModals = () => [...stack].forEach((m) => m.close());

  CD.confirm = ({ title = 'Are you sure?', message, confirmText = 'Confirm', cancelText = 'Cancel', danger = false, extra = null }) =>
    new Promise((resolve) => {
      let done = false;
      const finish = (v) => { if (done) return; done = true; resolve(v); m.close(); };
      const m = CD.modal({
        title, size: 'sm',
        body: h('div', {}, h('p', { class: 'confirm-msg' }, message), extra),
        footer: [h('button', { class: 'btn', type: 'button', onclick: () => finish(false) }, cancelText),
          h('button', { class: 'btn ' + (danger ? 'btn-danger' : 'btn-primary'), type: 'button', autofocus: true, onclick: () => finish(true) }, confirmText)],
        onClose: () => finish(false)
      });
    });

  /* ---------- File helpers ---------- */
  CD.downloadBlob = (blob, filename) => {
    if (CD.native && CD.native.isNative()) { CD.native.saveBlob(blob, filename).catch((e) => CD.toast('Could not save the file: ' + (e && e.message || e), 'error')); return; }
    const url = URL.createObjectURL(blob);
    const a = h('a', { href: url, download: filename, style: { display: 'none' } });
    document.body.append(a); a.click();
    setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 4000);
  };
  CD.copyText = async (text) => {
    try { await navigator.clipboard.writeText(text); return true; } catch (e) {
      const ta = h('textarea', { style: { position: 'fixed', opacity: '0' } }); ta.value = text; document.body.append(ta); ta.select();
      let ok = false; try { ok = document.execCommand('copy'); } catch (e2) { /* ignore */ } ta.remove(); return ok;
    }
  };
})();
