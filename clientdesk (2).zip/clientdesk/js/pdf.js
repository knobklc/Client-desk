/* ClientDesk — minimal dependency-free PDF writer (A4, Helvetica, tables, page numbers).
 * Written in-house so the app has no third-party libraries and generates PDFs fully offline. */
(function () {
  'use strict';
  const CD = window.CD;

  // Helvetica / Helvetica-Bold advance widths for ASCII 32..126 (units per 1000 em)
  const W_REG = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584];
  const W_BLD = [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556, 333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584];
  const WIN = { 0x20AC: 0x80, 0x201A: 0x82, 0x192: 0x83, 0x201E: 0x84, 0x2026: 0x85, 0x2020: 0x86, 0x2021: 0x87, 0x2C6: 0x88, 0x2030: 0x89, 0x160: 0x8A, 0x2039: 0x8B, 0x152: 0x8C, 0x17D: 0x8E, 0x2018: 0x91, 0x2019: 0x92, 0x201C: 0x93, 0x201D: 0x94, 0x2022: 0x95, 0x2013: 0x96, 0x2014: 0x97, 0x2DC: 0x98, 0x2122: 0x99, 0x161: 0x9A, 0x203A: 0x9B, 0x153: 0x9C, 0x17E: 0x9E, 0x178: 0x9F };

  // Normalise to characters representable in WinAnsi (one byte each)
  function enc(s) {
    let o = '';
    for (const ch of String(s == null ? '' : s)) {
      const c = ch.codePointAt(0);
      if (c === 9) o += ' ';
      else if (c < 32) o += '';
      else if (c < 127 || (c >= 128 && c <= 255)) o += ch; // 128-159: already WinAnsi (idempotent)
      else if (WIN[c]) o += String.fromCharCode(WIN[c]);
      else o += '?';
    }
    return o;
  }
  const esc = (s) => s.replace(/[\\()]/g, (m) => '\\' + m);
  const hex2rgb = (h) => { h = h.replace('#', ''); return [0, 2, 4].map((i) => (parseInt(h.slice(i, i + 2), 16) / 255).toFixed(3)).join(' '); };

  class PDF {
    constructor(meta = {}) {
      this.W = 595.28; this.H = 841.89; this.meta = meta;
      this.pages = []; this.addPage();
    }
    addPage() { this.cur = []; this.pages.push(this.cur); return this.pages.length; }
    width(str, size, bold) {
      const t = bold ? W_BLD : W_REG; let w = 0;
      for (const ch of enc(str)) { const c = ch.charCodeAt(0); w += (c >= 32 && c <= 126 ? t[c - 32] : 556); }
      return (w * size) / 1000;
    }
    /** wrap text to maxW; honours \n and hard-breaks very long words */
    wrap(str, maxW, size, bold) {
      const out = [];
      for (const para of enc(str).split('\n')) {
        let line = '';
        for (let word of para.split(/ +/)) {
          if (!word) continue;
          while (this.width(word, size, bold) > maxW) { // hard break
            let i = word.length - 1; while (i > 1 && this.width(word.slice(0, i), size, bold) > maxW) i--;
            if (line) { out.push(line); line = ''; }
            out.push(word.slice(0, i)); word = word.slice(i);
          }
          const test = line ? line + ' ' + word : word;
          if (this.width(test, size, bold) <= maxW) line = test; else { if (line) out.push(line); line = word; }
        }
        out.push(line);
      }
      return out.length ? out : [''];
    }
    /** y = baseline measured from the TOP of the page */
    text(str, x, y, { size = 10, bold = false, color = '#202938', align = 'left', width: boxW } = {}) {
      const s = enc(str); if (!s) return;
      if (align === 'right') x = x + (boxW || 0) - this.width(s, size, bold);
      else if (align === 'center') x = x + ((boxW || 0) - this.width(s, size, bold)) / 2;
      this.cur.push(`BT /${bold ? 'F2' : 'F1'} ${size} Tf ${hex2rgb(color)} rg ${x.toFixed(2)} ${(this.H - y).toFixed(2)} Td (${esc(s)}) Tj ET`);
    }
    rect(x, y, w, h, { fill, stroke, lw = 0.6 } = {}) {
      const ops = [];
      if (fill) ops.push(`${hex2rgb(fill)} rg`);
      if (stroke) ops.push(`${hex2rgb(stroke)} RG ${lw} w`);
      ops.push(`${x.toFixed(2)} ${(this.H - y - h).toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re ${fill && stroke ? 'B' : fill ? 'f' : 'S'}`);
      this.cur.push(ops.join(' '));
    }
    line(x1, y1, x2, y2, { color = '#E4E7EC', lw = 0.6 } = {}) {
      this.cur.push(`${hex2rgb(color)} RG ${lw} w ${x1.toFixed(2)} ${(this.H - y1).toFixed(2)} m ${x2.toFixed(2)} ${(this.H - y2).toFixed(2)} l S`);
    }
    build() {
      const objs = []; // index = obj number - 1
      const add = (s) => { objs.push(s); return objs.length; };
      add('<< /Type /Catalog /Pages 2 0 R >>');
      add(''); // pages placeholder
      add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
      add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
      const kids = [];
      for (const ops of this.pages) {
        const stream = ops.join('\n');
        const cid = objs.length + 2;
        const pid = add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${this.W} ${this.H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${cid} 0 R >>`);
        add(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
        kids.push(`${pid} 0 R`);
      }
      objs[1] = `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${kids.length} >>`;
      const d = new Date();
      const pdate = `D:${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, '0')}${String(d.getUTCDate()).padStart(2, '0')}${String(d.getUTCHours()).padStart(2, '0')}${String(d.getUTCMinutes()).padStart(2, '0')}00Z`;
      const info = add(`<< /Title (${esc(enc(this.meta.title || 'Report'))}) /Author (${esc(enc(this.meta.author || ''))}) /Creator (ClientDesk) /Producer (ClientDesk) /CreationDate (${pdate}) >>`);
      let out = '%PDF-1.4\n%\xE2\xE3\xCF\xD3\n'; const offs = [];
      objs.forEach((o, i) => { offs.push(out.length); out += `${i + 1} 0 obj\n${o}\nendobj\n`; });
      const xref = out.length;
      out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offs.map((o) => String(o).padStart(10, '0') + ' 00000 n \n').join('');
      out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R /Info ${info} 0 R >>\nstartxref\n${xref}\n%%EOF`;
      const u8 = new Uint8Array(out.length);
      for (let i = 0; i < out.length; i++) u8[i] = out.charCodeAt(i) & 0xff;
      return u8;
    }
    toBlob() { return new Blob([this.build()], { type: 'application/pdf' }); }
  }
  CD.PDF = PDF;

  /* ---------- Report model → A4 PDF ---------- */
  const C = { ink: '#202938', mute: '#667085', line: '#E4E7EC', navy: '#172333', blue: '#2563EB', zebra: '#F8F9FB', danger: '#B42318' };

  CD.reportToPDF = (m) => {
    const doc = new PDF({ title: `${m.title} — ${m.periodLabel}`, author: m.preparedBy });
    const ML = 40, MR = 40, CW = doc.W - ML - MR, TOP = 44, BOT = doc.H - 52;
    let y = TOP;
    const ensure = (h) => { if (y + h > BOT) { doc.addPage(); y = TOP; return true; } return false; };

    /* Header */
    if (m.orgName) doc.text(m.orgName.toUpperCase(), ML, y + 8, { size: 9, bold: true, color: C.mute });
    doc.text(`Generated ${m.generatedLabel}`, ML, y + 8, { size: 8.5, color: C.mute, align: 'right', width: CW });
    y += 26;
    if (m.heading) { doc.text(m.heading, ML, y, { size: 10, color: C.blue, bold: true }); y += 24; }
    for (const l of doc.wrap(m.title, CW, 21, true)) { doc.text(l, ML, y, { size: 21, bold: true, color: C.navy }); y += 25; }
    doc.text(m.periodLabel, ML, y, { size: 11, color: C.ink }); y += 10;
    doc.rect(ML, y, CW, 2, { fill: C.blue }); y += 14;

    /* Meta block */
    const meta = [['Prepared by', m.preparedBy || '—'], ['Job title', m.jobTitle || '—'], ['Supervisor', m.supervisor || '—'], ['Scope', m.scopeLabel || 'All clients']];
    const mw = CW / 4;
    meta.forEach(([k, v], i) => {
      doc.text(k.toUpperCase(), ML + i * mw, y + 7, { size: 7, bold: true, color: C.mute });
      doc.wrap(v, mw - 8, 9.5, false).slice(0, 2).forEach((l, j) => doc.text(l, ML + i * mw, y + 19 + j * 11, { size: 9.5 }));
    });
    y += 42;
    if (m.demoNote) {
      doc.rect(ML, y, CW, 20, { fill: '#FFFAEB', stroke: '#F5D58A' });
      doc.text(m.demoNote, ML + 8, y + 13.5, { size: 8.5, color: '#93370D' }); y += 30;
    }

    /* Stats grid (4 per row) */
    if (m.stats && m.stats.length) {
      const cols = 4, gw = CW / cols, gh = 46;
      const rows = Math.ceil(m.stats.length / cols);
      ensure(rows * gh + 24);
      doc.text('SUMMARY', ML, y + 8, { size: 8, bold: true, color: C.mute }); y += 14;
      m.stats.forEach((s, i) => {
        const cx = ML + (i % cols) * gw, cy = y + Math.floor(i / cols) * gh;
        doc.rect(cx + (i % cols ? 0 : 0), cy, gw, gh, { stroke: C.line, fill: s.warn ? '#FEF3F2' : '#FFFFFF' });
        doc.text(String(s.value), cx + 9, cy + 24, { size: 16, bold: true, color: s.warn ? C.danger : C.navy });
        const lines = doc.wrap(s.label + (s.note ? '' : ''), gw - 14, 7.8, false).slice(0, 2);
        lines.forEach((l, j) => doc.text(l, cx + 9, cy + 34 + j * 8.5 - (lines.length > 1 ? 3 : 0), { size: 7.8, color: C.mute }));
      });
      y += rows * gh + 8;
      if (m.statsFootnote) { doc.text(m.statsFootnote, ML, y + 7, { size: 7.5, color: C.mute }); y += 12; }
      y += 8;
    }

    /* Sections */
    for (const sec of m.sections) {
      ensure(60);
      doc.text(sec.heading, ML, y + 10, { size: 12, bold: true, color: C.navy });
      y += 15; doc.line(ML, y, ML + CW, y, { color: C.line, lw: 0.8 }); y += 8;
      if (sec.intro) { for (const l of doc.wrap(sec.intro, CW, 8.5, false)) { ensure(12); doc.text(l, ML, y + 8, { size: 8.5, color: C.mute }); y += 11; } y += 4; }
      if (sec.kv) {
        sec.kv.forEach(([k, v]) => {
          const lines = doc.wrap(v || '—', CW - 110, 9, false); ensure(lines.length * 12 + 2);
          doc.text(k, ML, y + 9, { size: 9, bold: true, color: C.mute });
          lines.forEach((l, i) => doc.text(l, ML + 110, y + 9 + i * 12, { size: 9 }));
          y += lines.length * 12 + 2;
        });
        y += 6;
      }
      if (sec.table) {
        const t = sec.table, total = t.cols.reduce((a, c) => a + c.w, 0);
        const widths = t.cols.map((c) => (c.w / total) * CW), pad = 4, fs = 8, lh = 10;
        const drawHead = () => {
          doc.rect(ML, y, CW, 17, { fill: C.navy });
          let x = ML; t.cols.forEach((c, i) => { doc.text(c.label, x + pad, y + 11.5, { size: 7.5, bold: true, color: '#FFFFFF', align: c.align || 'left', width: widths[i] - pad * 2 }); x += widths[i]; });
          y += 17;
        };
        ensure(17 + 24); drawHead();
        if (!t.rows.length) { doc.text(t.empty || 'No records.', ML + pad, y + 13, { size: 9, color: C.mute }); y += 22; }
        t.rows.forEach((row, ri) => {
          const cells = row.map((cell, i) => doc.wrap(String(cell == null ? '' : cell), widths[i] - pad * 2, fs, false));
          const rh = Math.max(...cells.map((c) => c.length)) * lh + 7;
          if (y + rh > BOT) { doc.addPage(); y = TOP; drawHead(); }
          if (ri % 2) doc.rect(ML, y, CW, rh, { fill: C.zebra });
          let x = ML;
          cells.forEach((lines, i) => {
            const flag = t.flagCol === i && /overdue|broken|urgent/i.test(row[i]);
            lines.forEach((l, j) => doc.text(l, x + pad, y + 10 + j * lh, { size: fs, align: t.cols[i].align || 'left', width: widths[i] - pad * 2, color: flag ? C.danger : C.ink, bold: flag }));
            x += widths[i];
          });
          doc.line(ML, y + rh, ML + CW, y + rh, { color: C.line, lw: 0.4 });
          y += rh;
        });
        if (t.note) { doc.text(t.note, ML, y + 11, { size: 7.5, color: C.mute }); y += 14; }
        y += 10;
      }
      if (sec.bullets) {
        if (!sec.bullets.length) { doc.text(sec.empty || 'None.', ML, y + 9, { size: 9, color: C.mute }); y += 16; }
        sec.bullets.forEach((b) => {
          const lines = doc.wrap(b, CW - 14, 9.2, false); ensure(lines.length * 12 + 3);
          doc.text('•', ML + 2, y + 9.5, { size: 9.2 });
          lines.forEach((l, i) => doc.text(l, ML + 14, y + 9.5 + i * 12, { size: 9.2 }));
          y += lines.length * 12 + 3;
        });
        y += 8;
      }
    }

    /* Sign-off */
    ensure(78);
    y += 10;
    const half = CW / 2 - 14;
    [[ 'Prepared by', m.preparedBy, m.jobTitle ], ['Reviewed by', m.supervisor, 'Supervisor']].forEach(([lab, name, sub], i) => {
      const x = ML + i * (half + 28);
      doc.line(x, y + 30, x + half, y + 30, { color: C.mute, lw: 0.6 });
      doc.text(lab.toUpperCase(), x, y + 41, { size: 7, bold: true, color: C.mute });
      doc.text([name, sub].filter(Boolean).join(' — ') || ' ', x, y + 52, { size: 9 });
    });

    /* Footer on every page */
    const n = doc.pages.length;
    doc.pages.forEach((ops, i) => {
      doc.cur = ops;
      doc.line(ML, doc.H - 38, doc.W - MR, doc.H - 38, { color: C.line });
      doc.text(CD.trunc([m.orgName, m.title].filter(Boolean).join(' · '), 90), ML, doc.H - 26, { size: 7.5, color: C.mute });
      doc.text(`Page ${i + 1} of ${n}`, ML, doc.H - 26, { size: 7.5, color: C.mute, align: 'right', width: CW });
    });
    return doc;
  };
})();
