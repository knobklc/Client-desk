/* ClientDesk — app shell, router, theme, offline/online status, reminders ticker, service worker */
(function () {
  'use strict';
  const CD = window.CD, h = CD.h, ui = CD.ui;

  const NAV = [['dashboard', 'Dashboard', 'grid'], ['clients', 'Clients', 'users'], ['calls', 'Call Logs', 'phone'], ['followups', 'Follow-ups', 'calendar'], ['promises', 'Promises & Commitments', 'shield'], ['analytics', 'Analytics', 'chart'], ['reports', 'Reports', 'file'], ['reminders', 'Reminders', 'bell'], ['settings', 'Settings', 'sliders']];
  const BOTTOM = ['dashboard', 'clients', 'calls', 'followups', 'promises'];
  const SHORT = { promises: 'Promises', calls: 'Calls' };
  let current = 'dashboard', deferredInstall = null;
  const refs = {};

  /* ---------- Theme ---------- */
  const mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  CD.applyTheme = () => {
    const t = (CD.settings && CD.settings.theme) || 'system';
    const dark = t === 'dark' || (t === 'system' && mq && mq.matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    const m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = dark ? '#0B121B' : '#172333';
  };
  if (mq && mq.addEventListener) mq.addEventListener('change', () => CD.applyTheme());

  /* ---------- Online / offline ---------- */
  const setOnline = () => {
    const on = navigator.onLine;
    document.querySelectorAll('.net').forEach((el) => { el.classList.toggle('off', !on); el.querySelector('.net-t').textContent = on ? 'Online' : 'Offline'; el.title = on ? 'Connected. ClientDesk also works without internet.' : 'No internet — everything still works and is saved on this device.'; });
    document.body.classList.toggle('is-offline', !on);
  };
  const netPill = () => h('span', { class: 'net', role: 'status', 'aria-live': 'polite' }, h('span', { class: 'net-dot' }), h('span', { class: 'net-t' }, 'Online'));
  window.addEventListener('online', () => { setOnline(); CD.toast('Back online.', 'info'); });
  window.addEventListener('offline', () => { setOnline(); CD.toast('You are offline. Everything still works and is saved on this device.', 'info'); });

  /* ---------- Install prompt ---------- */
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredInstall = e; if (refs.install) refs.install.hidden = false; });
  window.addEventListener('appinstalled', () => { deferredInstall = null; if (refs.install) refs.install.hidden = true; CD.toast('ClientDesk installed.'); });
  CD.canInstall = () => !!deferredInstall;
  CD.promptInstall = async () => { if (!deferredInstall) return; deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; if (refs.install) refs.install.hidden = true; };

  /* ---------- Service worker ---------- */
  CD.swStatus = async () => {
    if (!('serviceWorker' in navigator)) return 'Not supported by this browser — the app may not work offline.';
    if (!window.isSecureContext) return 'Unavailable on this address. Open the app over HTTPS (or localhost) once to enable offline use.';
    try { const reg = await navigator.serviceWorker.getRegistration(); if (reg && reg.active) return 'Ready — app files are saved on this device and work without internet.'; return 'Setting up offline mode…'; } catch (e) { return 'Could not check offline status.'; }
  };
  function registerSW() {
    if (!('serviceWorker' in navigator) || !window.isSecureContext || (CD.native && CD.native.isNative())) return;
    navigator.serviceWorker.register('sw.js').then((reg) => {
      reg.addEventListener('updatefound', () => {
        const nw = reg.installing; if (!nw) return;
        nw.addEventListener('statechange', () => {
          if (nw.state === 'installed' && navigator.serviceWorker.controller) CD.toast('A new version of ClientDesk is ready.', 'info', { ms: 20000, action: { label: 'Reload', fn: () => nw.postMessage('SKIP_WAITING') } });
        });
      });
    }).catch((e) => console.warn('SW registration failed', e));
    let reloading = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => { if (reloading || !CD.__hadController) return; reloading = true; location.reload(); });
    CD.__hadController = !!navigator.serviceWorker.controller;
  }

  /* ---------- Notifications ---------- */
  CD.notifState = () => (CD.native && CD.native.isNative() ? CD.native.perm : 'Notification' in window ? Notification.permission : 'unsupported');
  CD.requestNotifications = async () => {
    if (CD.native && CD.native.isNative()) return CD.native.requestNotifications();
    if (!('Notification' in window)) return 'unsupported';
    let r; try { r = await Notification.requestPermission(); } catch (e) { r = Notification.permission; }
    await CD.setSetting('notify', r === 'granted'); return r;
  };
  async function showNotification(r) {
    if (CD.native && CD.native.isNative()) return; // the OS already fires the scheduled native notification
    if (CD.notifState() !== 'granted' || !CD.settings.notify) return;
    const opts = { body: [CD.fmtTime(r.time), r.note].filter(Boolean).join(' – '), tag: r.id, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', data: { url: './#/reminders' } };
    try { const reg = 'serviceWorker' in navigator ? await navigator.serviceWorker.getRegistration() : null; if (reg) await reg.showNotification(r.title, opts); else new Notification(r.title, opts); } catch (e) { console.warn('Notification failed', e); }
  }
  function tick(first) {
    if (!CD.settings || !CD.data) return;
    const due = CD.data.reminders.filter((r) => CD.remTriggered(r) && !r.notifiedAt);
    if (due.length) {
      const now = new Date().toISOString();
      const fresh = due.filter((r) => !first || Date.now() - CD.remAlertAt(r) < 12 * 3600e3);
      due.forEach((r) => CD.put('reminders', { ...r, notifiedAt: now }, { silent: true }).catch(() => {}));
      if (fresh.length) {
        CD.toast(fresh.length === 1 ? `Reminder: ${fresh[0].title}` : `${fresh.length} reminders are due.`, 'info', { ms: 12000, action: { label: 'Open', fn: () => { location.hash = '#/reminders'; } } });
        fresh.slice(0, 3).forEach(showNotification);
        if (fresh.length > 3) showNotification({ id: 'many', title: `${fresh.length} reminders are due`, note: 'Open ClientDesk to see them.', time: '' });
      }
    }
    updateChrome();
    if (current === 'reminders' && due.length) CD.render();
  }

  /* ---------- Shell ---------- */
  function buildShell() {
    const sidebar = h('aside', { id: 'sidebar', 'aria-label': 'Main navigation' },
      h('div', { class: 'brand' }, CD.logo(36), h('div', {}, h('b', {}, 'ClientDesk'), h('small', {}, 'Client follow-up tracker'))),
      h('nav', { class: 'nav' }, ...NAV.map(([id, label, icon]) => h('a', { href: '#/' + id, class: 'nav-i', 'data-route': id, onclick: closeDrawer }, CD.icon(icon, 17), h('span', {}, label), h('span', { class: 'nav-badge', 'data-badge': id, hidden: true })))),
      h('div', { class: 'side-foot' }, netPill(), refs.install = ui.btn('Install app', { sm: true, icon: 'download', onclick: CD.promptInstall }), h('small', {}, 'v' + CD.VERSION + ' · by ' + CD.LEGAL.creator), h('button', { class: 'side-link', type: 'button', onclick: () => CD.showLegal('privacy') }, 'Privacy & terms')));
    refs.install.hidden = !deferredInstall;
    refs.title = h('h1', { class: 'top-title' });
    refs.bell = h('a', { href: '#/reminders', class: 'icon-btn bell', title: 'Reminders', 'aria-label': 'Reminders' }, CD.icon('bell', 18), h('span', { class: 'bell-badge', hidden: true }));
    const top = h('header', { id: 'topbar' }, h('button', { class: 'icon-btn menu-btn', type: 'button', 'aria-label': 'Open menu', onclick: openDrawer }, CD.icon('menu', 20)), refs.title, h('div', { class: 'grow' }), netPill(), refs.bell,
      h('button', { class: 'btn btn-primary top-call', type: 'button', onclick: () => CD.openCallForm() }, CD.icon('phone', 16), h('span', {}, 'Log call')));
    refs.view = h('main', { id: 'view', tabindex: '-1' });
    const bottom = h('nav', { id: 'bottomnav', 'aria-label': 'Quick navigation' }, ...BOTTOM.map((id) => { const [, label, icon] = NAV.find((n) => n[0] === id); return h('a', { href: '#/' + id, class: 'bn-i', 'data-route': id }, CD.icon(icon, 20), h('span', {}, SHORT[id] || label), h('span', { class: 'nav-badge', 'data-badge': id, hidden: true })); }));
    const backdrop = h('div', { id: 'backdrop', onclick: closeDrawer });
    CD.mount(document.getElementById('app'), sidebar, h('div', { id: 'main' }, top, refs.view, bottom), backdrop);
    setOnline();
  }
  const openDrawer = () => document.body.classList.add('drawer-open');
  const closeDrawer = () => document.body.classList.remove('drawer-open');

  function updateChrome() {
    const st = CD.stats();
    const open = CD.data.reminders.filter((r) => CD.remTriggered(r)).length;
    const set = (id, n, danger) => document.querySelectorAll(`[data-badge="${id}"]`).forEach((b) => { b.hidden = !n; b.textContent = n > 99 ? '99+' : n; b.classList.toggle('danger', !!danger); });
    set('followups', st.fuOverdue, true); set('promises', st.promOverdue, true); set('reminders', open, true);
    if (refs.bell) { const b = refs.bell.querySelector('.bell-badge'); b.hidden = !open; b.textContent = open; }
  }

  /* ---------- Router ---------- */
  const routeName = () => { const r = (location.hash || '').replace(/^#\/?/, '').split('?')[0]; return NAV.some((n) => n[0] === r) ? r : 'dashboard'; };
  CD.render = () => {
    if (!refs.view) return;
    const [, label] = NAV.find((n) => n[0] === current);
    refs.title.textContent = label;
    document.title = `${label} · ClientDesk`;
    document.querySelectorAll('[data-route]').forEach((a) => { const on = a.dataset.route === current; a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    const y = refs.view.scrollTop;
    try { CD.mount(refs.view, CD.views[current]()); } catch (e) { console.error(e); CD.mount(refs.view, h('div', { class: 'card' }, ui.empty('alert', 'This screen could not be displayed', String(e && e.message || e), ui.btn('Go to dashboard', { onclick: () => { location.hash = '#/dashboard'; } })))); }
    refs.view.scrollTop = y;
    updateChrome();
  };
  function route() { const r = routeName(); const changed = r !== current; current = r; CD.render(); if (changed) { refs.view.scrollTop = 0; window.scrollTo(0, 0); } closeDrawer(); }
  window.addEventListener('hashchange', route);

  let raf = 0;
  CD.on('change', () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => CD.render()); });
  CD.on('settings', () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => CD.render()); });

  /* ---------- Multi-tab consistency ---------- */
  function setupBroadcast() {
    if (!('BroadcastChannel' in window)) return;
    const bc = new BroadcastChannel('clientdesk'); let remote = false;
    const send = () => { if (!remote) bc.postMessage('changed'); };
    CD.on('change', send); CD.on('settings', send);
    bc.onmessage = async () => { remote = true; try { await CD.reloadAll(); CD.emit('change'); } finally { remote = false; } };
  }

  /* ---------- First run & daily overview ---------- */
  function onboarding() {
    const name = h('input', { class: 'input', placeholder: 'e.g. Grace Nakato', maxlength: 80, autofocus: true });
    const org = h('input', { class: 'input', placeholder: 'e.g. Kampala Credit Ltd', maxlength: 120 });
    let m, finished = false;
    const finish = async (demo) => { if (finished) return; finished = true; await CD.batch(async () => { if (val(name)) await CD.setSetting('userName', val(name)); if (val(org)) await CD.setSetting('org', val(org)); await CD.setSetting('onboarded', true); if (demo) await CD.loadDemoData(); }); m.close(); if (demo) CD.toast('Demonstration data loaded. Remove it any time in Settings.', 'info'); };
    const val = (el) => el.value.trim();
    m = CD.modal({ title: 'Welcome to ClientDesk', size: 'md', body: h('div', {},
      h('p', {}, 'Log calls, track what clients promise, schedule follow-ups and send reports to your supervisor — all of it works without internet.'),
      h('div', { class: 'row' }, ui.field('Your name', name), ui.field('Company / organisation', org)),
      h('p', { class: 'small muted' }, 'Your information is stored only in this browser on this device. Nothing is sent anywhere. Use Settings → Backup regularly. You can change these details later.')),
      footer: [ui.btn('Explore with demo data', { onclick: () => finish(true) }), ui.btn('Start with my own data', { kind: 'primary', onclick: () => finish(false) })], onClose: () => finish(false) });
  }
  function dailyOverview() {
    const today = CD.today(), S = CD.settings;
    if (!S.dailyOverview || S.lastOverviewDate === today || !S.onboarded) return;
    const f = CD.data.followups.filter((x) => CD.fuOpen(x) && x.date === today).length, o = CD.data.followups.filter(CD.fuOverdue).length, p = CD.data.promises.filter(CD.promiseOverdue).length;
    CD.setSetting('lastOverviewDate', today);
    if (!f && !o && !p) return;
    const line = (n, label, bad) => h('div', { class: 'ov-row' + (bad && n ? ' bad' : '') }, h('b', {}, n), h('span', {}, label));
    const m = CD.modal({ title: 'Today’s overview', size: 'sm', body: h('div', {}, h('p', { class: 'muted' }, CD.fmtDate(today)), line(f, 'follow-ups scheduled for today'), line(o, 'overdue follow-ups', true), line(p, 'overdue promises', true)),
      footer: [ui.btn('Close', { onclick: () => m.close() }), ui.btn('Open follow-ups', { kind: 'primary', onclick: () => { m.close(); FVtoday(); } })] });
  }
  const FVtoday = () => { location.hash = '#/followups'; };

  /* ---------- Boot ---------- */
  window.addEventListener('error', (e) => { console.error(e.error || e.message); });
  window.addEventListener('unhandledrejection', (e) => { console.error(e.reason); CD.toast('Something went wrong: ' + ((e.reason && e.reason.message) || e.reason), 'error'); });

  async function boot() {
    CD.applyTheme();
    try { await CD.dbOpen(); }
    catch (e) {
      console.error(e);
      CD.mount(document.getElementById('app'), h('div', { class: 'fatal' }, h('h1', {}, 'ClientDesk cannot start'), h('p', {}, String(e && e.message || e)), h('p', { class: 'muted' }, 'This usually happens in private/incognito windows or when the browser blocks site storage. Open the app in a normal browser window and allow storage for this site.')));
      return;
    }
    CD.applyTheme();
    buildShell();
    if (CD.memoryMode) setTimeout(() => CD.toast('Preview mode: this browser blocks storage, so nothing you enter is saved after you close this page.', 'info', { ms: 15000 }), 500);
    current = routeName(); CD.render();
    window.__clientdeskReady = true; // UI is on screen (consent/onboarding dialogs may follow)
    registerSW(); setupBroadcast();
    if (CD.native) await CD.native.start();
    tick(true); setInterval(() => tick(false), 20000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) tick(false); });
    window.addEventListener('focus', () => tick(false));
    if (CD.lock && CD.lock.enabled()) await CD.lock.show();
    if (!CD.hasConsent()) await CD.consentScreen();
    if (!CD.settings.onboarded) onboarding(); else setTimeout(dailyOverview, 600);
    setTimeout(() => CD.checkPendingCall && CD.checkPendingCall(), 800);
    if (CD.maybeWeeklyPrompt) { setTimeout(CD.maybeWeeklyPrompt, 2500); setInterval(CD.maybeWeeklyPrompt, 600000); }
    if (CD.handleSharedText) CD.handleSharedText();
    document.documentElement.classList.add('ready');
    window.__clientdeskReady = true;
  }
  boot();
})();
