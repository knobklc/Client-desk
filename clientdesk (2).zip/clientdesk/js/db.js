/* ClientDesk — IndexedDB persistence layer, in-memory cache, migrations, import/export.
 *
 * Sync-readiness: every record has a UUID `id`, `created_at`, `updated_at` (ISO UTC).
 * Every write/delete also appends an entry to the `changes` outbox store in the SAME
 * transaction, so a future sync engine can push exactly what changed since last sync.
 */
(function () {
  'use strict';
  const CD = (window.CD = window.CD || {});

  const DB_NAME = 'clientdesk';
  const DB_VERSION = 1;
  CD.SCHEMA_VERSION = DB_VERSION;

  // Record stores (data) and the allowed fields for each ('s' string, 'n' number, 'b' boolean).
  const BASE = { id: 's', created_at: 's', updated_at: 's', demo: 'b' };
  const SCHEMA = {
    clients: { ...BASE, name: 's', phone: 's', phoneNorm: 's', altPhone: 's', altNorm: 's', company: 's', email: 's', address: 's', category: 's', registered: 's', notes: 's', status: 's' },
    calls: { ...BASE, clientId: 's', date: 's', time: 's', direction: 's', outcome: 's', summary: 's', details: 's', response: 's', action: 's', nextFollowUp: 's', notes: 's', source: 's', extId: 's', durationSec: 'n' },
    promises: { ...BASE, clientId: 's', callId: 's', description: 's', dateMade: 's', expectedDate: 's', amount: 'n', amountFulfilled: 'n', category: 's', notes: 's', status: 's', fulfilledAt: 's', remind: 'b' },
    promiseEvents: { ...BASE, promiseId: 's', at: 's', type: 's', fromStatus: 's', toStatus: 's', fromDate: 's', toDate: 's', amount: 'n', note: 's' },
    followups: { ...BASE, clientId: 's', reason: 's', relatedType: 's', relatedId: 's', date: 's', time: 's', priority: 's', status: 's', result: 's', completedDate: 's', completedAt: 's', notes: 's' },
    reminders: { ...BASE, title: 's', note: 's', date: 's', time: 's', clientId: 's', followupId: 's', promiseId: 's', done: 'b', doneAt: 's', snoozedUntil: 's', notifiedAt: 's' }
  };
  CD.STORES = Object.keys(SCHEMA);

  // Versioned migrations. Add `2(db, tx, oldVersion) {...}` etc. here for future schema changes;
  // they run in order for every version between the user's old DB and DB_VERSION.
  const MIGRATIONS = {
    1(db) {
      const mk = (name, idx) => { const s = db.createObjectStore(name, { keyPath: 'id' }); (idx || []).forEach((i) => s.createIndex(i, i)); return s; };
      mk('clients', ['phoneNorm', 'status']);
      mk('calls', ['clientId', 'date']);
      mk('promises', ['clientId', 'status', 'expectedDate']);
      mk('promiseEvents', ['promiseId']);
      mk('followups', ['clientId', 'date', 'status']);
      mk('reminders', ['date', 'done']);
      db.createObjectStore('settings', { keyPath: 'key' });
      db.createObjectStore('changes', { keyPath: 'seq', autoIncrement: true });
    }
  };

  let db = null;
  CD.data = { clients: [], calls: [], promises: [], promiseEvents: [], followups: [], reminders: [] };
  CD.settings = {};
  CD.DEFAULTS = {
    userName: '', org: '', jobTitle: '', supervisor: '', supervisorEmail: '', supervisorPhone: '',
    reportTitle: 'Client Communication Report', dateFormat: 'D MMM YYYY', currency: 'UGX', countryCode: '256',
    theme: 'system', notify: true, leadMinutes: 0, dailyOverview: true, lastOverviewDate: '',
    backupReminderDays: 7, lastBackupAt: '', onboarded: false, deviceId: '', consentVersion: '', consentAt: '', lastCallImport: '',
    smartSuggestions: true, weeklyPrompt: true, weeklyDay: 5, lastWeeklyPrompt: '', templates: [],
    pinHash: '', pinSalt: '', lockAfter: 0, bioId: '',
    categories: ['Individual', 'Business', 'Corporate', 'Government / NGO', 'Other'],
    promiseCategories: ['Payment', 'Documents', 'Call back', 'Delivery', 'Meeting', 'Other']
  };

  const reqP = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const txDone = (tx) => new Promise((res, rej) => { tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error || new Error('Transaction aborted')); });

  const openIDB = () => new Promise((resolve, reject) => {
    if (!window.indexedDB) return reject(new Error('This browser does not support IndexedDB, so ClientDesk cannot store data.'));
    const r = indexedDB.open(DB_NAME, DB_VERSION);
    r.onupgradeneeded = (e) => {
      const d = r.result;
      for (let v = e.oldVersion + 1; v <= (e.newVersion || DB_VERSION); v++) if (MIGRATIONS[v]) MIGRATIONS[v](d, r.transaction, e.oldVersion);
    };
    r.onblocked = () => console.warn('DB upgrade blocked by another tab');
    r.onsuccess = async () => {
      db = r.result;
      db.onversionchange = () => { db.close(); };
      try { await loadAll(); resolve(); } catch (e) { reject(e); }
    };
    r.onerror = () => reject(r.error);
  });

  CD.reloadAll = () => loadAll();
  // If storage is blocked (e.g. a sandboxed preview), run in memory so the app still opens; data is NOT saved.
  CD.memoryMode = false;
  CD.dbOpen = async () => {
    try { await openIDB(); } catch (e) {
      console.warn('IndexedDB unavailable, using memory mode', e);
      CD.memoryMode = true; db = null; CD.settings = { ...CD.DEFAULTS, deviceId: CD.uuid() }; CD.invalidate();
    }
  };
  async function loadAll() {
    const tx = db.transaction([...CD.STORES, 'settings'], 'readonly');
    const reqs = CD.STORES.map((s) => reqP(tx.objectStore(s).getAll()));
    const sreq = reqP(tx.objectStore('settings').getAll());
    const res = await Promise.all(reqs);
    CD.STORES.forEach((s, i) => { CD.data[s] = res[i]; });
    const rows = await sreq;
    CD.settings = { ...CD.DEFAULTS };
    rows.forEach((r) => { CD.settings[r.key] = r.value; });
    if (!CD.settings.deviceId) await CD.setSetting('deviceId', CD.uuid());
    CD.invalidate();
  }

  /* ---------- Cache maps ---------- */
  let maps = null;
  CD.invalidate = () => { maps = null; };
  CD.clientsById = () => { if (!maps) maps = { clients: new Map(CD.data.clients.map((c) => [c.id, c])), promises: new Map(CD.data.promises.map((c) => [c.id, c])), calls: new Map(CD.data.calls.map((c) => [c.id, c])), followups: new Map(CD.data.followups.map((c) => [c.id, c])) }; return maps.clients; };
  CD.byId = (store, id) => { CD.clientsById(); return maps[store] ? maps[store].get(id) : CD.data[store].find((r) => r.id === id); };
  CD.client = (id) => CD.byId('clients', id);
  CD.clientName = (id) => { const c = CD.client(id); return c ? c.name : '(deleted client)'; };

  /* ---------- Writes ---------- */
  let batchDepth = 0, pending = false;
  const fire = () => { CD.invalidate(); if (batchDepth > 0) { pending = true; return; } CD.emit('change'); };
  CD.batch = async (fn) => {
    batchDepth++;
    try { return await fn(); } finally { batchDepth--; if (batchDepth === 0 && pending) { pending = false; CD.invalidate(); CD.emit('change'); } }
  };

  function cachePut(store, rec) {
    const arr = CD.data[store]; const i = arr.findIndex((r) => r.id === rec.id);
    if (i >= 0) arr[i] = rec; else arr.push(rec);
  }

  CD.put = async (store, rec, opts = {}) => {
    const now = new Date().toISOString();
    rec = { ...rec };
    if (!rec.id) rec.id = CD.uuid();
    if (!rec.created_at) rec.created_at = now;
    if (!opts.keepTimestamps || !rec.updated_at) rec.updated_at = now;
    if (!db) { cachePut(store, rec); if (opts.silent) CD.invalidate(); else fire(); return rec; }
    const tx = db.transaction([store, 'changes'], 'readwrite');
    tx.objectStore(store).put(rec);
    tx.objectStore('changes').add({ store, id: rec.id, op: 'put', at: now });
    await txDone(tx);
    cachePut(store, rec);
    if (opts.silent) CD.invalidate(); else fire();
    return rec;
  };

  CD.del = async (store, ids) => {
    ids = Array.isArray(ids) ? ids : [ids];
    if (!ids.length) return;
    const now = new Date().toISOString();
    if (!db) { const set0 = new Set(ids); CD.data[store] = CD.data[store].filter((r) => !set0.has(r.id)); fire(); return; }
    const tx = db.transaction([store, 'changes'], 'readwrite');
    ids.forEach((id) => { tx.objectStore(store).delete(id); tx.objectStore('changes').add({ store, id, op: 'delete', at: now }); });
    await txDone(tx);
    const set = new Set(ids);
    CD.data[store] = CD.data[store].filter((r) => !set.has(r.id));
    fire();
  };

  CD.setSetting = async (key, value) => {
    if (!db) { CD.settings[key] = value; CD.emit('settings', key); return; }
    const tx = db.transaction('settings', 'readwrite');
    tx.objectStore('settings').put({ key, value });
    await txDone(tx);
    CD.settings[key] = value;
    CD.emit('settings', key);
  };

  CD.deleteClientCascade = async (clientId) => {
    await CD.batch(async () => {
      const promiseIds = CD.data.promises.filter((p) => p.clientId === clientId).map((p) => p.id);
      await CD.del('promiseEvents', CD.data.promiseEvents.filter((e) => promiseIds.includes(e.promiseId)).map((e) => e.id));
      await CD.del('promises', promiseIds);
      await CD.del('calls', CD.data.calls.filter((c) => c.clientId === clientId).map((c) => c.id));
      await CD.del('followups', CD.data.followups.filter((f) => f.clientId === clientId).map((f) => f.id));
      await CD.del('reminders', CD.data.reminders.filter((r) => r.clientId === clientId).map((r) => r.id));
      await CD.del('clients', clientId);
    });
  };

  CD.removeDemoData = async () => {
    await CD.batch(async () => {
      for (const s of CD.STORES) await CD.del(s, CD.data[s].filter((r) => r.demo).map((r) => r.id));
    });
  };

  CD.wipeAll = async () => {
    if (!db) { CD.STORES.forEach((s) => { CD.data[s] = []; }); fire(); return; }
    const tx = db.transaction([...CD.STORES, 'changes'], 'readwrite');
    CD.STORES.forEach((s) => tx.objectStore(s).clear());
    tx.objectStore('changes').clear();
    await txDone(tx);
    CD.STORES.forEach((s) => { CD.data[s] = []; });
    fire();
  };

  /* ---------- Export / Import ---------- */
  CD.exportAll = () => ({
    app: 'ClientDesk', schema: DB_VERSION, exportedAt: new Date().toISOString(), deviceId: CD.settings.deviceId,
    settings: { ...CD.settings, lastOverviewDate: undefined, pinHash: undefined, pinSalt: undefined, bioId: undefined, templates: undefined },
    data: Object.fromEntries(CD.STORES.map((s) => [s, CD.data[s]]))
  });

  const MAXLEN = 20000;
  function sanitize(store, rec) {
    if (!rec || typeof rec !== 'object' || Array.isArray(rec)) return null;
    const spec = SCHEMA[store]; const out = {};
    for (const [k, t] of Object.entries(spec)) {
      const v = Object.prototype.hasOwnProperty.call(rec, k) ? rec[k] : undefined;
      if (v === undefined || v === null) continue;
      if (t === 's' && typeof v === 'string') out[k] = v.slice(0, MAXLEN);
      else if (t === 'n' && typeof v === 'number' && isFinite(v)) out[k] = v;
      else if (t === 'b' && typeof v === 'boolean') out[k] = v;
    }
    if (typeof out.id !== 'string' || !/^[\w-]{8,64}$/.test(out.id)) return null;
    if (!out.created_at) out.created_at = new Date().toISOString();
    if (!out.updated_at) out.updated_at = out.created_at;
    return out;
  }

  /** Validate & parse a backup file's text. Returns {ok, error?, clean?, counts?} — nothing is written. */
  CD.parseBackup = (text) => {
    if (text.length > 60 * 1024 * 1024) return { ok: false, error: 'That file is too large to be a ClientDesk backup.' };
    let obj; try { obj = JSON.parse(text); } catch (e) { return { ok: false, error: 'That file is not valid JSON, so it cannot be a ClientDesk backup.' }; }
    if (!obj || obj.app !== 'ClientDesk' || typeof obj.data !== 'object' || !obj.data) return { ok: false, error: 'This file does not look like a ClientDesk backup.' };
    if (typeof obj.schema === 'number' && obj.schema > DB_VERSION) return { ok: false, error: 'This backup was made by a newer version of ClientDesk. Update the app first.' };
    const clean = {}; const counts = {}; let skipped = 0;
    for (const s of CD.STORES) {
      const arr = Array.isArray(obj.data[s]) ? obj.data[s] : [];
      clean[s] = []; arr.forEach((r) => { const c = sanitize(s, r); if (c) clean[s].push(c); else skipped++; });
      counts[s] = clean[s].length;
    }
    // referential sanity: drop children whose client/promise is missing
    const cids = new Set(clean.clients.map((c) => c.id));
    const pids = new Set(clean.promises.map((c) => c.id));
    const before = clean.calls.length + clean.promises.length + clean.followups.length + clean.promiseEvents.length;
    clean.calls = clean.calls.filter((r) => cids.has(r.clientId));
    clean.promises = clean.promises.filter((r) => cids.has(r.clientId));
    clean.followups = clean.followups.filter((r) => cids.has(r.clientId));
    clean.promiseEvents = clean.promiseEvents.filter((r) => pids.has(r.promiseId));
    skipped += before - (clean.calls.length + clean.promises.length + clean.followups.length + clean.promiseEvents.length);
    CD.STORES.forEach((s) => { counts[s] = clean[s].length; });
    const settings = {};
    if (obj.settings && typeof obj.settings === 'object') {
      for (const [k, dv] of Object.entries(CD.DEFAULTS)) {
        const v = obj.settings[k];
        if (v === undefined || k === 'deviceId' || k === 'lastOverviewDate') continue;
        if (Array.isArray(dv) && Array.isArray(v) && v.every((x) => typeof x === 'string')) settings[k] = v.slice(0, 50).map((x) => x.slice(0, 60));
        else if (typeof v === typeof dv && !Array.isArray(dv)) settings[k] = typeof v === 'string' ? v.slice(0, 300) : v;
      }
    }
    ['pinHash', 'pinSalt', 'bioId', 'lockAfter'].forEach((k) => { delete settings[k]; });
    return { ok: true, clean, counts, skipped, settings, exportedAt: obj.exportedAt };
  };

  /** Apply a parsed backup. mode: 'merge' (newer updated_at wins; never silently overwrites newer local data) or 'replace'. */
  CD.applyBackup = async (parsed, mode) => {
    const stats = { added: 0, updated: 0, keptLocal: 0 };
    await CD.batch(async () => {
      if (mode === 'replace') await CD.wipeAll();
      for (const s of CD.STORES) {
        const existing = new Map(CD.data[s].map((r) => [r.id, r]));
        const toWrite = [];
        for (const r of parsed.clean[s]) {
          const ex = existing.get(r.id);
          if (!ex) { toWrite.push(r); stats.added++; }
          else if ((r.updated_at || '') > (ex.updated_at || '')) { toWrite.push(r); stats.updated++; }
          else stats.keptLocal++;
        }
        if (toWrite.length && !db) toWrite.forEach((r) => cachePut(s, r));
        else if (toWrite.length) {
          const now = new Date().toISOString();
          const tx = db.transaction([s, 'changes'], 'readwrite');
          toWrite.forEach((r) => { tx.objectStore(s).put(r); tx.objectStore('changes').add({ store: s, id: r.id, op: 'put', at: now }); });
          await txDone(tx);
          toWrite.forEach((r) => cachePut(s, r));
        }
      }
      if (mode === 'replace') for (const [k, v] of Object.entries(parsed.settings)) await CD.setSetting(k, v);
      else for (const k of ['categories', 'promiseCategories']) {
        if (parsed.settings[k]) await CD.setSetting(k, [...new Set([...(CD.settings[k] || []), ...parsed.settings[k]])]);
      }
      pending = true;
    });
    return stats;
  };

  CD.storageEstimate = async () => {
    try { if (navigator.storage && navigator.storage.estimate) return await navigator.storage.estimate(); } catch (e) { /* ignore */ }
    return null;
  };
})();
