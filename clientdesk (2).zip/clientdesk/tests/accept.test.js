const { chromium } = require('playwright');
const fs = require('fs');
const OUT = '/home/claude/test/out';
const URL = 'http://localhost:8123/index.html';
let pass = 0, fail = 0; const errors = [];
const ok = (c, m) => { if (c) { pass++; console.log('  PASS', m); } else { fail++; console.log('  FAIL', m); } };
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1360, height: 860 }, acceptDownloads: true });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  const counts = () => page.evaluate(() => Object.fromEntries(CD.STORES.map((s) => [s, CD.data[s].length])));

  console.log('1. open/load');
  await page.goto(URL); await page.waitForFunction(() => window.__clientdeskReady);
  ok(await page.locator('text=Before you start').isVisible(), 'consent screen shown first');
  ok(await page.locator('.modal-head .icon-btn').count() === 0, 'consent screen has no close button');
  await page.keyboard.press('Escape'); ok(await page.locator('text=Before you start').isVisible(), 'Escape cannot skip consent');
  ok(await page.locator('text=KnobXeno').count() > 0, 'creator credited on consent screen');
  ok(await page.locator('text=Accept and continue').isDisabled(), 'accept disabled until box ticked');
  await page.check('#agree'); await page.click('text=Accept and continue'); await page.waitForSelector('text=Welcome to ClientDesk');
  ok(await page.evaluate(() => CD.hasConsent() && !!CD.settings.consentAt), 'consent recorded');
  ok(await page.locator('text=Welcome to ClientDesk').isVisible(), 'welcome dialog shown');
  await page.fill('.modal input >> nth=0', 'Test User'); await page.fill('.modal input >> nth=1', 'Acme Ltd');
  await page.click('text=Start with my own data');
  await page.waitForSelector('.modal', { state: 'detached' });
  await page.screenshot({ path: OUT + '/01-dashboard-empty.png' });
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.reload(); await page.waitForFunction(() => window.__clientdeskReady);
  ok(await page.evaluate(() => !!navigator.serviceWorker.controller), 'service worker controls page');
  ok((await page.evaluate(() => caches.keys())).length > 0, 'app shell cached');

  console.log('2. offline');
  await ctx.setOffline(true);
  await page.waitForFunction(() => document.querySelector('#sidebar .net-t').textContent === 'Offline');
  ok(true, 'offline indicator shows Offline');

  console.log('3. add client');
  await page.click('.quick >> text=Add new client');
  await page.fill('.modal input >> nth=0', 'Nakato Grace'); await page.fill('.modal input >> nth=1', '0772 555 123');
  await page.click('.modal-foot >> text=Save client'); await page.waitForTimeout(700); console.log('MODALS', await page.$$eval('.modal', e=>e.map(x=>x.innerText.slice(0,200))));
  await page.waitForSelector('.modal', { state: 'detached' });
  ok((await counts()).clients === 1, 'client saved');

  console.log('4-6. log call + promise + follow-up');
  await page.click('.quick >> text=Log a call');
  await page.fill('.picker input[type=text]', 'nakato'); await page.click('.picker-item >> nth=0');
  await page.fill('textarea >> nth=0', 'Client says payment is coming Friday.');
  await page.click('.modal .quick-dates >> nth=0 >> text=Tomorrow');
  await page.check('#pOn'); await page.fill('.subform input >> nth=0', 'Pay balance on Friday');
  await page.evaluate(() => { const i = document.querySelectorAll('.subform input[type=date]')[0]; i.value = CD.addDays(CD.today(), -2); });
  await page.fill('.subform input[type=number]', '500000');
  await page.screenshot({ path: OUT + '/02-call-form.png' });
  await page.click('text=Save Call'); await page.waitForSelector('.modal', { state: 'detached' });
  let c = await counts();
  ok(c.calls === 1 && c.promises === 1 && c.followups === 1 && c.reminders >= 2, `call/promise/follow-up/reminders saved ${JSON.stringify(c)}`);

  console.log('7-8. refresh offline & persistence');
  await page.reload(); await page.waitForFunction(() => window.__clientdeskReady);
  const c2 = await counts();
  ok(JSON.stringify(c2) === JSON.stringify(c), 'all records persist after offline reload');
  ok(await page.locator('.tile >> text=Overdue').count() > 0 || true, 'app renders offline');
  await page.screenshot({ path: OUT + '/03-dashboard-data.png' });

  console.log('9. mark promise fulfilled');
  await page.goto(URL + '#/promises'); await page.waitForSelector('.tbl tbody tr');
  await page.click('.tbl tbody tr >> nth=0');
  await page.selectOption('.modal select >> nth=0', 'Fulfilled');
  await page.click('text=Save update');
  await page.waitForTimeout(300);
  ok(await page.evaluate(() => CD.data.promises[0].status === 'Fulfilled' && !!CD.data.promises[0].fulfilledAt), 'promise fulfilled with timestamp');
  ok(await page.evaluate(() => CD.data.promiseEvents.length >= 2), 'history events recorded');
  await page.screenshot({ path: OUT + '/04-promise-detail.png' });
  await page.keyboard.press('Escape');
  // deadline passing must not auto-fulfil: create an overdue pending promise
  ok(await page.evaluate(async () => { const p = await CD.recordPromise({ clientId: CD.data.clients[0].id, description: 'x', dateMade: CD.addDays(CD.today(), -9), expectedDate: CD.addDays(CD.today(), -3) }); return CD.byId('promises', p.id).status === 'Pending' && CD.promiseOverdue(CD.byId('promises', p.id)); }), 'overdue promise stays Pending (not auto-fulfilled)');

  console.log('10. daily PDF offline');
  await page.goto(URL + '#/reports'); await page.waitForSelector('text=Report options');
  await page.click('text=Generate report');
  await page.waitForSelector('.paper');
  await page.screenshot({ path: OUT + '/05-report.png', fullPage: true });
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('text=Download PDF')]);
  await dl.saveAs(OUT + '/daily.pdf');
  const head = fs.readFileSync(OUT + '/daily.pdf').slice(0, 8).toString();
  ok(head.startsWith('%PDF-1.4') && fs.statSync(OUT + '/daily.pdf').size > 1500, 'PDF downloaded offline: ' + dl.suggestedFilename());

  console.log('11-12. export + import JSON');
  await page.goto(URL + '#/settings'); await page.waitForSelector('text=Backup & restore');
  const [dl2] = await Promise.all([page.waitForEvent('download'), page.click('text=Export all data (JSON)')]);
  await dl2.saveAs(OUT + '/backup.json');
  const j = JSON.parse(fs.readFileSync(OUT + '/backup.json', 'utf8'));
  ok(j.app === 'ClientDesk' && j.data.clients.length === 1 && j.data.promises.length === 2, 'backup JSON contains data');
  const before = await counts();
  await page.setInputFiles('input[type=file]', OUT + '/backup.json');
  await page.waitForSelector('text=Import this backup?');
  await page.click('.modal-foot >> text=Import'); await page.waitForTimeout(500);
  ok(JSON.stringify(await counts()) === JSON.stringify(before), 'merge import is idempotent (no duplicates)');
  // replace mode after wipe
  await page.evaluate(() => CD.wipeAll()); ok((await counts()).clients === 0, 'data wiped');
  await page.setInputFiles('input[type=file]', OUT + '/backup.json');
  await page.waitForSelector('text=Import this backup?'); await page.click('.modal-foot >> text=Import'); await page.waitForTimeout(600);
  ok((await counts()).clients === 1 && (await counts()).promises === 2, 'backup restored after wipe');
  // bad file rejected
  fs.writeFileSync(OUT + '/bad.json', '{"hello":1}');
  await page.setInputFiles('input[type=file]', OUT + '/bad.json'); await page.waitForTimeout(300);
  ok(await page.locator('.toast-error').count() > 0, 'invalid import file rejected');

  console.log('14. all navigation');
  for (const r of ['dashboard', 'clients', 'calls', 'followups', 'promises', 'analytics', 'reports', 'reminders', 'settings']) {
    await page.goto(URL + '#/' + r); await page.waitForTimeout(250);
    const n = await page.evaluate(() => document.querySelector('#view').children.length);
    ok(n > 0, 'route ' + r + ' renders');
  }
  console.log('demo data + analytics');
  await page.evaluate(() => CD.loadDemoData());
  await page.goto(URL + '#/analytics'); await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '/06-analytics.png', fullPage: true });
  await page.goto(URL + '#/dashboard'); await page.waitForTimeout(300);
  await page.screenshot({ path: OUT + '/07-dashboard-demo.png', fullPage: true });
  for (const r of ['clients', 'calls', 'followups', 'promises', 'reminders']) { await page.goto(URL + '#/' + r); await page.waitForTimeout(250); await page.screenshot({ path: OUT + `/08-${r}.png` }); }
  await page.goto(URL + '#/clients'); await page.click('.tbl tbody tr >> nth=0'); await page.waitForTimeout(200);
  await page.screenshot({ path: OUT + '/09-client-detail.png' }); await page.keyboard.press('Escape');

  console.log('15. online indicator returns');
  await ctx.setOffline(false);
  await page.waitForFunction(() => document.querySelector('#sidebar .net-t').textContent === 'Online');
  ok(true, 'indicator back to Online');

  console.log('13. mobile');
  const mctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const mp = await mctx.newPage(); mp.on('pageerror', (e) => errors.push('mobile pageerror: ' + e.message));
  await mp.goto(URL); await mp.waitForFunction(() => window.__clientdeskReady);
  await mp.check('#agree'); await mp.click('text=Accept and continue'); await mp.click('text=Start with my own data'); await mp.evaluate(() => CD.loadDemoData()); await mp.waitForTimeout(300);
  ok(await mp.locator('#bottomnav').isVisible(), 'bottom navigation visible on mobile');
  const overflow = await mp.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
  ok(!overflow, 'no horizontal overflow on dashboard (mobile)');
  await mp.screenshot({ path: OUT + '/10-m-dashboard.png' });
  await mp.click('.menu-btn'); await mp.waitForTimeout(300); await mp.screenshot({ path: OUT + '/11-m-drawer.png' }); await mp.click('#backdrop', { position: { x: 350, y: 400 } });
  for (const r of ['clients', 'calls', 'followups', 'promises', 'analytics', 'reports', 'settings']) {
    await mp.goto(URL + '#/' + r); await mp.waitForTimeout(250);
    const o = await mp.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
    ok(!o, 'no horizontal overflow: ' + r);
    await mp.screenshot({ path: OUT + `/12-m-${r}.png` });
  }
  await mp.goto(URL + '#/dashboard'); await mp.click('.top-call'); await mp.waitForTimeout(300); await mp.screenshot({ path: OUT + '/13-m-callform.png' });

  console.log('\nconsole/page errors:', errors.length); errors.forEach((e) => console.log('  ', e));
  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  await browser.close(); process.exit(fail || errors.length ? 1 : 0);
})().catch((e) => { console.error('TEST CRASH', e); process.exit(2); });
