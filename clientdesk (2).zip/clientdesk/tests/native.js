const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1200, height: 800 }, acceptDownloads: true }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  await p.addInitScript(() => {
    window.__calls = [];
    const rec = (n, m) => (a) => { window.__calls.push([n, m, JSON.parse(JSON.stringify(a || {}))]); };
    window.Capacitor = { isNativePlatform: () => true, Plugins: {
      Filesystem: { writeFile: async (a) => { window.__calls.push(['FS', 'writeFile', { path: a.path, len: a.data.length, dir: a.directory }]); return { uri: 'file:///cache/' + a.path }; } },
      Share: { share: async (a) => { window.__calls.push(['Share', 'share', a]); } },
      LocalNotifications: { checkPermissions: async () => ({ display: 'prompt' }), requestPermissions: async () => ({ display: 'granted' }), getPending: async () => ({ notifications: [{ id: 5 }] }), cancel: async (a) => { rec('LN', 'cancel')(a); }, schedule: async (a) => { window.__calls.push(['LN', 'schedule', { n: a.notifications.length, first: a.notifications[0] && a.notifications[0].title }]); } },
      App: { addListener: (e, f) => { window.__backFn = f; }, exitApp: () => { window.__exited = true; } }
    } };
  });
  await p.goto('http://localhost:8123/index.html'); await p.waitForFunction(() => window.__clientdeskReady);
  await p.check('#agree'); await p.click('text=Accept and continue'); await p.click('text=Start with my own data');
  console.log('native class:', await p.evaluate(() => document.documentElement.classList.contains('native-app')), '| SW registered:', await p.evaluate(async () => !!(await navigator.serviceWorker.getRegistration())));
  console.log('perm before:', await p.evaluate(() => CD.notifState()));
  console.log('request ->', await p.evaluate(() => CD.requestNotifications()));
  await p.evaluate(async () => { const c = await CD.saveClient({ name: 'A', phone: '0772 000 111', status: 'Active', registered: CD.today() }); await CD.saveFollowup({ clientId: c.id, reason: 'x', date: CD.addDays(CD.today(), 2), time: '10:00', priority: 'Normal', status: 'Pending' }); });
  await p.waitForTimeout(1500);
  console.log('schedule calls:', JSON.stringify(await p.evaluate(() => window.__calls.filter((c) => c[0] === 'LN'))));
  await p.evaluate(() => CD.downloadBlob(new Blob(['hi'], { type: 'text/plain' }), 'test.txt')); await p.waitForTimeout(300);
  console.log('file save:', JSON.stringify(await p.evaluate(() => window.__calls.filter((c) => c[0] === 'FS' || c[0] === 'Share'))));
  await p.evaluate(() => { location.hash = '#/clients'; }); await p.waitForTimeout(200);
  await p.evaluate(() => window.__backFn()); await p.waitForTimeout(200);
  console.log('back -> hash', await p.evaluate(() => location.hash)); await p.evaluate(() => window.__backFn()); console.log('exited:', await p.evaluate(() => !!window.__exited));
  await p.screenshot({ path: '/home/claude/test/out/native.png' });
  console.log('errors', errs); await b.close();
})();
