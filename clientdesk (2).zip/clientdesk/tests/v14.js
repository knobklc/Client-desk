const { chromium } = require('playwright');
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  PASS' : '  FAIL', m); };
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1300, height: 900 } }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  await p.addInitScript(() => { window.__opened = []; window.open = (u) => { window.__opened.push(u); return null; }; });
  const URL = 'http://localhost:8123/index.html';
  await p.goto(URL); await p.waitForFunction(() => window.__clientdeskReady);
  await p.check('#agree'); await p.click('text=Accept and continue'); await p.click('text=Start with my own data');
  await p.waitForSelector('.modal', { state: 'detached' });

  console.log('analysis');
  const A = await p.evaluate(() => { const t = (s) => CD.analyseCall({ summary: s, date: CD.today() }); return {
    paid: t('Client has paid UGX 500,000 via mobile money').paid, amt: t('Client has paid UGX 500,000 via mobile money').amount,
    notPaid: t('Client has not paid yet, says tomorrow').paid, notPaid2: t("He hasn't sent the money").paid,
    promise: t('Will pay 300k on Friday').promise, k: t('Will pay 300k on Friday').amount, when: !!t('Will pay 300k on Friday').when,
    chat: t('Asked about opening hours').promise || t('Asked about opening hours').paid, m: CD.parseAmount('balance of 1.5m'), tomorrow: t('will pay tomorrow').when === CD.addDays(CD.today(), 1) }; });
  ok(A.paid && A.amt === 500000, 'detects payment + amount'); ok(!A.notPaid && !A.notPaid2, 'negation not treated as paid');
  ok(A.promise && A.k === 300000 && A.when, 'detects promise, 300k, weekday'); ok(!A.chat, 'plain chat ignored'); ok(A.m === 1500000, '1.5m parsed'); ok(A.tomorrow, 'tomorrow parsed');

  await p.evaluate(async () => { const c = await CD.saveClient({ name: 'Nakato Grace', phone: '0772 555 123', status: 'Active', registered: CD.today() });
    await CD.recordPromise({ clientId: c.id, description: 'Pay invoice 44', dateMade: CD.today(), expectedDate: CD.addDays(CD.today(), 2), amount: 500000, category: 'Payment', notes: '', status: 'Pending' }); });

  console.log('payment suggestion');
  const logCall = async (text) => { await p.click('.quick >> text=Log a call'); await p.fill('.picker input[type=text]', 'nakato'); await p.click('.picker-item >> nth=0'); await p.fill('textarea >> nth=0', text); await p.click('.modal-foot >> text=Save Call'); await p.waitForTimeout(900); };
  await logCall('Client has not paid yet, says soon.');
  ok(await p.$$eval('.modal h2', (e) => e.map((x) => x.textContent)).then((t) => !t.some((x) => /Payment|promise/i.test(x))), 'no suggestion for unpaid note');
  await logCall('Client has paid UGX 500,000 via mobile money.');
  ok(await p.isVisible('.modal >> text=Payment mentioned'), 'payment suggestion appears');
  await p.click('.modal-foot >> text=Mark fulfilled'); await p.waitForTimeout(500);
  const st = await p.evaluate(() => CD.data.promises.map((x) => [x.status, x.amountFulfilled]));
  ok(st.length === 1 && st[0][0] === 'Fulfilled' && st[0][1] === 500000, 'promise fulfilled with amount ' + JSON.stringify(st));

  console.log('promise suggestion');
  await logCall('Says he will pay 300k on Friday.');
  ok(await p.isVisible('.modal >> text=A promise was made?'), 'promise suggestion appears');
  await p.click('.modal-foot >> text=Record promise'); await p.waitForTimeout(500);
  const pr = await p.evaluate(() => ({ p: CD.data.promises.filter((x) => x.status === 'Pending').map((x) => x.amount), f: CD.data.followups.length }));
  ok(pr.p.length === 1 && pr.p[0] === 300000 && pr.f === 1, 'promise + follow-up created ' + JSON.stringify(pr));

  console.log('quick reply');
  await p.evaluate(() => CD.quickReply(CD.data.clients[0].id));
  const txt = await p.inputValue('.modal textarea');
  ok(/Nakato/.test(txt) && !/\{/.test(txt), 'template filled: ' + txt.slice(0, 60));
  await p.click('.modal .chip >> nth=1'); const t2 = await p.inputValue('.modal textarea');
  ok(/300,?000|UGX/.test(t2) || /reminder/i.test(t2), 'payment reminder uses promise');
  await p.click('.modal-foot >> text=Open WhatsApp'); await p.waitForTimeout(200);
  ok((await p.evaluate(() => window.__opened[0] || '')).startsWith('https://wa.me/256772555123?text='), 'opens wa.me with text');

  console.log('weekly summary');
  await p.evaluate(() => CD.openWeeklySummary('this'));
  ok(await p.isVisible('.modal >> text=Weekly summary') && (await p.$$('.ws-stat')).length >= 4, 'weekly summary shows stats');
  await p.click('.modal .chip >> text=Last week'); await p.waitForSelector('.ws-grid'); ok(true, 'last week toggles');
  await p.click('.modal-foot >> text=WhatsApp'); ok((await p.evaluate(() => window.__opened.length)) === 2, 'summary shared via WhatsApp');
  await p.keyboard.press('Escape');

  console.log('PIN lock');
  await p.goto(URL + '#/settings'); await p.waitForSelector('text=Set a PIN'); await p.click('text=Set a PIN');
  await p.fill('.modal input >> nth=0', '1234'); await p.fill('.modal input >> nth=1', '9999'); await p.click('.modal-foot >> text=Save PIN');
  ok(await p.isVisible('.modal >> text=do not match'), 'mismatched PIN rejected');
  await p.fill('.modal input >> nth=1', '1234'); await p.click('.modal-foot >> text=Save PIN'); await p.waitForSelector('text=App lock is');
  ok(await p.evaluate(() => !!CD.settings.pinHash && CD.settings.pinHash !== '1234'), 'PIN stored hashed');
  const bk = await p.evaluate(() => JSON.stringify(CD.exportAll())); ok(!/pinHash":"[0-9a-f]{10}/.test(bk), 'backup excludes PIN hash');
  await p.reload(); await p.waitForSelector('.lock-screen');
  ok(true, 'locked on reload');
  await p.fill('.lock-pin', '0000'); await p.click('.lock-screen >> text=Unlock'); await p.waitForSelector('text=Wrong PIN');
  ok(true, 'wrong PIN rejected');
  await p.fill('.lock-pin', '1234'); await p.click('.lock-screen >> text=Unlock'); await p.waitForSelector('.lock-screen', { state: 'detached' });
  ok(true, 'correct PIN unlocks');
  await p.evaluate(() => { Object.defineProperty(document, 'hidden', { value: true, configurable: true }); document.dispatchEvent(new Event('visibilitychange')); Object.defineProperty(document, 'hidden', { value: false, configurable: true }); document.dispatchEvent(new Event('visibilitychange')); });
  await p.waitForSelector('.lock-screen'); ok(true, 'relocks after leaving app');
  await p.fill('.lock-pin', '1234'); await p.click('.lock-screen >> text=Unlock'); await p.waitForSelector('.lock-screen', { state: 'detached' });
  await p.click('text=Turn off'); await p.fill('.modal input', '1234'); await p.click('.modal-foot >> text=Continue'); await p.waitForSelector('text=Set a PIN');
  ok(await p.evaluate(() => !CD.settings.pinHash), 'lock turned off');

  console.log('errors', errs); console.log('RESULT', pass, 'passed', fail, 'failed'); await b.close();
})();
