const { chromium } = require('playwright');
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  PASS' : '  FAIL', m); };
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1300, height: 900 } }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  await p.addInitScript(() => {
    window.__dev = [];
    const t = Date.now();
    window.Capacitor = { isNativePlatform: () => true, Plugins: {
      App: { addListener: () => {}, exitApp: () => {} },
      ClientDeskDevice: {
        getContacts: async () => { window.__dev.push('contacts'); return { contacts: [{ name: 'Achieng Ruth', numbers: ['0789 000 707', '+256789000707'] }, { name: 'Bwambale Tom', numbers: ['0701 123 456'] }, { name: 'No Number', numbers: [] }] }; },
        getCalls: async (o) => { window.__dev.push('calls:' + o.limit); return { calls: [
          { number: '0772 555 123', name: '', type: 2, date: t - 3600e3, duration: 125 },
          { number: '+256772555123', name: '', type: 3, date: t - 7200e3, duration: 0 },
          { number: '0755 999 888', name: 'Mukasa Joe', type: 1, date: t - 9000e3, duration: 60 },
          { number: '', name: '', type: 1, date: t - 1000e3, duration: 5 } ] }; }
      } } };
  });
  await p.goto('http://localhost:8123/index.html'); await p.waitForFunction(() => window.__clientdeskReady);
  await p.check('#agree'); await p.click('text=Accept and continue'); await p.click('text=Start with my own data');
  await p.evaluate(() => CD.saveClient({ name: 'Nakato Grace', phone: '0772 555 123', status: 'Active', registered: CD.today() }));

  console.log('contacts import');
  await p.goto('http://localhost:8123/index.html#/clients'); await p.click('text=Import numbers'); await p.click('text=Pick from phone contacts');
  ok(await p.locator('text=Use your contacts?').isVisible(), 'disclosure shown before permission');
  ok((await p.evaluate(() => window.__dev.length)) === 0, 'device not touched before consent');
  await p.click('.modal-foot >> text=Continue'); await p.waitForSelector('text=numbers found');
  const rows = await p.$$eval('.bulk tbody tr', (r) => r.map((x) => x.children[2].textContent));
  ok(rows.length === 2 && rows.includes('0789 000 707') && rows.includes('0701 123 456'), 'contacts listed, duplicate numbers merged: ' + rows);
  await p.click('.modal-foot .btn-primary'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => CD.data.clients.some((c) => c.name === 'Achieng Ruth')), 'selected contacts saved as clients');

  console.log('call history import');
  await p.goto('http://localhost:8123/index.html#/calls'); await p.click('text=Import from phone');
  await p.click('text=Read call history'); await p.click('.modal-foot >> text=Continue'); await p.waitForSelector('text=calls found');
  const n = await p.$$eval('.bulk tbody tr', (r) => r.length); ok(n === 3, 'blank/private numbers skipped, 3 calls listed');
  ok((await p.$$eval('.bulk tbody input:checked', (r) => r.length)) === 2, 'calls with saved clients pre-ticked');
  await p.check('.bulk tbody tr:nth-child(3) input'); await p.click('.modal-foot .btn-primary'); await p.waitForTimeout(500);
  const st = await p.evaluate(() => ({ calls: CD.data.calls.map((c) => [c.direction, c.outcome, c.source, c.durationSec]), clients: CD.data.clients.length }));
  ok(st.calls.length === 3 && st.clients === 4, 'calls imported + unknown number added as client ' + JSON.stringify(st));
  ok(st.calls.some((c) => c[0] === 'Outgoing' && c[1] === 'Answered' && c[3] === 125) && st.calls.some((c) => c[1] === 'No answer'), 'type/duration mapped to direction & outcome');
  await p.click('text=Import from phone'); await p.click('text=Read call history'); await p.click('.modal-foot >> text=Continue'); await p.waitForTimeout(400);
  ok(await p.locator('text=No new calls found').count() + await p.locator('text=already imported').count() > 0, 're-import skips calls already imported');
  await p.keyboard.press('Escape');

  console.log('start call');
  await p.evaluate(() => { CD.startCall(CD.data.clients[0].id); });
  ok(await p.evaluate(() => !!localStorage.getItem('cd_pending_call')), 'pending call remembered');
  await p.evaluate(() => { const v = JSON.parse(localStorage.getItem('cd_pending_call')); v.at -= 20000; v.time = '09:41'; localStorage.setItem('cd_pending_call', JSON.stringify(v)); CD.checkPendingCall(); });
  await p.waitForSelector('text=Log your call?'); await p.click('.modal-foot >> text=Log call'); await p.waitForSelector('text=Save Call');
  ok((await p.inputValue('.modal input[type=time]')) === '09:41', 'call form opens prefilled with the time the call started');
  await p.keyboard.press('Escape');

  console.log('legal');
  await p.goto('http://localhost:8123/index.html#/settings'); await p.click('text=Privacy Policy >> nth=-1');
  ok(await p.locator('.legal >> text=KnobXeno').count() > 0, 'privacy policy shows & credits KnobXeno');
  await p.screenshot({ path: '/home/claude/test/out/legal.png' }); await p.keyboard.press('Escape');
  ok(await p.locator('text=Created by').count() > 0, 'About shows creator');
  console.log('errors', errs); console.log(`RESULT ${pass} passed ${fail} failed`); await b.close(); process.exit(fail || errs.length ? 1 : 0);
})();
