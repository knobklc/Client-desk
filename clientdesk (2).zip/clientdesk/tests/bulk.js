const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
  const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto('http://localhost:8123/index.html?text=' + encodeURIComponent('12/11/2026, 10:15 - Moses: Grace Nakato 0772 000 111\n[12/11/26, 10:16:02] Ruth: Okello David: +256 752 000 222\n0703000333\n0772 000 111 again\nno number here\n0701 000 4440702 000 555')); await p.waitForFunction(() => window.__clientdeskReady);
  await p.check('#agree'); await p.click('text=Accept and continue'); await p.click('text=Start with my own data'); await p.waitForSelector('text=numbers found');
  const rows = await p.$$eval('.bulk tbody tr', (r) => r.map((x) => [x.querySelector('input[type=text],input:not([type])').value, x.children[2].textContent]));
  console.log(JSON.stringify(rows));
  await p.screenshot({ path: '/home/claude/test/out/bulk.png' });
  await p.click('text=Import 5 selected').catch(() => p.click('.modal-foot .btn-primary'));
  await p.waitForTimeout(500);
  console.log('clients', await p.evaluate(() => CD.data.clients.map((c) => c.name + '|' + c.phone)));
  console.log('errors', errs); await b.close();
})();
